variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "us-east-1"
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}

variable "project_name" {
  description = "Project name"
  type        = string
  default     = "soc"
}

variable "vpc_name" {
  description = "Name of the VPC"
  type        = string
  default     = "soc_vpc"
}

variable "vpc_cidr" {
  description = "CIDR block for VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "public_subnet_cidrs" {
  description = "CIDR blocks for public subnets"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
}

variable "private_subnet_cidrs" {
  description = "CIDR blocks for private subnets"
  type        = list(string)
  default     = ["10.0.11.0/24", "10.0.12.0/24", "10.0.13.0/24"]
}

variable "cluster_name" {
  description = "EKS Cluster name"
  type        = string
  default     = "soc-eks-cluster"
}

variable "kubernetes_version" {
  description = "Kubernetes version to use for the EKS cluster"
  type        = string
  default     = "1.29"
}

variable "desired_worker_nodes" {
  description = "Desired number of worker nodes"
  type        = number
  default     = 3
}

variable "min_worker_nodes" {
  description = "Minimum number of worker nodes"
  type        = number
  default     = 3
}

variable "max_worker_nodes" {
  description = "Maximum number of worker nodes"
  type        = number
  default     = 6
}

variable "worker_instance_type" {
  description = "EC2 instance type for worker nodes"
  type        = string
  default     = "t3.medium"
}

variable "worker_disk_size" {
  description = "Disk size in GiB for worker nodes"
  type        = number
  default     = 30
}

variable "cluster_role_arn" {
  description = "ARN of existing IAM role for EKS cluster (optional - leave empty to create new role). Required for AWS Academy labs."
  type        = string
  default     = ""
}

variable "node_role_arn" {
  description = "ARN of existing IAM role for EKS worker nodes (optional - leave empty to create new role). Required for AWS Academy labs."
  type        = string
  default     = ""
}

variable "create_oidc_provider" {
  description = "Whether to create OIDC provider for IRSA (IAM Roles for Service Accounts). Set to false for AWS Academy labs."
  type        = bool
  default     = true
}

variable "wazuh_allowed_cidr_blocks" {
  description = "CIDR blocks allowed for external access to Wazuh API and Dashboard"
  type        = list(string)
  default     = ["0.0.0.0/0"]
  # Example for production: ["192.168.1.0/24", "10.0.0.0/8"]
}

# Wazuh Configuration Variables
variable "wazuh_version" {
  description = "Wazuh version to deploy"
  type        = string
  default     = "4.8.0"
}

variable "wazuh_username" {
  description = "Wazuh dashboard username"
  type        = string
  default     = "admin"
}

variable "wazuh_password" {
  description = "Wazuh dashboard password"
  type        = string
  default     = "admin123"
  sensitive   = true
}

variable "elasticsearch_memory_limit" {
  description = "Memory limit for Elasticsearch pod"
  type        = string
  default     = "1Gi"
}

variable "elasticsearch_memory_request" {
  description = "Memory request for Elasticsearch pod"
  type        = string
  default     = "512Mi"
}

variable "manager_memory_limit" {
  description = "Memory limit for Wazuh manager pod"
  type        = string
  default     = "1Gi"
}

variable "manager_memory_request" {
  description = "Memory request for Wazuh manager pod"
  type        = string
  default     = "512Mi"
}

variable "api_memory_limit" {
  description = "Memory limit for Wazuh API pod"
  type        = string
  default     = "512Mi"
}

variable "api_memory_request" {
  description = "Memory request for Wazuh API pod"
  type        = string
  default     = "256Mi"
}

variable "dashboard_memory_limit" {
  description = "Memory limit for Wazuh dashboard pod"
  type        = string
  default     = "512Mi"
}

variable "dashboard_memory_request" {
  description = "Memory request for Wazuh dashboard pod"
  type        = string
  default     = "256Mi"
}

variable "elasticsearch_storage_size" {
  description = "Storage size for Elasticsearch data"
  type        = string
  default     = "20Gi"
}

variable "manager_data_storage_size" {
  description = "Storage size for Wazuh manager data"
  type        = string
  default     = "10Gi"
}

variable "manager_logs_storage_size" {
  description = "Storage size for Wazuh manager logs"
  type        = string
  default     = "10Gi"
}

variable "dashboard_service_type" {
  description = "Service type for Wazuh dashboard (LoadBalancer or ClusterIP)"
  type        = string
  default     = "LoadBalancer"
}

variable "enable_persistence" {
  description = "Enable persistent storage for Wazuh components"
  type        = bool
  default     = true
}

variable "storage_class_name" {
  description = "Storage class name for persistent volumes"
  type        = string
  default     = "gp3"
}
