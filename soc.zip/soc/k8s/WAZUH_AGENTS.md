# Wazuh Agents on EKS Worker Nodes

## 🏗️ Architecture

Your EKS deployment has:

```
┌─────────────────────────────────────────┐
│        AWS EKS Control Plane            │
│     (Managed by AWS - Can't Monitor)    │
│                                         │
│  • API Server       • Scheduler         │
│  • Controller Mgr   • etcd              │
└─────────────────────────────────────────┘
                 ▼
┌─────────────────────────────────────────┐
│           EKS Worker Nodes              │
│  (Your EC2 instances - CAN Monitor)     │
│                                         │
│  ┌─────────────┐  ┌─────────────┐      │
│  │   Worker 1  │  │   Worker 2  │      │
│  │ (t3.medium) │  │ (t3.medium) │      │
│  │             │  │             │      │
│  │ Wazuh Agent │  │ Wazuh Agent │      │
│  └─────────────┘  └─────────────┘      │
│                                         │
│  ┌─────────────┐                       │
│  │   Worker 3  │                       │
│  │ (t3.medium) │                       │
│  │             │                       │
│  │ Wazuh Agent │                       │
│  └─────────────┘                       │
└─────────────────────────────────────────┘
         │ Reports to
         ▼
┌─────────────────────────────┐
│    Wazuh Manager (Pod)      │
│  (Receives agent data)      │
└─────────────────────────────┘
```

## 🤖 What are Wazuh Agents?

**Wazuh Agents** are lightweight monitoring software that:
- ✅ Monitor system processes, files, and logs
- ✅ Detect unauthorized access attempts
- ✅ Identify malware and suspicious activity
- ✅ Collect compliance and audit data
- ✅ Report to the Wazuh Manager

## 🚀 Deploy Agents - 3 Methods

### Method 1: DaemonSet (Auto-Deploy on All Nodes) ⭐ RECOMMENDED

DaemonSet ensures one Wazuh agent runs on **every worker node automatically**.

#### Deploy:
```bash
kubectl apply -f wazuh-agent-daemonset.yaml
```

#### Or use the automated script:
```bash
chmod +x deploy-wazuh-agents.sh
./deploy-wazuh-agents.sh
```

#### Verify:
```bash
# See agents on each node
kubectl get pods -n wazuh -l component=agent -o wide

# Should see one agent pod per node:
# wazuh-agent-xxxxx  1/1  Running  <node-1>
# wazuh-agent-yyyyy  1/1  Running  <node-2>
# wazuh-agent-zzzzz  1/1  Running  <node-3>
```

---

### Method 2: Docker Container (On EC2 Worker Nodes)

If you want to run agents **directly on EC2 instances** (not in Kubernetes):

```bash
# On each EC2 worker node
docker run -d --name wazuh-agent \
  -e WAZUH_MANAGER="<manager-ip>" \
  -e WAZUH_MANAGER_PORT="1514" \
  -e WAZUH_AGENT_NAME="eks-worker-1" \
  -e WAZUH_AGENT_GROUP="kubernetes" \
  --restart=always \
  wazuh/wazuh-agent-ubi:4.7.2
```

---

### Method 3: Host Agent (Traditional Installation)

SSH into each EC2 worker node and install:

```bash
# SSH into worker node
ssh -i <your-key.pem> ec2-user@<worker-node-ip>

# Update system
sudo yum update -y

# Add Wazuh repo
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | sudo rpm --import -

# Install agent
sudo yum install wazuh-agent -y

# Configure manager
sudo sed -i 's/<value>MANAGER_IP<\/value>/<value>wazuh-manager-ip<\/value>/' /var/ossec/etc/ossec.conf

# Start agent
sudo systemctl start wazuh-agent
sudo systemctl enable wazuh-agent

# Verify
sudo systemctl status wazuh-agent
```

---

## 📊 Monitor Your Agents

### Check Agent Status:

```bash
# 1. View all agents running
kubectl get pods -n wazuh -l component=agent

# 2. Check specific agent logs
kubectl logs -f pod/wazuh-agent-xxxxx -n wazuh

# 3. List agents in Manager
kubectl exec -it deployment/wazuh-manager -n wazuh -- /var/ossec/bin/manage_agents -l

# 4. View agent details
kubectl exec -it deployment/wazuh-manager -n wazuh -- /var/ossec/bin/manage_agents -i 001
```

### In Wazuh Dashboard:

1. **Login** to Wazuh Dashboard
2. Go to **Management > Agents**
3. View all connected agents:
   - **Active** - Receiving data
   - **Disconnected** - Not sending data
   - **Pending** - Waiting for registration

### See Agent Data:

```bash
# View alerts from specific agent
kubectl logs -f pod/<agent-pod> -n wazuh | grep "alert"

# Count events per agent
kubectl exec -it deployment/wazuh-elasticsearch -n wazuh -- \
  curl -s "localhost:9200/wazuh-alerts-*/_search?size=0&aggs=agents" | jq
```

---

## 🔧 Configure Agents

### Change Agent Group (for organizing agents):

Edit `wazuh-agent-daemonset.yaml`:
```yaml
env:
- name: WAZUH_AGENT_GROUP
  value: "kubernetes-nodes"  # Change to: prod-workers, dev-workers, etc.
```

### Customize Monitoring:

Create a ConfigMap with custom agent config:

```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: wazuh-agent-config
  namespace: wazuh
data:
  agent.cfg: |
    # Monitor specific directories
    <localfile>
      <log_format>syslog</log_format>
      <location>/var/log/auth.log</location>
    </localfile>
    
    # Monitor specific files
    <syscheck>
      <directories check_all="yes">/etc</directories>
      <databases>yes</databases>
    </syscheck>
```

---

## 📈 Scaling and High Availability

### View Current Agents:
```bash
# Count agents
kubectl get pods -n wazuh -l component=agent | wc -l

# Expected: Number of worker nodes
kubectl get nodes | wc -l
```

### If new nodes are added:
```bash
# DaemonSet automatically deploys agents on new nodes
# Just wait a few moments...

# Verify
kubectl get pods -n wazuh -l component=agent -o wide
```

### If a node is removed:
```bash
# DaemonSet automatically removes the agent pod
kubectl get events -n wazuh
```

---

## 🆘 Troubleshooting

### Agents not connecting:

```bash
# 1. Check agent logs
kubectl logs -f pod/wazuh-agent-xxxxx -n wazuh

# 2. Verify Manager is running
kubectl get pods -n wazuh -l component=manager

# 3. Check Manager logs
kubectl logs -f deployment/wazuh-manager -n wazuh | grep agent

# 4. Verify network connectivity
kubectl exec -it pod/wazuh-agent-xxxxx -n wazuh -- \
  telnet wazuh-manager.wazuh.svc.cluster.local 1514
```

### Agent pod crashing:

```bash
# 1. Get pod status
kubectl describe pod wazuh-agent-xxxxx -n wazuh

# 2. Check events
kubectl get events -n wazuh

# 3. Check resource limits
kubectl top pods -n wazuh -l component=agent
```

### Missing agents on some nodes:

```bash
# Check node status
kubectl get nodes

# Check node selectors/taints
kubectl describe node <node-name> | grep -A5 "Taints\|Labels"

# Add node tolerations if needed
# Edit wazuh-agent-daemonset.yaml and add tolerations
```

---

## 🎯 Common Queries

### Get all agents:
```bash
kubectl get pods -n wazuh -l component=agent
```

### Get agents by node:
```bash
kubectl get pods -n wazuh -l component=agent --no-headers | awk '{print $7}' | sort | uniq -c
```

### Monitor agent connectivity:
```bash
kubectl exec -it deployment/wazuh-manager -n wazuh -- \
  /var/ossec/bin/manage_agents -s | grep -i active
```

### View agent metrics:
```bash
kubectl top pods -n wazuh -l component=agent
```

---

## 📝 Summary

| Aspect | Details |
|--------|---------|
| **What** | Wazuh agents monitor your worker nodes |
| **How Many** | One agent per worker node (DaemonSet) |
| **Deployment** | Automatic (DaemonSet handles scaling) |
| **Data** | Sent to Wazuh Manager for analysis |
| **Monitoring** | Via Dashboard or API |
| **Resource Cost** | ~128Mi RAM, 100m CPU per agent |

---

## ✅ Next Steps

1. **Deploy agents:**
   ```bash
   ./deploy-wazuh-agents.sh
   ```

2. **Verify all nodes have agents:**
   ```bash
   kubectl get pods -n wazuh -l component=agent -o wide
   ```

3. **Check Dashboard:**
   - Management > Agents
   - Should show 3 agents (one per worker node)

4. **Monitor security events:**
   - Security Events will show worker node activity
   - Check for file changes, process execution, etc.

5. **Configure additional monitoring** as needed for your use case