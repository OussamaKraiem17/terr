# Wazuh Security Configuration Guide

## 🔒 Security Overview

Your Wazuh deployment includes multiple layers of security:

1. **Kubernetes Network Policies** - Pod-to-pod traffic control
2. **AWS Security Groups** - VPC-level traffic control
3. **IAM Roles and Policies** - Access control
4. **Namespace Isolation** - Dedicated `wazuh` namespace

---

## 🛡️ Kubernetes Network Policies

Network Policies control traffic between Kubernetes pods in the `wazuh` namespace.

### Configuration Files

- `wazuh-network-policy.yaml` - Main network policies for all components

### What's Protected

| Component | Inbound | Outbound |
|-----------|---------|----------|
| **Manager** | From agents (1514), from API (55000) | To Elasticsearch (9200), to agents (1515) |
| **API** | From dashboard (55000), external (55000) | To manager (55000), to ES (9200) |
| **Dashboard** | External HTTP (5601) | To API (55000), to ES (9200) |
| **Elasticsearch** | From manager (9200), from dashboard (9200) | To other ES nodes (9300) |
| **Agents** | From manager (1515) | To manager (1514) |

### Deploy Network Policies

```bash
# Deploy network policies
kubectl apply -f wazuh-network-policy.yaml

# Verify policies are created
kubectl get networkpolicies -n wazuh

# View policy details
kubectl describe networkpolicy wazuh-network-policy -n wazuh
```

### Network Policy Rules

**Manager Ingress:**
- Port 1514 (TCP) - Agent data collection
- Port 1515 (TCP) - Agent registration
- Port 55000 (TCP) - From API access

**Manager Egress:**
- Port 9200 (TCP) - Elasticsearch
- Port 1515 (TCP) - Agent heartbeat/commands
- Port 53 (UDP) - DNS

**Elasticsearch Ingress:**
- Port 9200 (TCP) - HTTP API from manager/dashboard
- Port 9300 (TCP) - Node communication from other ES nodes

**API Ingress:**
- Port 55000 (TCP) - From dashboard and external clients

**Dashboard Ingress:**
- Port 5601 (TCP) - External HTTP access

---

## 🔐 AWS Security Groups

Security Groups control network traffic at the VPC level (EC2/ELB).

### Terraform Module

Created in `modules/wazuh-sg/` with:
- `main.tf` - Security group rules
- `variables.tf` - Configuration variables
- `outputs.tf` - Security group outputs

### Security Group Rules

#### Inbound Rules

| Port | Protocol | Source | Purpose |
|------|----------|--------|---------|
| 1514 | TCP | Cluster SG | Agent data |
| 1515 | TCP | Cluster SG | Agent registration |
| 5601 | TCP | 0.0.0.0/0 | Dashboard (change in prod) |
| 9200 | TCP | Cluster SG | Elasticsearch HTTP |
| 9300 | TCP | Cluster SG | Elasticsearch nodes |
| 55000 | TCP | 0.0.0.0/0 | API (change in prod) |
| 22 | TCP | 0.0.0.0/0 | SSH (change in prod) |

#### Outbound Rules

- All traffic allowed to 0.0.0.0/0

### Configure Security Groups

In `terraform.tfvars`:

```hcl
# Restrict access to specific IPs (recommended for production)
wazuh_allowed_cidr_blocks = [
  "10.0.0.0/8",              # Your VPC
  "192.168.1.100/32",        # Admin IP
  "203.0.113.0/24"           # Your organization
]
```

### Default Configuration (Development)

```hcl
wazuh_allowed_cidr_blocks = ["0.0.0.0/0"]  # Open to all (NOT RECOMMENDED for production)
```

### View Security Groups

```bash
# After Terraform deployment
terraform output wazuh_security_group_id
terraform output wazuh_security_group_name

# In AWS Console
aws ec2 describe-security-groups --group-ids sg-xxxxx
```

---

## 🔑 IAM Roles and Policies

Already configured in the EKS module:

### Cluster IAM Role
- **Policy:** `AmazonEKSClusterPolicy`
- **Purpose:** Allows EKS service to manage AWS resources

### Node IAM Role
- **Policies:**
  - `AmazonEKSWorkerNodePolicy`
  - `AmazonEKS_CNI_Policy`
  - `AmazonEC2ContainerRegistryReadOnly`
- **Purpose:** Allows EC2 nodes to join cluster and pull images

---

## 📋 Complete Security Deployment

### Step 1: Deploy Infrastructure with Terraform

```bash
cd /path/to/soc

# Configure terraform.tfvars with security settings
nano terraform.tfvars

# Add/update:
wazuh_allowed_cidr_blocks = ["YOUR_IP/32"]

# Deploy
terraform init
terraform plan
terraform apply
```

### Step 2: Deploy Kubernetes Network Policies

```bash
cd k8s

# Deploy policies
kubectl apply -f wazuh-network-policy.yaml

# Verify
kubectl get networkpolicies -n wazuh
```

### Step 3: Deploy Wazuh Components

```bash
# Deploy with network policies included
./deploy-wazuh.sh
```

---

## 🧪 Test Security Configuration

### Test Pod-to-Pod Communication

```bash
# Get a pod name
POD=$(kubectl get pod -n wazuh -l component=manager -o name | head -1)

# Test connectivity to Elasticsearch
kubectl exec -it $POD -n wazuh -- curl http://wazuh-elasticsearch:9200

# Test connectivity to API
kubectl exec -it $POD -n wazuh -- curl http://wazuh-api:55000/api/version

# Test DNS
kubectl exec -it $POD -n wazuh -- nslookup wazuh-elasticsearch.wazuh.svc.cluster.local
```

### Test External Access

```bash
# Port forward and test
kubectl port-forward -n wazuh svc/wazuh-dashboard 5601:5601 &
curl http://localhost:5601

# Port forward API
kubectl port-forward -n wazuh svc/wazuh-api 55000:55000 &
curl -u admin:admin http://localhost:55000/api/version
```

### Verify Security Group Rules

```bash
# Get security group ID
SG_ID=$(terraform output -raw wazuh_security_group_id)

# List all rules
aws ec2 describe-security-groups --group-ids $SG_ID

# View specific rule
aws ec2 describe-security-group-rules --filters Name=group-id,Values=$SG_ID
```

---

## 🚨 Production Security Checklist

### Network Security
- [ ] Restrict `wazuh_allowed_cidr_blocks` to specific IPs
- [ ] Change SSH port (1514 in current config)
- [ ] Review and restrict egress rules
- [ ] Enable VPC Flow Logs
- [ ] Consider using AWS WAF for dashboard/API

### Access Control
- [ ] Change default Wazuh credentials
- [ ] Enable HTTPS/TLS for dashboard
- [ ] Configure RBAC for Kubernetes
- [ ] Implement pod security policies
- [ ] Use IRSA for sensitive operations

### Data Protection
- [ ] Enable EBS encryption for persistent volumes
- [ ] Enable S3 encryption for backups
- [ ] Configure TLS between components
- [ ] Implement data classification

### Monitoring & Logging
- [ ] Enable EKS control plane logging
- [ ] Enable VPC Flow Logs
- [ ] Monitor Wazuh alerts
- [ ] Set up CloudTrail for audit logs

### Compliance
- [ ] Document security architecture
- [ ] Perform security assessment
- [ ] Review compliance requirements
- [ ] Schedule penetration testing

---

## 🔄 Updating Security Policies

### Update Network Policies

```bash
# Edit the policy
kubectl edit networkpolicy wazuh-network-policy -n wazuh

# Or apply updated file
kubectl apply -f wazuh-network-policy.yaml
```

### Update Security Groups

```bash
# Edit Terraform
nano terraform.tfvars

# Update allowed_cidr_blocks
wazuh_allowed_cidr_blocks = ["10.0.0.0/8", "192.168.1.0/24"]

# Apply changes
terraform plan
terraform apply
```

---

## 📊 Security Monitoring

### Monitor Network Policy Violations

```bash
# Check pod-level denials
kubectl get events -n wazuh

# View pod network interface stats
kubectl exec -it <pod> -n wazuh -- ip link show

# Check firewall rules from within pod
kubectl exec -it <pod> -n wazuh -- iptables -L
```

### Monitor Security Group Activity

```bash
# Enable VPC Flow Logs (Terraform)
# View in CloudWatch Logs

# Check security group rules changes
aws ec2 describe-security-group-rules --filters Name=group-id,Values=sg-xxxxx

# Monitor with CloudTrail
aws cloudtrail lookup-events --lookup-attributes AttributeKey=ResourceName,AttributeValue=sg-xxxxx
```

---

## 🆘 Troubleshooting

### Pods can't communicate

```bash
# 1. Check network policy
kubectl get networkpolicies -n wazuh
kubectl describe networkpolicy wazuh-manager-network-policy -n wazuh

# 2. Test directly
kubectl exec -it <pod> -n wazuh -- curl http://other-pod:port

# 3. Check DNS
kubectl exec -it <pod> -n wazuh -- nslookup service-name.wazuh.svc.cluster.local

# 4. Verify selectors match
kubectl get pods -n wazuh --show-labels
```

### Can't access dashboard externally

```bash
# 1. Check security group allows port 5601
aws ec2 describe-security-groups --group-ids sg-xxxxx | grep -A20 'IpPermissions'

# 2. Check service is exposed
kubectl get svc -n wazuh

# 3. Test from pod
kubectl exec -it <pod> -n wazuh -- curl http://wazuh-dashboard:5601

# 4. Port forward and test
kubectl port-forward svc/wazuh-dashboard 5601:5601 -n wazuh
```

---

## 📚 Additional Resources

- [Kubernetes Network Policies](https://kubernetes.io/docs/concepts/services-networking/network-policies/)
- [AWS Security Groups](https://docs.aws.amazon.com/vpc/latest/userguide/VPC_SecurityGroups.html)
- [Wazuh Security](https://documentation.wazuh.com/current/user-manual/manager/management.html)
- [EKS Security Best Practices](https://aws.github.io/aws-eks-best-practices/)