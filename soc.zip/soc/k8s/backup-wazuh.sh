#!/bin/bash

# Wazuh Data Backup Script
# This script creates backups of Wazuh persistent data

set -e

BACKUP_DIR="./wazuh-backups"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
BACKUP_NAME="wazuh_backup_${TIMESTAMP}"

echo "🔄 Starting Wazuh data backup..."

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

# Create backup directory
mkdir -p "${BACKUP_DIR}/${BACKUP_NAME}"

# Function to backup PVC data
backup_pvc() {
    local pvc_name=$1
    local namespace=$2
    local pod_name=$3
    local source_path=$4
    local backup_path=$5

    echo -e "${GREEN}[INFO]${NC} Backing up ${pvc_name}..."

    # Create backup directory
    mkdir -p "${BACKUP_DIR}/${BACKUP_NAME}/${pvc_name}"

    # Copy data from PVC
    kubectl cp "${namespace}/${pod_name}:${source_path}" "${BACKUP_DIR}/${BACKUP_NAME}/${pvc_name}/" -c "${pod_name%-*}" 2>/dev/null || {
        echo -e "${YELLOW}[WARNING]${NC} Could not backup ${pvc_name} - pod may not be running"
    }
}

# Get running pods
echo "🔍 Finding running Wazuh pods..."
WAZUH_MANAGER_POD=$(kubectl get pods -n wazuh -l app=wazuh,component=manager -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")
ELASTICSEARCH_POD=$(kubectl get pods -n wazuh -l app=wazuh,component=elasticsearch -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || echo "")

# Backup Wazuh Manager data
if [ -n "$WAZUH_MANAGER_POD" ]; then
    backup_pvc "wazuh-manager-data" "wazuh" "$WAZUH_MANAGER_POD" "/var/ossec/data" "data"
    backup_pvc "wazuh-manager-logs" "wazuh" "$WAZUH_MANAGER_POD" "/var/ossec/logs" "logs"
fi

# Backup Elasticsearch data
if [ -n "$ELASTICSEARCH_POD" ]; then
    backup_pvc "wazuh-elasticsearch-data" "wazuh" "$ELASTICSEARCH_POD" "/usr/share/elasticsearch/data" "data"
fi

# Create backup manifest
cat > "${BACKUP_DIR}/${BACKUP_NAME}/backup-info.txt" << EOF
Wazuh Backup Information
========================
Backup Date: $(date)
Backup Name: ${BACKUP_NAME}
Kubernetes Namespace: wazuh

Components Backed Up:
- Wazuh Manager Data (/var/ossec/data)
- Wazuh Manager Logs (/var/ossec/logs)
- Elasticsearch Data (/usr/share/elasticsearch/data)

To restore:
1. Scale down Wazuh deployments
2. Copy backup data back to PVCs
3. Scale up deployments

Note: This is a basic backup. For production, consider:
- Database snapshots
- Regular automated backups
- Off-cluster backup storage
EOF

# Compress backup
echo -e "${GREEN}[INFO]${NC} Compressing backup..."
cd "${BACKUP_DIR}"
tar -czf "${BACKUP_NAME}.tar.gz" "${BACKUP_NAME}"
rm -rf "${BACKUP_NAME}"

echo -e "${GREEN}[SUCCESS]${NC} Backup completed!"
echo -e "${GREEN}[INFO]${NC} Backup saved to: ${BACKUP_DIR}/${BACKUP_NAME}.tar.gz"
echo -e "${GREEN}[INFO]${NC} Backup size: $(du -sh "${BACKUP_NAME}.tar.gz" | cut -f1)"

# List backups
echo -e "${GREEN}[INFO]${NC} Available backups:"
ls -la "${BACKUP_DIR}"/*.tar.gz 2>/dev/null || echo "No previous backups found"