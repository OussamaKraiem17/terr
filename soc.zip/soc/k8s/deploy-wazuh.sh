#!/bin/bash

# Wazuh Kubernetes Deployment Script
# This script deploys Wazuh security monitoring platform to Kubernetes

set -e

echo "🚀 Starting Wazuh deployment to Kubernetes..."

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if kubectl is configured
if ! kubectl cluster-info >/dev/null 2>&1; then
    print_error "kubectl is not configured or cluster is not accessible"
    print_error "Please run: aws eks update-kubeconfig --region us-east-1 --name soc-eks-cluster"
    exit 1
fi

print_status "kubectl is configured and cluster is accessible"

# Apply manifests in order
MANIFESTS=(
    "wazuh-namespace.yaml"
    "wazuh-network-policy.yaml"
    "wazuh-pvc.yaml"
    "wazuh-elasticsearch.yaml"
    "wazuh-manager.yaml"
    "wazuh-api.yaml"
    "wazuh-dashboard.yaml"
    "wazuh-agent-daemonset.yaml"
    "wazuh-ingress.yaml"
)

for manifest in "${MANIFESTS[@]}"; do
    if [ -f "$manifest" ]; then
        if [ "$manifest" = "wazuh-pvc.yaml" ]; then
            print_status "Applying Persistent Volume Claims for data persistence..."
        else
            print_status "Applying $manifest..."
        fi
        kubectl apply -f "$manifest"
        sleep 2
    else
        print_error "Manifest $manifest not found!"
        exit 1
    fi
done

print_status "Waiting for Elasticsearch to be ready..."
kubectl wait --for=condition=ready pod -l app=wazuh,component=elasticsearch -n wazuh --timeout=300s

print_status "Waiting for Wazuh Manager to be ready..."
kubectl wait --for=condition=ready pod -l app=wazuh,component=manager -n wazuh --timeout=300s

print_status "Waiting for Wazuh API to be ready..."
kubectl wait --for=condition=ready pod -l app=wazuh,component=api -n wazuh --timeout=300s

print_status "Waiting for Wazuh Dashboard to be ready..."
kubectl wait --for=condition=ready pod -l app=wazuh,component=dashboard -n wazuh --timeout=300s

print_status "🎉 Wazuh deployment completed successfully!"
print_status ""
print_status "📊 Access Information:"
print_status "Dashboard URL: http://wazuh-dashboard.local (if using Ingress)"
print_status "API URL: http://wazuh-api.wazuh.svc.cluster.local:55000"
print_status "Manager: wazuh-manager.wazuh.svc.cluster.local:1514"
print_status ""
print_status "🔍 Check deployment status:"
print_status "kubectl get pods -n wazuh"
print_status "kubectl get services -n wazuh"
print_status ""
print_status "📝 Default credentials:"
print_status "Username: admin"
print_status "Password: admin"
print_status ""
print_warning "⚠️  Remember to change default passwords in production!"
print_warning "⚠️  Configure proper ingress/load balancer for external access"