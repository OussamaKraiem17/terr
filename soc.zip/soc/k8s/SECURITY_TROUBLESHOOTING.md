# Security Troubleshooting Guide

## Common Security Issues and Solutions

---

## 1. Network Policy Blocking Traffic

### Symptom
Pods cannot connect to each other or external services.

### Root Causes
- Network policy selectors don't match pod labels
- Egress rules too restrictive
- DNS resolution blocked

### Diagnosis
```bash
# Check which network policies exist
kubectl get networkpolicies -n wazuh

# Check pod labels (must match policy selectors)
kubectl get pods -n wazuh --show-labels

# View policy rules
kubectl describe networkpolicy wazuh-manager-network-policy -n wazuh

# Test connectivity
kubectl exec -it <pod-name> -n wazuh -- ping wazuh-elasticsearch.wazuh.svc.cluster.local

# Check logs
kubectl logs -n wazuh <pod-name> | grep -i "connection\|error\|refused"
```

### Solutions

**Solution 1: Pod Labels Don't Match**
```bash
# Current policy selects: component: manager
# But pod might be labeled: app: wazuh-manager

# Fix: Update network policy
kubectl edit networkpolicy wazuh-manager-network-policy -n wazuh

# Change selector to match actual pod labels
podSelector:
  matchLabels:
    component: manager  # Or your actual label
```

**Solution 2: Egress Rule Missing DNS**
```bash
# Current rule: only allows specific ports
# Need to add: port 53 for DNS

# Edit and add DNS egress rule:
- to:
  - namespaceSelector:
      matchLabels:
        name: kube-system
  ports:
  - protocol: UDP
    port: 53  # DNS
```

**Solution 3: Namespace Selector Missing**
```bash
# If pods communicate across namespaces, add:
- to:
  - namespaceSelector:
      matchLabels:
        name: other-namespace

# Make sure namespace has the label:
kubectl label namespace other-namespace name=other-namespace
```

---

## 2. Security Group Blocking External Traffic

### Symptom
Cannot access dashboard from browser, API endpoints unreachable.

### Root Causes
- Security group rules don't allow necessary ports
- Wrong source IP in rules
- Rules apply to wrong resource

### Diagnosis
```bash
# Get security group ID
SG_ID=$(aws ec2 describe-security-groups \
  --filters Name=group-name,Values=wazuh* \
  --query 'SecurityGroups[0].GroupId' \
  --output text)

echo $SG_ID

# List all rules
aws ec2 describe-security-groups --group-ids $SG_ID

# Check specific rule
aws ec2 describe-security-group-rules \
  --filters Name=group-id,Values=$SG_ID

# Test connectivity from outside
nc -zv -w 5 <node-ip> 5601
curl -v http://<node-ip>:5601
```

### Solutions

**Solution 1: Missing Inbound Rule**
```bash
# Add missing rule via Terraform
cd /path/to/soc
cat >> terraform.tfvars << EOF

wazuh_allowed_cidr_blocks = ["0.0.0.0/0"]
EOF

terraform apply

# Or manually with AWS CLI:
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxx \
  --protocol tcp \
  --port 5601 \
  --cidr 0.0.0.0/0
```

**Solution 2: Wrong Source IP**
```bash
# If rule says 0.0.0.0/0 but you need specific IP:
aws ec2 revoke-security-group-ingress \
  --group-id sg-xxxxx \
  --protocol tcp \
  --port 5601 \
  --cidr 0.0.0.0/0

aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxx \
  --protocol tcp \
  --port 5601 \
  --cidr YOUR.IP.ADDRESS/32
```

**Solution 3: Dashboard Service Type**
```bash
# Check if service is LoadBalancer or ClusterIP
kubectl get svc -n wazuh

# If ClusterIP, need port-forward or Ingress:
kubectl port-forward svc/wazuh-dashboard 5601:5601 -n wazuh

# Or expose as LoadBalancer:
kubectl patch svc wazuh-dashboard -n wazuh \
  -p '{"spec": {"type":"LoadBalancer"}}'
```

---

## 3. Pod Cannot Access Elasticsearch

### Symptom
Manager logs show "Cannot connect to Elasticsearch", dashboard shows no data.

### Root Causes
- Elasticsearch pod not running
- Network policy blocks port 9200
- Wrong Elasticsearch address in config

### Diagnosis
```bash
# Check Elasticsearch pod status
kubectl get pods -n wazuh -l component=elasticsearch
kubectl describe pod <elasticsearch-pod> -n wazuh

# Check if running
kubectl exec -it <manager-pod> -n wazuh -- \
  curl -v http://wazuh-elasticsearch:9200

# Check service
kubectl get svc -n wazuh -l component=elasticsearch

# Check logs
kubectl logs -n wazuh -l component=elasticsearch
kubectl logs -n wazuh -l component=manager | grep -i elasticsearch
```

### Solutions

**Solution 1: Elasticsearch Not Running**
```bash
# Deploy Elasticsearch
kubectl apply -f wazuh-elasticsearch.yaml

# Wait for it to be ready
kubectl wait --for=condition=ready pod \
  -l component=elasticsearch -n wazuh --timeout=300s
```

**Solution 2: Network Policy Blocks Port**
```bash
# Add to network policy: allow manager->elasticsearch port 9200
kubectl edit networkpolicy wazuh-manager-network-policy -n wazuh

# Add egress rule:
- to:
  - podSelector:
      matchLabels:
        component: elasticsearch
  ports:
  - protocol: TCP
    port: 9200
```

**Solution 3: Wrong Address in Config**
```bash
# Check manager config
kubectl get configmap -n wazuh wazuh-manager-config
kubectl describe cm wazuh-manager-config -n wazuh

# Should reference: http://wazuh-elasticsearch:9200
# Check it's set correctly:
kubectl exec -it <manager-pod> -n wazuh -- \
  grep -A2 'elasticsearch' /var/ossec/etc/ossec.conf
```

---

## 4. Agents Cannot Connect to Manager

### Symptom
No agents showing up in manager, agent logs show connection refused.

### Root Causes
- Manager pod not running
- Network policy blocks inbound on 1514/1515
- Agent pointing to wrong manager address
- Cluster security group blocks traffic

### Diagnosis
```bash
# Check manager is running
kubectl get pods -n wazuh -l component=manager

# Check ports are open
kubectl exec -it <manager-pod> -n wazuh -- ss -tlnp | grep -E "1514|1515"

# From agent pod, test connectivity
kubectl exec -it <agent-pod> -n wazuh -- \
  nslookup wazuh-manager.wazuh.svc.cluster.local

kubectl exec -it <agent-pod> -n wazuh -- \
  nc -zv wazuh-manager 1514

# Check agent logs
kubectl logs -n wazuh -l component=agent | grep -i "manager\|connect\|error" | head -20
```

### Solutions

**Solution 1: Manager Networking**
```bash
# Expose manager service correctly
kubectl get svc -n wazuh wazuh-manager

# Should show ClusterIP on ports 1514, 1515
# If missing, add service:
kubectl apply -f - <<EOF
apiVersion: v1
kind: Service
metadata:
  name: wazuh-manager
  namespace: wazuh
spec:
  type: ClusterIP
  selector:
    component: manager
  ports:
  - name: agent-data
    port: 1514
    targetPort: 1514
    protocol: TCP
  - name: agent-registration
    port: 1515
    targetPort: 1515
    protocol: TCP
EOF
```

**Solution 2: Network Policy allows Inbound**
```bash
# Verify network policy allows agent connections
kubectl describe networkpolicy wazuh-manager-network-policy -n wazuh

# Should show:
# - podSelector: component: agent
#   ports: 1514, 1515

# If missing, edit:
kubectl edit networkpolicy wazuh-manager-network-policy -n wazuh

# Add ingress rule:
- from:
  - podSelector:
      matchLabels:
        component: agent
  ports:
  - protocol: TCP
    port: 1514
  - protocol: TCP
    port: 1515
```

**Solution 3: Agent Configuration**
```bash
# Check agent config
kubectl exec -it <agent-pod> -n wazuh -- cat /var/ossec/etc/ossec.conf | grep -A2 manager

# Should point to: wazuh-manager.wazuh.svc.cluster.local
# If wrong, edit ConfigMap and restart agent:
kubectl edit configmap wazuh-agent-config -n wazuh
kubectl delete pod -n wazuh -l component=agent
```

---

## 5. Dashboard Inaccessible

### Symptom
Browser cannot load dashboard, connection timeout.

### Root Causes
- LoadBalancer not provisioned
- Security group blocks port 5601
- Dashboard pod not running
- Wrong endpoint

### Diagnosis
```bash
# Check service type and IP
kubectl get svc -n wazuh wazuh-dashboard

# For LoadBalancer: note EXTERNAL-IP
# For ClusterIP: use port-forward

# Check dashboard pod
kubectl get pods -n wazuh -l component=dashboard
kubectl describe pod <dashboard-pod> -n wazuh

# Check if listening on 5601
kubectl exec -it <dashboard-pod> -n wazuh -- ss -tlnp | grep 5601

# Check security group allows 5601
aws ec2 describe-security-groups --group-ids sg-xxxxx | grep -B5 -A5 5601
```

### Solutions

**Solution 1: Service Not Exposed**
```bash
# If service is ClusterIP, expose it
kubectl patch svc wazuh-dashboard -n wazuh -p '{"spec":{"type":"LoadBalancer"}}'

# Wait for external IP
kubectl get svc -n wazuh wazuh-dashboard -w

# Or use port-forward temporarily
kubectl port-forward svc/wazuh-dashboard 5601:5601 -n wazuh
# Then access: http://localhost:5601
```

**Solution 2: Security Group Blocks Traffic**
```bash
# Add 5601 to security group
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxx \
  --protocol tcp \
  --port 5601 \
  --cidr 0.0.0.0/0

# Verify
aws ec2 describe-security-groups --group-ids sg-xxxxx | grep 5601
```

**Solution 3: Dashboard Pod Not Ready**
```bash
# Check pod status
kubectl get pods -n wazuh -l component=dashboard

# If not ready, check events
kubectl describe pod <dashboard-pod> -n wazuh

# Check logs
kubectl logs -n wazuh -l component=dashboard

# Restart if needed
kubectl delete pod -n wazuh -l component=dashboard
kubectl wait --for=condition=ready pod -l component=dashboard -n wazuh --timeout=300s
```

---

## 6. API Inaccessible

### Symptom
API calls return connection refused or timeout.

### Root Causes
- API pod not running
- Network policy blocks access
- Security group blocks port 55000
- Manager not accessible from API

### Diagnosis
```bash
# Check API pod
kubectl get pods -n wazuh -l component=api
kubectl describe pod <api-pod> -n wazuh

# Check API service
kubectl get svc -n wazuh -l component=api

# Check connectivity
kubectl exec -it <api-pod> -n wazuh -- \
  curl -u admin:admin http://localhost:55000/api/version

# Test from another pod
kubectl exec -it <manager-pod> -n wazuh -- \
  curl -u admin:admin http://wazuh-api:55000/api/version

# Check firewall from API pod
kubectl exec -it <api-pod> -n wazuh -- ss -tlnp | grep 55000
```

### Solutions

**Solution 1: API Pod Not Running**
```bash
# Deploy API
kubectl apply -f wazuh-api.yaml

# Wait to be ready
kubectl wait --for=condition=ready pod -l component=api -n wazuh --timeout=300s

# Check logs
kubectl logs -n wazuh -l component=api
```

**Solution 2: Network Policy**
```bash
# Check if policy allows access
kubectl describe networkpolicy wazuh-api-network-policy -n wazuh

# Should allow ingress from dashboard and external on 55000
# If missing, restart API pod to register:
kubectl delete pod -n wazuh -l component=api
```

**Solution 3: Security Group**
```bash
# Check rule exists
aws ec2 describe-security-groups \
  --group-ids sg-xxxxx | grep -B2 -A2 55000

# Add if missing
aws ec2 authorize-security-group-ingress \
  --group-id sg-xxxxx \
  --protocol tcp \
  --port 55000 \
  --cidr 0.0.0.0/0
```

---

## 7. Persistent Storage Issues

### Symptom
Pods fail to start with "PVC not bound" error, or data is lost after restart.

### Root Causes
- PVC not created
- Storage class not available
- Node affinity issues
- Disk full

### Diagnosis
```bash
# Check PVCs
kubectl get pvc -n wazuh

# Check if bound (should show "Bound")
kubectl describe pvc wazuh-manager-data -n wazuh

# Check PVs
kubectl get pv

# Check storage class
kubectl get storageclass

# Check disk usage
kubectl exec -it <pod> -n wazuh -- df -h

# Check events for mount errors
kubectl describe pod <pod> -n wazuh
```

### Solutions

**Solution 1: PVC Not Created**
```bash
# Deploy PVCs
kubectl apply -f wazuh-pvc.yaml

# Verify
kubectl get pvc -n wazuh
kubectl get pv
```

**Solution 2: Storage Class Issue**
```bash
# Check if gp3 available (AWS)
kubectl get storageclass

# If not, create it:
kubectl apply -f - <<EOF
apiVersion: storage.k8s.io/v1
kind: StorageClass
metadata:
  name: gp3
provisioner: ebs.csi.aws.com
parameters:
  type: gp3
  iops: "3000"
  throughput: "125"
EOF
```

**Solution 3: Disk Full**
```bash
# Check usage
kubectl exec -it <pod> -n wazuh -- df -h

# If full, scale down or delete old data:
kubectl exec -it <manager-pod> -n wazuh -- \
  rm -rf /var/ossec/data/* 

# Or expand volume:
kubectl patch pvc wazuh-manager-data -n wazuh \
  -p '{"spec":{"resources":{"requests":{"storage":"20Gi"}}}}'
```

---

## 8. Terraform Security Group Apply Fails

### Symptom
`terraform apply` fails with permission denied or resource already exists.

### Root Causes
- IAM role lacks EC2 permissions
- Security group already exists (not in state)
- VPC doesn't exist

### Diagnosis
```bash
# Check what Terraform thinks exists
terraform state list | grep security

# Check actual AWS resources
aws ec2 describe-security-groups \
  --filters Name=tag:Name,Values=wazuh* \
  --query 'SecurityGroups[*].[GroupId,GroupName]'

# Check IAM permissions
aws sts get-caller-identity
```

### Solutions

**Solution 1: Import Existing Security Group**
```bash
# If SG already exists, import it
SG_ID=$(aws ec2 describe-security-groups \
  --filters Name=tag:Name,Values=wazuh \
  --query 'SecurityGroups[0].GroupId' \
  --output text)

terraform import aws_security_group.wazuh $SG_ID
```

**Solution 2: Fix IAM Permissions**
```bash
# Using AWS Academy LabRole, ensure it has:
# ec2:AuthorizeSecurityGroupIngress
# ec2:AuthorizeSecurityGroupEgress
# ec2:RevokeSecurityGroupIngress
# ec2:RevokeSecurityGroupEgress

# Check your role:
aws iam get-role --role-name LabRole
```

**Solution 3: VPC Variable Not Set**
```bash
# Ensure terraform.tfvars has VPC ID
cat terraform.tfvars | grep -E "vpc_id|create_oidc"

# Add if missing:
echo 'vpc_id = "vpc-xxxxx"' >> terraform.tfvars
terraform apply
```

---

## Quick Debug Checklist

```bash
# 🔍 Step-by-step debugging

# 1. Check all pods running
kubectl get pods -n wazuh

# 2. Check services
kubectl get svc -n wazuh

# 3. Check network policies
kubectl get networkpolicies -n wazuh

# 4. Test pod connectivity
POD=$(kubectl get pod -n wazuh -l component=manager -o name | head -1)
kubectl exec -it $POD -n wazuh -- curl http://wazuh-elasticsearch:9200

# 5. Check security group
aws ec2 describe-security-groups --group-ids sg-xxxxx

# 6. Check pod logs
kubectl logs -n wazuh -l component=manager | head -50

# 7. Check pod status
kubectl describe pod <pod-name> -n wazuh

# 8. Check events
kubectl get events -n wazuh --sort-by='.lastTimestamp'
```

---

## Support Resources

- Kubernetes: `kubectl logs`, `kubectl describe`, `kubectl exec`
- AWS: AWS CLI commands, AWS Console
- Wazuh: Container logs, ossec.conf, API endpoints
- Terraform: `terraform plan`, `terraform state`, `terraform show`