#!/bin/bash

# Deploy Wazuh agents on EKS worker nodes
# This script deploys Wazuh agents as a DaemonSet

set -e

echo "🚀 Deploying Wazuh agents on EKS worker nodes..."

# Colors
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

print_status() {
    echo -e "${GREEN}[INFO]${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}[WARNING]${NC} $1"
}

print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
}

# Check if kubectl is configured
if ! kubectl cluster-info >/dev/null 2>&1; then
    print_error "kubectl is not configured or cluster is not accessible"
    exit 1
fi

# Check if Wazuh manager is running
print_status "Checking Wazuh manager availability..."
if ! kubectl get deployment wazuh-manager -n wazuh >/dev/null 2>&1; then
    print_error "Wazuh manager is not deployed. Deploy Wazuh first."
    exit 1
fi

print_status "Deploying Wazuh agents as DaemonSet..."
kubectl apply -f wazuh-agent-daemonset.yaml

print_status "Waiting for agents to be deployed on all nodes..."
sleep 5

# Get node count
NODE_COUNT=$(kubectl get nodes --no-headers | wc -l)
print_status "EKS cluster has $NODE_COUNT nodes"

# Wait for agents to be ready
kubectl rollout status daemonset/wazuh-agent -n wazuh --timeout=300s

# Get pod count
AGENT_POD_COUNT=$(kubectl get pods -n wazuh -l component=agent --no-headers | wc -l)
print_status "Deployed $AGENT_POD_COUNT Wazuh agent pods"

print_status "🎉 Wazuh agents deployed successfully!"
print_status ""
print_status "📊 Agent Status:"
kubectl get pods -n wazuh -l component=agent -o wide

print_status ""
print_status "📝 Check agent logs:"
print_status "kubectl logs -f daemonset/wazuh-agent -n wazuh"

print_status ""
print_status "🔍 View registered agents in Wazuh Manager:"
print_status "kubectl exec -it deployment/wazuh-manager -n wazuh -- /var/ossec/bin/manage_agents -l"

print_status ""
print_status "💡 To view in dashboard:"
print_status "1. Open Wazuh Dashboard"
print_status "2. Go to Management > Agents"
print_status "3. You should see agents for each worker node"