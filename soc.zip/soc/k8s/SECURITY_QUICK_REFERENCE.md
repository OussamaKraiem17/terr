# Wazuh Security Quick Reference Card

## 📋 At a Glance

| Layer | Technology | File | Scope |
|-------|-----------|------|-------|
| **Container** | Kubernetes NetworkPolicies | `wazuh-network-policy.yaml` | Pod-to-pod traffic |
| **Node** | AWS Security Groups | `modules/wazuh-sg/` | EC2-level traffic |
| **Cluster** | EKS IAM Roles | `modules/eks/` | Service authentication |

---

## 🔒 Port Reference

### Kubernetes Internal Ports
```
1514/TCP   → Manager ← Agents (data)
1515/TCP   → Manager ← API (registration)
5601/TCP   → Dashboard ← External (web UI)
9200/TCP   → Elasticsearch ← Manager/Dashboard (HTTP API)
9300/TCP   → Elasticsearch ← Elasticsearch (node comms)
55000/TCP  → API ← Dashboard/External (REST API)
53/UDP     → All → CoreDNS (DNS)
```

### Storage Ports
```
2049/TCP   → EBS (if using NFS)
3260/TCP   → iSCSI (if using block devices)
```

---

## 🚀 Quick Deploy Commands

### 1. Deploy Infrastructure
```bash
cd /path/to/soc
terraform init
terraform apply
```

### 2. Deploy Kubernetes Resources
```bash
cd k8s
kubectl apply -f wazuh-namespace.yaml
kubectl apply -f wazuh-network-policy.yaml
kubectl apply -f wazuh-pvc.yaml
kubectl apply -f wazuh-elasticsearch.yaml
kubectl apply -f wazuh-manager.yaml
kubectl apply -f wazuh-api.yaml
kubectl apply -f wazuh-dashboard.yaml
kubectl apply -f wazuh-agent-daemonset.yaml
kubectl apply -f wazuh-ingress.yaml
```

### 3. Or Use Deployment Script
```bash
cd k8s
./deploy-wazuh.sh
```

---

## ✅ Verification Commands

### Infrastructure Ready?
```bash
# Check VPC
aws ec2 describe-vpcs --filters Name=tag:Name,Values=soc_vpc

# Check EKS cluster
aws eks list-clusters

# Check security group
aws ec2 describe-security-groups --filters Name=tag:Name,Values=wazuh
```

### Kubernetes Ready?
```bash
# Check cluster
kubectl cluster-info

# Check nodes
kubectl get nodes

# Check namespace
kubectl get namespace wazuh
```

### Wazuh Ready?
```bash
# Check pods
kubectl get pods -n wazuh

# Check services
kubectl get svc -n wazuh

# Check network policies
kubectl get networkpolicies -n wazuh

# Check PVCs
kubectl get pvc -n wazuh

# Check PVs
kubectl get pv
```

### Network Connectivity?
```bash
# Pod to pod
kubectl exec -it <pod> -n wazuh -- curl http://wazuh-elasticsearch:9200

# Pod to external
kubectl exec -it <pod> -n wazuh -- curl http://google.com

# DNS
kubectl exec -it <pod> -n wazuh -- nslookup wazuh-manager.wazuh.svc.cluster.local
```

---

## 🔧 Common Operations

### View Security Group Rules
```bash
# Get SG ID
SG=$(aws ec2 describe-security-groups \
  --filters Name=tag:Name,Values=wazuh \
  --query 'SecurityGroups[0].GroupId' \
  --output text)

# View rules
aws ec2 describe-security-groups --group-ids $SG

# View specific rules
aws ec2 describe-security-group-rules \
  --filters Name=group-id,Values=$SG
```

### View Network Policies
```bash
# List all
kubectl get networkpolicies -n wazuh

# View specific
kubectl describe networkpolicy wazuh-manager-network-policy -n wazuh

# Edit policy
kubectl edit networkpolicy wazuh-manager-network-policy -n wazuh
```

### View Pod Logs
```bash
# Current logs
kubectl logs -n wazuh <pod-name>

# Last 50 lines
kubectl logs -n wazuh <pod-name> --tail=50

# Streaming logs
kubectl logs -n wazuh <pod-name> -f

# Previous pod (if crashed)
kubectl logs -n wazuh <pod-name> --previous
```

### Access Dashboard
```bash
# Port forward
kubectl port-forward svc/wazuh-dashboard 5601:5601 -n wazuh

# Browser: http://localhost:5601
# Credentials: admin/admin
```

### Access API
```bash
# Port forward
kubectl port-forward svc/wazuh-api 55000:55000 -n wazuh

# Test
curl -u admin:admin http://localhost:55000/api/version
```

---

## ⚠️ Production Checklist

- [ ] Change default credentials (admin/admin → strong password)
- [ ] Restrict CIDR blocks: edit terraform.tfvars `wazuh_allowed_cidr_blocks`
- [ ] Enable TLS/HTTPS for dashboard and API
- [ ] Configure backup: run `backup-wazuh.sh` regularly
- [ ] Review network policies: `kubectl get networkpolicies -n wazuh`
- [ ] Review security group rules: run AWS CLI commands above
- [ ] Enable EKS logging: CloudWatch Logs for audit
- [ ] Enable EBS encryption: `encrypt_volumes = true` in Terraform
- [ ] Monitor resources: `kubectl top nodes`, `kubectl top pods -n wazuh`
- [ ] Regular backups: schedule `backup-wazuh.sh` with cron

---

## 🆘 Emergency Commands

### Force Delete Stuck Pod
```bash
kubectl delete pod <pod-name> -n wazuh --grace-period=0 --force
```

### Restart All Wazuh Pods
```bash
kubectl delete pods -n wazuh --all
```

### Clear Network Policies (CAUTION!)
```bash
kubectl delete networkpolicies -n wazuh --all
```

### Check What's Running
```bash
# All Wazuh resources
kubectl get all -n wazuh

# All persistent storage
kubectl get pvc,pv -n wazuh

# All network policies
kubectl get networkpolicies -n wazuh
```

### Jump Into Pod
```bash
kubectl exec -it <pod-name> -n wazuh -- /bin/bash
```

---

## 📊 Monitoring Commands

### Pod Resource Usage
```bash
# All pods
kubectl top pods -n wazuh

# Specific pod
kubectl top pod <pod-name> -n wazuh
```

### Node Resource Usage
```bash
kubectl top nodes
```

### Disk Usage
```bash
# From inside pod
kubectl exec -it <pod> -n wazuh -- df -h

# PVC usage
kubectl get pvc -n wazuh
```

### Event Log
```bash
# Recent events
kubectl get events -n wazuh --sort-by='.lastTimestamp'

# Watch events
kubectl get events -n wazuh -w
```

---

## 📞 Help Commands

```bash
# Describe resource
kubectl describe <resource-type> <name> -n wazuh

# Get detailed info
kubectl get <resource-type> <name> -o yaml -n wazuh

# Get last 100 lines of logs
kubectl logs -n wazuh <pod> --tail=100

# Get logs from all pods with label
kubectl logs -n wazuh -l component=manager

# Explain resource
kubectl explain <resource-type>

# Get API resources
kubectl api-resources
```

---

## 🔐 Security Quick Audit

### Check Credentials
```bash
# Find default credentials in configs
kubectl get cm -n wazuh -o yaml | grep -i password

# Find secrets
kubectl get secrets -n wazuh
```

### Check RBAC
```bash
# View roles
kubectl get roles -n wazuh
kubectl get clusterroles | grep wazuh

# View bindings
kubectl get rolebindings -n wazuh
kubectl get clusterrolebindings | grep wazuh
```

### Check Pod Security
```bash
# View pod security context
kubectl get pod <pod-name> -n wazuh -o yaml | grep -A10 securityContext

# Check running user
kubectl exec -it <pod> -n wazuh -- id
```

### Check Network Isolation
```bash
# List all policies
kubectl get networkpolicies -n wazuh

# Test if traffic is blocked
kubectl exec -it <pod1> -n wazuh -- curl http://<pod2-service>:<port>

# Check iptables (inside pod)
kubectl exec -it <pod> -n wazuh -- iptables -L
```

---

## 📂 File Locations

```
/path/to/soc/
├── main.tf
├── variables.tf
├── outputs.tf
├── terraform.tfvars
├── modules/
│   ├── vpc/
│   ├── eks/
│   └── wazuh-sg/
├── k8s/
│   ├── wazuh-namespace.yaml
│   ├── wazuh-network-policy.yaml
│   ├── wazuh-pvc.yaml
│   ├── wazuh-manager.yaml
│   ├── wazuh-elasticsearch.yaml
│   ├── wazuh-api.yaml
│   ├── wazuh-dashboard.yaml
│   ├── wazuh-agent-daemonset.yaml
│   ├── wazuh-ingress.yaml
│   ├── deploy-wazuh.sh
│   ├── deploy-wazuh-agents.sh
│   ├── backup-wazuh.sh
│   ├── README.md
│   ├── HOW_TO_RUN.md
│   ├── WAZUH_AGENTS.md
│   ├── SECURITY_CONFIGURATION.md
│   └── SECURITY_TROUBLESHOOTING.md
└── AWS_ACADEMY_SETUP.md
```

---

## 🎯 Default Credentials

⚠️ **CHANGE IMMEDIATELY IN PRODUCTION**

| Service | Username | Password |
|---------|----------|----------|
| Wazuh Dashboard | admin | admin |
| Wazuh API | admin | admin |
| Elasticsearch | elastic | elastic |

---

## 📞 Common Issues Quick Fixes

| Issue | Quick Fix |
|-------|----------|
| Pods not communicating | `kubectl describe networkpolicy -n wazuh` then edit if needed |
| Can't access dashboard | `kubectl port-forward svc/wazuh-dashboard 5601:5601 -n wazuh` |
| Manager can't reach ES | Check `kubectl logs -n wazuh -l component=manager` |
| Agents not registering | Check `kubectl logs -n wazuh -l component=agent` |
| Disk full | `kubectl exec -it <pod> -n wazuh -- df -h` |
| Pod won't start | `kubectl describe pod <pod> -n wazuh` |

---

## 🔗 Documentation Links

- [Kubernetes Documentation](https://kubernetes.io/docs/)
- [AWS EKS Documentation](https://docs.aws.amazon.com/eks/)
- [Wazuh Documentation](https://documentation.wazuh.com/)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest)
- This directory:
  - [SECURITY_CONFIGURATION.md](SECURITY_CONFIGURATION.md) - Detailed security setup
  - [SECURITY_TROUBLESHOOTING.md](SECURITY_TROUBLESHOOTING.md) - Troubleshooting guide
  - [HOW_TO_RUN.md](HOW_TO_RUN.md) - How to access and operate
  - [WAZUH_AGENTS.md](WAZUH_AGENTS.md) - Agent deployment guide