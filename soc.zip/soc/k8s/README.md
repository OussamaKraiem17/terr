# Wazuh Security Monitoring Deployment

This directory contains Kubernetes manifests for deploying Wazuh security monitoring platform in a dedicated namespace with proper tagging.

## 🏗️ Architecture

The deployment includes the following components:

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Wazuh Manager │    │   Wazuh API     │    │  Wazuh Dashboard│
│   (Core Engine) │◄──►│  (REST API)     │◄──►│   (Web UI)      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                        │
         └────────────────────────┼─────────────────────────────┐
                                  ▼                             │
                       ┌─────────────────┐                      │
                       │ Elasticsearch   │◄─────────────────────┘
                       │ (Data Storage)  │
                       └─────────────────┘
```

## 📁 Files

### Kubernetes Manifests
- `wazuh-namespace.yaml` - Creates dedicated `wazuh` namespace
- `wazuh-network-policy.yaml` - Kubernetes network policies (pod-level security)
- `wazuh-pvc.yaml` - Persistent Volume Claims for data persistence
- `wazuh-manager.yaml` - Wazuh manager deployment (core security engine)
- `wazuh-api.yaml` - Wazuh API deployment (REST endpoints)
- `wazuh-dashboard.yaml` - Wazuh dashboard (Kibana-based web interface)
- `wazuh-elasticsearch.yaml` - Elasticsearch for data indexing
- `wazuh-agent-daemonset.yaml` - Wazuh agents on worker nodes (DaemonSet)
- `wazuh-ingress.yaml` - Ingress and LoadBalancer services

### Deployment Scripts
- `deploy-wazuh.sh` - Automated deployment script
- `deploy-wazuh-agents.sh` - Agent deployment script
- `backup-wazuh.sh` - Data backup script

### Documentation
- `README.md` - This file (overview and architecture)
- `HOW_TO_RUN.md` - How to run and access Wazuh
- `WAZUH_AGENTS.md` - Wazuh agents guide (worker node monitoring)
- `SECURITY_CONFIGURATION.md` - **Detailed security setup and configuration** ⭐
- `SECURITY_TROUBLESHOOTING.md` - **Security troubleshooting guide** ⭐
- `SECURITY_QUICK_REFERENCE.md` - **Quick reference card for common operations** ⭐

## 🚀 Quick Deployment

### Prerequisites

1. **Kubernetes cluster** with kubectl configured
2. **AWS EKS cluster** (from Terraform deployment)
3. **kubectl configured** for your cluster:
   ```bash
   aws eks update-kubeconfig --region us-east-1 --name soc-eks-cluster
   ```

### Automated Deployment

```bash
cd k8s
chmod +x deploy-wazuh.sh
./deploy-wazuh.sh
```

### Manual Deployment

```bash
# Apply in order
kubectl apply -f wazuh-namespace.yaml
kubectl apply -f wazuh-elasticsearch.yaml
kubectl apply -f wazuh-manager.yaml
kubectl apply -f wazuh-api.yaml
kubectl apply -f wazuh-dashboard.yaml
kubectl apply -f wazuh-ingress.yaml
```

## 🔍 Access Information

### Dashboard Access

**Local Development (Ingress):**
- URL: `http://wazuh-dashboard.local`
- Add to `/etc/hosts`: `127.0.0.1 wazuh-dashboard.local`

**Cloud Environment (LoadBalancer):**
```bash
kubectl get service wazuh-dashboard-lb -n wazuh
```
Use the external IP from the output.

### API Access

**Internal URL:** `http://wazuh-api.wazuh.svc.cluster.local:55000`

### Default Credentials

- **Username:** `admin`
- **Password:** `admin`

⚠️ **Change these credentials immediately in production!**

## 📊 Monitoring Components

### Wazuh Manager
- **Purpose:** Core security engine, processes events and alerts
- **Ports:** 1514 (agent connections), 1515 (registration), 55000 (API)
- **Resources:** 512Mi-1Gi RAM, 500m-1000m CPU

### Wazuh API
- **Purpose:** REST API for Wazuh management
- **Port:** 55000
- **Resources:** 256Mi-512Mi RAM, 250m-500m CPU

### Wazuh Dashboard
- **Purpose:** Web-based user interface
- **Port:** 5601
- **Resources:** 512Mi-1Gi RAM, 250m-500m CPU

### Elasticsearch
- **Purpose:** Data indexing and storage
- **Ports:** 9200 (HTTP), 9300 (transport)
- **Resources:** 1Gi-2Gi RAM, 500m-1000m CPU

## 💾 Persistent Storage

The deployment includes Persistent Volume Claims (PVCs) for data persistence:

### Storage Configuration

- **Wazuh Manager Data:** 10Gi (security events, configurations)
- **Wazuh Manager Logs:** 5Gi (log files)
- **Elasticsearch Data:** 20Gi (indexed security data)

### Storage Class

Uses AWS EBS `gp3` storage class for optimal performance and cost.

### PVCs Created

```yaml
wazuh-manager-data     # Manager security data
wazuh-manager-logs     # Manager log files
wazuh-elasticsearch-data # Elasticsearch indexed data
```

### Benefits

- **Data Persistence:** Survives pod restarts and rescheduling
- **High Availability:** Data remains available during node failures
- **Backup Ready:** Persistent volumes can be backed up
- **Performance:** EBS gp3 provides consistent IOPS

## 🔧 Configuration

### Custom Configuration

Edit the ConfigMaps in each YAML file:

- `wazuh-manager-config` - Manager settings (`ossec.conf`)
- `wazuh-api-config` - API settings (`api.yaml`)
- `wazuh-dashboard-config` - Dashboard settings (`wazuh.yml`)
- `elasticsearch-config` - Elasticsearch settings (`elasticsearch.yml`)

### Storage Monitoring

```bash
# Check PVC status
kubectl get pvc -n wazuh

# Check PV status
kubectl get pv -n wazuh

# Monitor storage usage
kubectl describe pvc wazuh-elasticsearch-data -n wazuh
```

### Storage Scaling

To increase storage capacity:

1. **Edit PVC** (requires cluster admin):
   ```bash
   kubectl edit pvc wazuh-elasticsearch-data -n wazuh
   ```

2. **Update storage size** in the spec

3. **Restart pods** to pick up changes:
   ```bash
   kubectl rollout restart deployment/wazuh-elasticsearch -n wazuh
   ```

### Resource Limits

Modify resource requests/limits based on your cluster capacity:
```yaml
resources:
  requests:
    memory: "512Mi"
    cpu: "500m"
  limits:
    memory: "1Gi"
    cpu: "1000m"
```

## 📈 Health Checks

### Check Pod Status
```bash
kubectl get pods -n wazuh
```

### Check Services
```bash
kubectl get services -n wazuh
```

### View Logs
```bash
# Manager logs
kubectl logs -f deployment/wazuh-manager -n wazuh

# API logs
kubectl logs -f deployment/wazuh-api -n wazuh

# Dashboard logs
kubectl logs -f deployment/wazuh-dashboard -n wazuh

# Elasticsearch logs
kubectl logs -f deployment/wazuh-elasticsearch -n wazuh
```

## 🔒 Security

This deployment includes multiple layers of security controls. For complete security configuration details, refer to the dedicated security guides:

### Security Documentation

📖 **Read these guides for security details:**
- **[SECURITY_CONFIGURATION.md](SECURITY_CONFIGURATION.md)** - Kubernetes NetworkPolicies and AWS Security Groups setup
- **[SECURITY_TROUBLESHOOTING.md](SECURITY_TROUBLESHOOTING.md)** - Troubleshooting security-related issues
- **[SECURITY_QUICK_REFERENCE.md](SECURITY_QUICK_REFERENCE.md)** - Quick reference for security commands

### Security Layers

1. **Kubernetes Network Policies** (`wazuh-network-policy.yaml`)
   - Pod-to-pod traffic control
   - Granular ingress/egress rules per component
   - Internal communication only between necessary services

2. **AWS Security Groups** (`modules/wazuh-sg/`)
   - VPC-level traffic control
   - Restrict external access by IP/CIDR block
   - Separate rules for each component (manager, API, dashboard, Elasticsearch)

3. **IAM Roles and Policies**
   - EKS cluster role with necessary permissions
   - Node role for worker nodes
   - Optional OIDC provider for IRSA (AWS Academy compatible)

### Quick Security Hardening

Before production deployment:

1. **Update terraform.tfvars** - Restrict allowed CIDR blocks:
   ```hcl
   # Change from 0.0.0.0/0 to your IP/network
   wazuh_allowed_cidr_blocks = ["10.0.0.0/8", "YOUR.IP.ADDRESS/32"]
   ```

2. **Deploy Terraform** to apply security group rules:
   ```bash
   terraform apply
   ```

3. **Change default credentials:**
   ```bash
   # Update in kubernetes manifests or via API
   # Username: admin → your-username
   # Password: admin → strong-password
   ```

4. **Deploy with Network Policies:**
   ```bash
   ./deploy-wazuh.sh  # Includes network-policy.yaml
   ```

### Security Considerations

1. **✅ Persistent Storage:** Already configured with PVCs and encryption-ready
2. **✅ Network Isolation:** Kubernetes NetworkPolicies configured
3. **✅ Access Control:** AWS Security Groups with granular rules
4. **Change default passwords** (CRITICAL)
5. **Enable HTTPS/TLS** for dashboard and API
6. **Configure proper RBAC** for team access
7. **Restrict CIDR blocks** to known networks
8. **Enable audit logging** in EKS
9. **Regular backups** with `backup-wazuh.sh`
10. **Monitor network policies** and security group changes

### Production Security Checklist

- [ ] Changed default admin/admin credentials
- [ ] Restricted `wazuh_allowed_cidr_blocks` in terraform.tfvars
- [ ] Deployed Terraform security group rules
- [ ] Verified all NetworkPolicies are applied
- [ ] Enabled EKS control plane logging
- [ ] Configured TLS/HTTPS for dashboard
- [ ] Set up automated backups
- [ ] Reviewed storage encryption settings
- [ ] Implemented RBAC policies
- [ ] Scheduled security audits

## 🔄 Backup and Restore

### Automated Backup

```bash
# Run backup script
chmod +x backup-wazuh.sh
./backup-wazuh.sh
```

This creates compressed backups of:
- Wazuh Manager data and logs
- Elasticsearch indexed data

### Manual Backup

```bash
# Backup specific PVC data
kubectl cp wazuh/wazuh-manager-pod:/var/ossec/data ./backup/wazuh-data
kubectl cp wazuh/wazuh-elasticsearch-pod:/usr/share/elasticsearch/data ./backup/es-data
```

### Restore Process

1. **Scale down deployments:**
   ```bash
   kubectl scale deployment wazuh-manager -n wazuh --replicas=0
   kubectl scale deployment wazuh-elasticsearch -n wazuh --replicas=0
   ```

2. **Copy data back:**
   ```bash
   kubectl cp ./backup/wazuh-data wazuh/wazuh-manager-pod:/var/ossec/data
   kubectl cp ./backup/es-data wazuh/wazuh-elasticsearch-pod:/usr/share/elasticsearch/data
   ```

3. **Scale up deployments:**
   ```bash
   kubectl scale deployment wazuh-manager -n wazuh --replicas=1
   kubectl scale deployment wazuh-elasticsearch -n wazuh --replicas=1
   ```

## 📚 Additional Resources

- [Wazuh Documentation](https://documentation.wazuh.com/)
- [Wazuh Docker Images](https://hub.docker.com/u/wazuh)
- [Kubernetes Best Practices](https://kubernetes.io/docs/concepts/)

## 🆘 Troubleshooting

### Common Issues

1. **Pods not starting:** Check resource limits vs cluster capacity
2. **Services not accessible:** Verify namespace and service names
3. **Dashboard not loading:** Check Elasticsearch connectivity
4. **Agent registration failing:** Verify manager service is running

### Debug Commands

```bash
# Check pod events
kubectl describe pod <pod-name> -n wazuh

# Check service endpoints
kubectl get endpoints -n wazuh

# Test connectivity
kubectl exec -it <pod-name> -n wazuh -- curl http://wazuh-api:55000
```