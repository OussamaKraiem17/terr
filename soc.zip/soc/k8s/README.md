# Wazuh Security Monitoring Deployment

This directory contains Kubernetes manifests for deploying Wazuh security monitoring platform in a dedicated namespace with proper tagging.

## 🏗️ Architecture

The deployment includes the following components:

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Wazuh Manager │    │   Wazuh API     │    │  Wazuh Dashboard│
│   (Core Engine) │◄──►│  (REST API)     │◄──►│   (Web UI)      │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                        │
         └────────────────────────┼─────────────────────────────┐
                                  ▼                             │
                       ┌─────────────────┐                      │
                       │ Elasticsearch   │◄─────────────────────┘
                       │ (Data Storage)  │
                       └─────────────────┘
```

## 📁 Files

- `wazuh-namespace.yaml` - Creates dedicated `wazuh` namespace
- `wazuh-pvc.yaml` - Persistent Volume Claims for data persistence
- `wazuh-manager.yaml` - Wazuh manager deployment (core security engine)
- `wazuh-api.yaml` - Wazuh API deployment (REST endpoints)
- `wazuh-dashboard.yaml` - Wazuh dashboard (Kibana-based web interface)
- `wazuh-elasticsearch.yaml` - Elasticsearch for data indexing
- `wazuh-agent-daemonset.yaml` - Wazuh agents on worker nodes (DaemonSet)
- `wazuh-ingress.yaml` - Ingress and LoadBalancer services
- `deploy-wazuh.sh` - Automated deployment script
- `deploy-wazuh-agents.sh` - Agent deployment script
- `backup-wazuh.sh` - Data backup script
- `HOW_TO_RUN.md` - How to run and access Wazuh
- `WAZUH_AGENTS.md` - Wazuh agents guide (worker node monitoring)

## 🚀 Quick Deployment

### Prerequisites

1. **Kubernetes cluster** with kubectl configured
2. **AWS EKS cluster** (from Terraform deployment)
3. **kubectl configured** for your cluster:
   ```bash
   aws eks update-kubeconfig --region us-east-1 --name soc-eks-cluster
   ```

### Automated Deployment

```bash
cd k8s
chmod +x deploy-wazuh.sh
./deploy-wazuh.sh
```

### Manual Deployment

```bash
# Apply in order
kubectl apply -f wazuh-namespace.yaml
kubectl apply -f wazuh-elasticsearch.yaml
kubectl apply -f wazuh-manager.yaml
kubectl apply -f wazuh-api.yaml
kubectl apply -f wazuh-dashboard.yaml
kubectl apply -f wazuh-ingress.yaml
```

## 🔍 Access Information

### Dashboard Access

**Local Development (Ingress):**
- URL: `http://wazuh-dashboard.local`
- Add to `/etc/hosts`: `127.0.0.1 wazuh-dashboard.local`

**Cloud Environment (LoadBalancer):**
```bash
kubectl get service wazuh-dashboard-lb -n wazuh
```
Use the external IP from the output.

### API Access

**Internal URL:** `http://wazuh-api.wazuh.svc.cluster.local:55000`

### Default Credentials

- **Username:** `admin`
- **Password:** `admin`

⚠️ **Change these credentials immediately in production!**

## 📊 Monitoring Components

### Wazuh Manager
- **Purpose:** Core security engine, processes events and alerts
- **Ports:** 1514 (agent connections), 1515 (registration), 55000 (API)
- **Resources:** 512Mi-1Gi RAM, 500m-1000m CPU

### Wazuh API
- **Purpose:** REST API for Wazuh management
- **Port:** 55000
- **Resources:** 256Mi-512Mi RAM, 250m-500m CPU

### Wazuh Dashboard
- **Purpose:** Web-based user interface
- **Port:** 5601
- **Resources:** 512Mi-1Gi RAM, 250m-500m CPU

### Elasticsearch
- **Purpose:** Data indexing and storage
- **Ports:** 9200 (HTTP), 9300 (transport)
- **Resources:** 1Gi-2Gi RAM, 500m-1000m CPU

## 💾 Persistent Storage

The deployment includes Persistent Volume Claims (PVCs) for data persistence:

### Storage Configuration

- **Wazuh Manager Data:** 10Gi (security events, configurations)
- **Wazuh Manager Logs:** 5Gi (log files)
- **Elasticsearch Data:** 20Gi (indexed security data)

### Storage Class

Uses AWS EBS `gp3` storage class for optimal performance and cost.

### PVCs Created

```yaml
wazuh-manager-data     # Manager security data
wazuh-manager-logs     # Manager log files
wazuh-elasticsearch-data # Elasticsearch indexed data
```

### Benefits

- **Data Persistence:** Survives pod restarts and rescheduling
- **High Availability:** Data remains available during node failures
- **Backup Ready:** Persistent volumes can be backed up
- **Performance:** EBS gp3 provides consistent IOPS

## 🔧 Configuration

### Custom Configuration

Edit the ConfigMaps in each YAML file:

- `wazuh-manager-config` - Manager settings (`ossec.conf`)
- `wazuh-api-config` - API settings (`api.yaml`)
- `wazuh-dashboard-config` - Dashboard settings (`wazuh.yml`)
- `elasticsearch-config` - Elasticsearch settings (`elasticsearch.yml`)

### Storage Monitoring

```bash
# Check PVC status
kubectl get pvc -n wazuh

# Check PV status
kubectl get pv -n wazuh

# Monitor storage usage
kubectl describe pvc wazuh-elasticsearch-data -n wazuh
```

### Storage Scaling

To increase storage capacity:

1. **Edit PVC** (requires cluster admin):
   ```bash
   kubectl edit pvc wazuh-elasticsearch-data -n wazuh
   ```

2. **Update storage size** in the spec

3. **Restart pods** to pick up changes:
   ```bash
   kubectl rollout restart deployment/wazuh-elasticsearch -n wazuh
   ```

### Resource Limits

Modify resource requests/limits based on your cluster capacity:
```yaml
resources:
  requests:
    memory: "512Mi"
    cpu: "500m"
  limits:
    memory: "1Gi"
    cpu: "1000m"
```

## 📈 Health Checks

### Check Pod Status
```bash
kubectl get pods -n wazuh
```

### Check Services
```bash
kubectl get services -n wazuh
```

### View Logs
```bash
# Manager logs
kubectl logs -f deployment/wazuh-manager -n wazuh

# API logs
kubectl logs -f deployment/wazuh-api -n wazuh

# Dashboard logs
kubectl logs -f deployment/wazuh-dashboard -n wazuh

# Elasticsearch logs
kubectl logs -f deployment/wazuh-elasticsearch -n wazuh
```

## 🔒 Security Considerations

### Production Setup

1. **✅ Persistent Storage:** Already configured with PVCs
2. **Change default passwords**
3. **Enable HTTPS/TLS**
4. **Configure proper RBAC**
5. **Set up proper ingress** with SSL certificates
6. **Configure network policies**
7. **Enable authentication** and authorization

### Network Security

```yaml
# Example NetworkPolicy
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: wazuh-network-policy
  namespace: wazuh
spec:
  podSelector: {}
  policyTypes:
  - Ingress
  - Egress
  ingress:
  - from:
    - namespaceSelector:
        matchLabels:
          name: wazuh
  egress:
  - {}
```

## 🔄 Backup and Restore

### Automated Backup

```bash
# Run backup script
chmod +x backup-wazuh.sh
./backup-wazuh.sh
```

This creates compressed backups of:
- Wazuh Manager data and logs
- Elasticsearch indexed data

### Manual Backup

```bash
# Backup specific PVC data
kubectl cp wazuh/wazuh-manager-pod:/var/ossec/data ./backup/wazuh-data
kubectl cp wazuh/wazuh-elasticsearch-pod:/usr/share/elasticsearch/data ./backup/es-data
```

### Restore Process

1. **Scale down deployments:**
   ```bash
   kubectl scale deployment wazuh-manager -n wazuh --replicas=0
   kubectl scale deployment wazuh-elasticsearch -n wazuh --replicas=0
   ```

2. **Copy data back:**
   ```bash
   kubectl cp ./backup/wazuh-data wazuh/wazuh-manager-pod:/var/ossec/data
   kubectl cp ./backup/es-data wazuh/wazuh-elasticsearch-pod:/usr/share/elasticsearch/data
   ```

3. **Scale up deployments:**
   ```bash
   kubectl scale deployment wazuh-manager -n wazuh --replicas=1
   kubectl scale deployment wazuh-elasticsearch -n wazuh --replicas=1
   ```

## 📚 Additional Resources

- [Wazuh Documentation](https://documentation.wazuh.com/)
- [Wazuh Docker Images](https://hub.docker.com/u/wazuh)
- [Kubernetes Best Practices](https://kubernetes.io/docs/concepts/)

## 🆘 Troubleshooting

### Common Issues

1. **Pods not starting:** Check resource limits vs cluster capacity
2. **Services not accessible:** Verify namespace and service names
3. **Dashboard not loading:** Check Elasticsearch connectivity
4. **Agent registration failing:** Verify manager service is running

### Debug Commands

```bash
# Check pod events
kubectl describe pod <pod-name> -n wazuh

# Check service endpoints
kubectl get endpoints -n wazuh

# Test connectivity
kubectl exec -it <pod-name> -n wazuh -- curl http://wazuh-api:55000
```