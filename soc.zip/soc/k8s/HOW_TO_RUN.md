# How to Run Wazuh After Installation

## 1️⃣ Verify Deployment Status

### Check all pods are running:
```bash
kubectl get pods -n wazuh
```

Expected output:
```
NAME                                 READY   STATUS    RESTARTS   AGE
wazuh-manager-xxxxx                  1/1     Running   0          5m
wazuh-api-xxxxx                      1/1     Running   0          4m
wazuh-dashboard-xxxxx                1/1     Running   0          3m
wazuh-elasticsearch-xxxxx            1/1     Running   0          6m
```

### Check all services are running:
```bash
kubectl get services -n wazuh
```

Expected output:
```
NAME                     TYPE        CLUSTER-IP       EXTERNAL-IP   PORT(S)
wazuh-manager            ClusterIP   10.100.x.x       <none>        1514/TCP,1515/TCP,55000/TCP
wazuh-api                ClusterIP   10.100.x.x       <none>        55000/TCP
wazuh-dashboard          ClusterIP   10.100.x.x       <none>        5601/TCP
wazuh-elasticsearch      ClusterIP   10.100.x.x       <none>        9200/TCP,9300/TCP
wazuh-dashboard-lb       LoadBalancer 10.100.x.x      <EXTERNAL-IP> 80:xxxxx/TCP
```

---

## 2️⃣ Access Wazuh Dashboard

### Options:

#### Option A: Using LoadBalancer (AWS EKS)
```bash
# Get the external IP
kubectl get service wazuh-dashboard-lb -n wazuh -o wide

# Access in browser
http://<EXTERNAL-IP>
```

#### Option B: Using Port Forward
```bash
# Forward local port to dashboard
kubectl port-forward -n wazuh svc/wazuh-dashboard 5601:5601

# Access in browser
http://localhost:5601
```

#### Option C: Port Forward on Specific Interface
```bash
# Listen on all interfaces
kubectl port-forward -n wazuh svc/wazuh-dashboard 5601:5601 --address 0.0.0.0

# Access from remote machine
http://<YOUR-IP>:5601
```

### Login to Dashboard:
```
Default Credentials:
- Username: admin
- Password: admin
```

⚠️ **IMPORTANT:** Change these credentials immediately in production!

---

## 3️⃣ Access Wazuh API

### API Base URL (within cluster):
```
http://wazuh-api.wazuh.svc.cluster.local:55000
```

### For external access:
```bash
# Port forward the API
kubectl port-forward -n wazuh svc/wazuh-api 55000:55000

# API will be available at:
http://localhost:55000
```

### Test API Connection:
```bash
# From within a pod
kubectl exec -it <pod-name> -n wazuh -- bash
curl -u admin:admin http://wazuh-api:55000/api/version

# From your machine (with port-forward)
curl -u admin:admin http://localhost:55000/api/version
```

---

## 4️⃣ View Component Logs

### Manager Logs:
```bash
kubectl logs -f deployment/wazuh-manager -n wazuh
```

### API Logs:
```bash
kubectl logs -f deployment/wazuh-api -n wazuh
```

### Dashboard Logs:
```bash
kubectl logs -f deployment/wazuh-dashboard -n wazuh
```

### Elasticsearch Logs:
```bash
kubectl logs -f deployment/wazuh-elasticsearch -n wazuh
```

### Real-time logs for all pods:
```bash
kubectl logs -f -l app=wazuh -n wazuh --all-containers=true
```

---

## 5️⃣ Deploy Wazuh Agents

Agents collect security data from your systems and send it to the manager.

### Generate Agent Registration Key:

#### From Dashboard:
1. Login to Dashboard
2. Go to **Management** > **Agents**
3. Click **Deploy New Agent**
4. Select your OS (Linux, Windows, macOS)
5. Copy the registration key

#### Or using API:
```bash
# Get agents endpoint
kubectl exec -it <manager-pod> -n wazuh -- bash
/var/ossec/bin/manage_agents -l
```

### Install Agent on Linux:
```bash
# 1. Download agent
curl -s https://packages.wazuh.com/4.x/apt/pool/main/w/wazuh-agent/wazuh-agent_4.7.2-1_amd64.deb -o wazuh-agent.deb

# 2. Install
sudo dpkg -i wazuh-agent.deb

# 3. Register agent
sudo nano /var/ossec/etc/ossec.conf
# Update MANAGER_IP with wazuh-manager IP

# 4. Start agent
sudo systemctl start wazuh-agent
sudo systemctl enable wazuh-agent

# 5. Verify
sudo systemctl status wazuh-agent
```

### Install Agent on Windows:
```powershell
# 1. Download
Invoke-WebRequest -Uri "https://packages.wazuh.com/4.x/windows/wazuh-agent-4.7.2-1.msi" -OutFile "wazuh-agent.msi"

# 2. Install
.\wazuh-agent.msi /quiet WAZUH_MANAGER_IP="<MANAGER-IP>" WAZUH_REGISTRATION_SERVER="<MANAGER-IP>" WAZUH_AGENT_GROUP="windows"

# 3. Start service
net start WazuhSvc

# 4. Verify
Get-Service WazuhSvc
```

### Deploy Agent in Kubernetes Cluster:
See `wazuh-agent-k8s.yaml` for DaemonSet deployment

---

## 6️⃣ Monitor Security Events

### In Dashboard:
1. **Modules** > **Security Events** - View all security events
2. **Threat Detection** - View threats detected
3. **Compliance** > **PCI DSS**, **HIPAA**, **GDPR** - Compliance reports
4. **Integrity Monitoring** - File integrity alerts
5. **Vulnerabilities** - CVE information

### Via API:
```bash
# Get recent alerts
curl -s -u admin:admin http://localhost:55000/api/events?limit=10 | jq

# Get alerts by severity
curl -s -u admin:admin http://localhost:55000/api/events?rule.level=7 | jq

# Get alerts from specific agent
curl -s -u admin:admin http://localhost:55000/api/events?agent_id=001 | jq
```

---

## 7️⃣ Configure Alerts and Response

### Email Notifications:
Edit `wazuh-manager-config` ConfigMap:
```bash
kubectl edit configmap wazuh-manager-config -n wazuh
```

Update the `ossec.conf` section:
```xml
<email_notification>yes</email_notification>
<smtp_server>your-smtp-server.com</smtp_server>
<email_from>wazuh@example.com</email_from>
<email_to>admin@example.com</email_to>
<email_alert_level>5</email_alert_level>
```

### Active Response:
Configure automatic responses to threats:
```xml
<active-response>
  <command>restart-ossec</command>
  <location>local</location>
  <rules_id>1002</rules_id>
</active-response>
```

---

## 8️⃣ Backup and Maintenance

### Daily Backup:
```bash
# Schedule backup (Linux)
0 2 * * * /path/to/backup-wazuh.sh

# Or manually
./backup-wazuh.sh
```

### Check Storage:
```bash
kubectl get pvc -n wazuh

# Monitor storage usage
kubectl top nodes -n wazuh
kubectl top pods -n wazuh
```

### Update Configuration:
```bash
# Edit manager config
kubectl edit configmap wazuh-manager-config -n wazuh

# Restart manager pod to apply changes
kubectl rollout restart deployment/wazuh-manager -n wazuh
```

---

## 9️⃣ Troubleshooting

### Pods not running:
```bash
# Check pod events
kubectl describe pod <pod-name> -n wazuh

# Restart all pods
kubectl rollout restart deployment -n wazuh
```

### Can't connect to dashboard:
```bash
# Check if service is running
kubectl get service wazuh-dashboard -n wazuh

# Check pod logs
kubectl logs -f pod/<dashboard-pod> -n wazuh

# Test connectivity
kubectl exec -it <any-pod> -n wazuh -- curl http://wazuh-dashboard:5601
```

### Manager not receiving agent data:
1. Check agent registration: Dashboard > Management > Agents
2. Verify manager port (1514) is open: `kubectl get svc wazuh-manager -n wazuh`
3. Check manager logs: `kubectl logs -f deployment/wazuh-manager -n wazuh`
4. Verify agent connectivity: `curl -v telnet://wazuh-manager:1514`

### Storage full:
```bash
# Expand PVC
kubectl patch pvc wazuh-elasticsearch-data -n wazuh -p '{"spec":{"resources":{"requests":{"storage":"50Gi"}}}}'

# Or delete old indices
kubectl exec -it <elasticsearch-pod> -n wazuh -- bash
curl -X DELETE "localhost:9200/wazuh-alerts-*"
```

---

## 🔟 Performance Tuning

### For high-volume environments:

1. **Increase Manager Resources:**
```bash
# Edit resources in wazuh-manager.yaml
kubectl set resources deployment wazuh-manager -n wazuh --limits=cpu=2,memory=2Gi --requests=cpu=1,memory=1Gi
```

2. **Scale Elasticsearch:**
```bash
# Edit replicas in wazuh-elasticsearch.yaml
kubectl scale deployment wazuh-elasticsearch -n wazuh --replicas=3
```

3. **Adjust Alerts Threshold:**
Edit ConfigMap and increase `email_alert_level` to reduce noise

---

## 📋 Quick Reference Commands

```bash
# Check status
kubectl get pods -n wazuh
kubectl get svc -n wazuh

# Access dashboard
kubectl port-forward svc/wazuh-dashboard 5601:5601 -n wazuh

# Access API
kubectl port-forward svc/wazuh-api 55000:55000 -n wazuh

# View logs
kubectl logs -f deployment/wazuh-manager -n wazuh

# Backup data
./backup-wazuh.sh

# Restart services
kubectl rollout restart deployment -n wazuh

# Remove everything
kubectl delete namespace wazuh
```

---

## 🎯 Next Steps

1. ✅ Verify all pods are running
2. ✅ Access the dashboard
3. ✅ Change default credentials
4. ✅ Install agents on servers
5. ✅ Configure alerts and responses
6. ✅ Set up regular backups
7. ✅ Monitor and tune performance