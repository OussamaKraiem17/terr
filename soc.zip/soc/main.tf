terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Environment = var.environment
      Project     = var.project_name
      ManagedBy   = "Terraform"
    }
  }
}

# VPC Module
module "vpc" {
  source = "./modules/vpc"

  vpc_name              = var.vpc_name
  vpc_cidr              = var.vpc_cidr
  public_subnet_cidrs   = var.public_subnet_cidrs
  private_subnet_cidrs  = var.private_subnet_cidrs
  cluster_name          = var.cluster_name
}

# EKS Module
module "eks" {
  source = "./modules/eks"

  cluster_name           = var.cluster_name
  kubernetes_version     = var.kubernetes_version
  public_subnet_ids      = module.vpc.public_subnet_ids
  private_subnet_ids     = module.vpc.private_subnet_ids
  security_group_id      = module.vpc.security_group_id
  desired_worker_nodes   = var.desired_worker_nodes
  min_worker_nodes       = var.min_worker_nodes
  max_worker_nodes       = var.max_worker_nodes
  worker_instance_type   = var.worker_instance_type
  worker_disk_size       = var.worker_disk_size
  cluster_role_arn       = var.cluster_role_arn
  node_role_arn          = var.node_role_arn
  create_oidc_provider   = var.create_oidc_provider
}

# Wazuh Security Group Module
module "wazuh_security_group" {
  source = "./modules/wazuh-sg"

  vpc_id                      = module.vpc.vpc_id
  cluster_security_group_id   = module.vpc.security_group_id
  environment                 = var.environment
  allowed_cidr_blocks         = var.wazuh_allowed_cidr_blocks
  tags = {
    app       = "wazuh"
    component = "security"
  }
}

# Wazuh Module
module "wazuh" {
  source = "./modules/wazuh"

  depends_on = [module.eks]

  cluster_name                    = var.cluster_name
  wazuh_version                   = var.wazuh_version
  wazuh_username                  = var.wazuh_username
  wazuh_password                  = var.wazuh_password
  elasticsearch_memory_limit      = var.elasticsearch_memory_limit
  elasticsearch_memory_request    = var.elasticsearch_memory_request
  manager_memory_limit            = var.manager_memory_limit
  manager_memory_request          = var.manager_memory_request
  api_memory_limit                = var.api_memory_limit
  api_memory_request              = var.api_memory_request
  dashboard_memory_limit          = var.dashboard_memory_limit
  dashboard_memory_request        = var.dashboard_memory_request
  elasticsearch_storage_size      = var.elasticsearch_storage_size
  manager_data_storage_size       = var.manager_data_storage_size
  manager_logs_storage_size       = var.manager_logs_storage_size
  dashboard_service_type          = var.dashboard_service_type
  enable_persistence              = var.enable_persistence
  storage_class_name              = var.storage_class_name
}
