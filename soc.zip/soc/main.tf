terraform {
  required_version = ">= 1.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Environment = var.environment
      Project     = var.project_name
      ManagedBy   = "Terraform"
    }
  }
}

# VPC Module
module "vpc" {
  source = "./modules/vpc"

  vpc_name              = var.vpc_name
  vpc_cidr              = var.vpc_cidr
  public_subnet_cidrs   = var.public_subnet_cidrs
  private_subnet_cidrs  = var.private_subnet_cidrs
  cluster_name          = var.cluster_name
}

# EKS Module
module "eks" {
  source = "./modules/eks"

  cluster_name           = var.cluster_name
  kubernetes_version     = var.kubernetes_version
  public_subnet_ids      = module.vpc.public_subnet_ids
  private_subnet_ids     = module.vpc.private_subnet_ids
  security_group_id      = module.vpc.security_group_id
  desired_worker_nodes   = var.desired_worker_nodes
  min_worker_nodes       = var.min_worker_nodes
  max_worker_nodes       = var.max_worker_nodes
  worker_instance_type   = var.worker_instance_type
  worker_disk_size       = var.worker_disk_size
  cluster_role_arn       = var.cluster_role_arn
  node_role_arn          = var.node_role_arn
  create_oidc_provider   = var.create_oidc_provider
}

# Deploy Wazuh after EKS cluster is ready
resource "null_resource" "deploy_wazuh" {
  depends_on = [module.eks]

  provisioner "local-exec" {
    command = "./deploy_wazuh.sh"
  }
}
