# AWS Academy - Finding Your IAM Role ARNs

## Step 1: Log into AWS Academy Console

1. Go to your AWS Academy Lab dashboard
2. Click **AWS Details** or **Get Started**
3. Copy your **AWS Access Key ID** and **Secret Access Key**
4. Click **Open AWS Console**

## Step 2: Find Your IAM Roles

In the AWS Console:

1. Go to **IAM** > **Roles**
2. Search for roles with these patterns:
   - `voclabs` (most common in AWS Academy labs)
   - `LabRole`
   - Your account-specific role
   - Look for roles that allow EC2 and EKS operations

## Step 3: Get the Role ARN

For each role (cluster and node):
1. Click on the role name
2. Copy the **ARN** from the top (format: `arn:aws:iam::ACCOUNT-ID:role/ROLE-NAME`)

## Step 4: Update terraform.tfvars

Replace the ARNs in your terraform.tfvars:

```hcl
cluster_role_arn = "arn:aws:iam::533267173701:role/YOUR_CLUSTER_ROLE"
node_role_arn    = "arn:aws:iam::533267173701:role/YOUR_NODE_ROLE"
```

## Common AWS Academy Roles

If you see these roles, use them:
- **Cluster Role:** `voclabs-LabRole` or similar
- **Node Role:** Often the same role can be used for both

## Example terraform.tfvars for AWS Academy

```hcl
aws_region            = "us-east-1"
environment           = "dev"
project_name          = "soc"
vpc_name              = "soc_vpc"
vpc_cidr              = "10.0.0.0/16"
public_subnet_cidrs   = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
private_subnet_cidrs  = ["10.0.11.0/24", "10.0.12.0/24", "10.0.13.0/24"]
cluster_name          = "soc-eks-cluster"
kubernetes_version    = "1.29"
desired_worker_nodes  = 3
min_worker_nodes      = 3
max_worker_nodes      = 6
worker_instance_type  = "t3.medium"
worker_disk_size      = 30
cluster_role_arn      = "arn:aws:iam::YOUR_ACCOUNT_ID:role/YOUR_CLUSTER_ROLE"
node_role_arn         = "arn:aws:iam::YOUR_ACCOUNT_ID:role/YOUR_NODE_ROLE"
```

## If You Can't Find Pre-existing Roles

Contact your lab instructor or:
1. Check AWS Academy documentation for available roles
2. Ask for EC2FullAccess and EKSFullAccess permissions
3. Some labs may provide a role in the CloudFormation stack that was launched

## Testing Your Configuration

Once you have the ARNs:
1. Update `terraform.tfvars` with your role ARNs
2. Run `terraform validate`
3. Run `terraform plan` to verify before applying
4. Run `terraform apply` when ready
