# SOC Infrastructure - AWS VPC and EKS Cluster

This Terraform configuration creates an AWS infrastructure with:
- **VPC** named `soc_vpc` with public and private subnets across 3 availability zones
- **EKS Cluster** with 3 worker nodes and AWS-managed Kubernetes control plane
- **NAT Gateways** for outbound traffic from private subnets
- **Security Groups** for cluster communication
- **OIDC Provider** for IAM Roles for Service Accounts (IRSA)

## Architecture

```
┌─────────────────────────────────────────┐
│         AWS VPC (10.0.0.0/16)           │
├─────────────────────────────────────────┤
│                                         │
│  Public Subnets      Private Subnets   │
│  ┌──────────────┐    ┌──────────────┐  │
│  │ 10.0.1.0/24  │    │ 10.0.11.0/24 │  │
│  │   NAT GW 1   │    │  Worker 1    │  │
│  └──────────────┘    └──────────────┘  │
│                                         │
│  ┌──────────────┐    ┌──────────────┐  │
│  │ 10.0.2.0/24  │    │ 10.0.12.0/24 │  │
│  │   NAT GW 2   │    │  Worker 2    │  │
│  └──────────────┘    └──────────────┘  │
│                                         │
│  ┌──────────────┐    ┌──────────────┐  │
│  │ 10.0.3.0/24  │    │ 10.0.13.0/24 │  │
│  │   NAT GW 3   │    │  Worker 3    │  │
│  └──────────────┘    └──────────────┘  │
│                                         │
│        Internet Gateway                 │
│                                         │
└─────────────────────────────────────────┘
         │
         │ EKS Cluster (Managed Control Plane)
         │
      ┌──────────────────┐
      │  Kubernetes API  │
      │    (Managed)     │
      └──────────────────┘
```

## Prerequisites

1. **AWS Account** with appropriate permissions
2. **Terraform** >= 1.0 installed
3. **AWS CLI** configured with credentials
4. **kubectl** installed (for accessing the cluster)

## Files Description

- **main.tf** - Provider configuration and module calls
- **modules/vpc/main.tf** - VPC, subnets, internet gateway, NAT gateways, and route tables
- **modules/vpc/variables.tf** - VPC module input variables
- **modules/vpc/outputs.tf** - VPC module outputs
- **modules/eks/main.tf** - EKS cluster, node groups, IAM roles, and OIDC provider
- **modules/eks/variables.tf** - EKS module input variables
- **modules/eks/outputs.tf** - EKS module outputs
- **variables.tf** - Root input variable definitions
- **terraform.tfvars** - Variable values
- **outputs.tf** - Root output values for cluster access

## Configuration

### Project Structure

```
.
├── main.tf                    # Provider config and module calls
├── variables.tf              # Root variables
├── outputs.tf                # Root outputs
├── terraform.tfvars          # Variable values
├── README.md
├── .gitignore
└── modules/
    ├── vpc/                  # VPC Module
    │   ├── main.tf
    │   ├── variables.tf
    │   └── outputs.tf
    └── eks/                  # EKS Module
        ├── main.tf
        ├── variables.tf
        └── outputs.tf
```

### Modular Architecture

The infrastructure is organized into reusable modules:

#### VPC Module (`modules/vpc/`)
Manages all networking components:
- VPC with configurable CIDR
- Public subnets for NAT and load balancers
- Private subnets for EKS worker nodes
- Internet Gateway for public traffic
- NAT Gateways for private subnet internet access
- Route tables and associations
- Security group for cluster communication

#### EKS Module (`modules/eks/`)
Manages Kubernetes infrastructure:
- EKS cluster with managed control plane
- Worker node groups with configurable scaling
- IAM roles and policies for cluster and nodes
- OIDC provider for IAM Roles for Service Accounts (IRSA)
- Cluster logging (API, audit, authenticator, etc.)

### Default Values (in terraform.tfvars)

| Variable | Default Value |
|----------|---------------|
| AWS Region | us-east-1 |
| Environment | dev |
| VPC Name | soc_vpc |
| VPC CIDR | 10.0.0.0/16 |
| Cluster Name | soc-eks-cluster |
| Kubernetes Version | 1.29 |
| Worker Nodes | 3 (desired/min) |
| Max Worker Nodes | 6 |
| Worker Instance Type | t3.medium |
| Worker Disk Size | 30 GiB |

### Modify Configuration

Edit `terraform.tfvars` to customize:
- AWS region
- VPC and subnet CIDR blocks
- Cluster name
- Kubernetes version
- Worker node count and instance type

## Usage

### 1. Initialize Terraform

```bash
terraform init
```

This downloads required providers and initializes the backend.

### 2. Plan Deployment

```bash
terraform plan -out=tfplan
```

Review the planned changes before applying.

### 3. Apply Configuration

```bash
terraform apply tfplan
```

Or without saving the plan:

```bash
terraform apply
```

The infrastructure will take approximately 10-15 minutes to create.

### 4. Configure kubectl

After deployment, configure kubectl to access your cluster:

```bash
aws eks update-kubeconfig --region us-east-1 --name soc-eks-cluster
```

Or use the output from Terraform:

```bash
$(terraform output -raw configure_kubectl)
```

### 5. Verify Cluster Access

```bash
kubectl get nodes
kubectl get pods --all-namespaces
```

## Outputs

After applying the configuration, Terraform outputs:

- **vpc_id** - VPC identifier
- **cluster_name** - EKS cluster name
- **cluster_endpoint** - Kubernetes API endpoint
- **cluster_arn** - EKS cluster ARN
- **configure_kubectl** - Command to configure kubectl
- **oidc_provider_arn** - OIDC provider for IRSA

View outputs:

```bash
terraform output
```

## Cleanup

To destroy all infrastructure:

```bash
terraform destroy
```

Review the resources to be deleted, then confirm with `yes`.

**Warning:** This will delete all resources including the EKS cluster and VPC. Make sure to back up any important data first.

## Cost Estimation

Approximate monthly costs (us-east-1, on-demand):
- 3 t3.medium EC2 instances: ~$60
- NAT Gateways (3): ~$32
- Data transfer: ~$7
- EKS cluster: $0.10/hour (~$73/month)
- Elastic IPs: ~$3

**Total: ~$175-200/month** (varies by usage)

Use `terraform plan` to estimate costs more accurately with tools like Infracost.

## Security Considerations

1. **Endpoint Access** - Both public and private endpoints are enabled. Consider disabling public endpoint in production.
2. **Security Groups** - Review and restrict inbound/outbound rules as needed.
3. **IAM Roles** - Use least privilege principle for service account permissions.
4. **Logging** - EKS control plane logging is enabled (API, audit, authenticator, controllerManager, scheduler).
5. **Network Policies** - Implement Kubernetes network policies for pod-to-pod communication.

## Troubleshooting

### Cluster creation timeout
- Check IAM permissions for the AWS account
- Verify VPC and subnet configuration
- Check CloudFormation events in AWS console

### kubectl connection errors
```bash
# Verify cluster endpoint
terraform output cluster_endpoint

# Check security groups allow port 443
aws ec2 describe-security-groups --group-ids <sg-id>
```

### Nodes not joining cluster
- Check node IAM role policies
- Verify subnet and security group configuration
- Check EC2 instance logs in Systems Manager Session Manager

## Additional Resources

- [AWS EKS Documentation](https://docs.aws.amazon.com/eks/)
- [Terraform AWS Provider](https://registry.terraform.io/providers/hashicorp/aws/latest/docs)
- [Kubernetes Documentation](https://kubernetes.io/docs/)

## Support

For issues or questions:
1. Check AWS CloudFormation events in the console
2. Review Terraform logs: `TF_LOG=DEBUG terraform apply`
3. Verify AWS credentials and permissions
