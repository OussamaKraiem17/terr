output "vpc_id" {
  description = "VPC ID"
  value       = module.vpc.vpc_id
}

output "vpc_cidr" {
  description = "VPC CIDR block"
  value       = module.vpc.vpc_cidr
}

output "public_subnet_ids" {
  description = "List of public subnet IDs"
  value       = module.vpc.public_subnet_ids
}

output "private_subnet_ids" {
  description = "List of private subnet IDs"
  value       = module.vpc.private_subnet_ids
}

output "cluster_name" {
  description = "EKS Cluster name"
  value       = module.eks.cluster_name
}

output "cluster_endpoint" {
  description = "EKS Cluster API endpoint"
  value       = module.eks.cluster_endpoint
}

output "cluster_version" {
  description = "EKS Cluster version"
  value       = module.eks.cluster_version
}

output "cluster_arn" {
  description = "EKS Cluster ARN"
  value       = module.eks.cluster_arn
}

output "cluster_certificate_authority_data" {
  description = "Base64 encoded certificate data required to communicate with the cluster"
  value       = module.eks.cluster_certificate_authority_data
  sensitive   = true
}

output "node_group_id" {
  description = "Node Group ID"
  value       = module.eks.node_group_id
}

# Wazuh Outputs
output "wazuh_namespace" {
  description = "Wazuh namespace name"
  value       = module.wazuh.namespace
}

output "wazuh_dashboard_url" {
  description = "Wazuh dashboard URL"
  value       = module.wazuh.dashboard_url
}

output "wazuh_api_url" {
  description = "Wazuh API URL"
  value       = module.wazuh.api_url
}

output "wazuh_manager_url" {
  description = "Wazuh manager URL"
  value       = module.wazuh.manager_url
}

output "wazuh_elasticsearch_url" {
  description = "Elasticsearch URL"
  value       = module.wazuh.elasticsearch_url
}

output "wazuh_dashboard_credentials" {
  description = "Wazuh dashboard login credentials"
  value       = module.wazuh.dashboard_credentials
  sensitive   = true
}

output "wazuh_persistent_volume_claims" {
  description = "List of created Wazuh PVCs"
  value       = module.wazuh.persistent_volume_claims
}

output "wazuh_deployments" {
  description = "List of created Wazuh deployments"
  value       = module.wazuh.deployments
}

output "wazuh_services" {
  description = "List of created Wazuh services"
  value       = module.wazuh.services
}

output "node_group_arn" {
  description = "Node Group ARN"
  value       = module.eks.node_group_arn
}

output "oidc_provider_arn" {
  description = "OIDC Provider ARN for IRSA"
  value       = module.eks.oidc_provider_arn
}

output "configure_kubectl" {
  description = "Command to configure kubectl"
  value       = "aws eks update-kubeconfig --region ${var.aws_region} --name ${module.eks.cluster_name}"
}

output "wazuh_security_group_id" {
  description = "Wazuh security group ID"
  value       = module.wazuh_security_group.wazuh_security_group_id
}

output "wazuh_security_group_name" {
  description = "Wazuh security group name"
  value       = module.wazuh_security_group.wazuh_security_group_name
}
