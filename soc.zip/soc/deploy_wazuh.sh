#!/bin/bash

# Wazuh Deployment Automation Script for EKS
# This script automates the deployment of Wazuh on an existing EKS cluster.
# Run this after 'terraform apply' has successfully created the EKS cluster.
# Prerequisites: kubectl configured, git installed, EKS cluster active.

set -e  # Exit on any error

# Variables
WAZUH_VERSION="v4.14.4"
REPO_URL="https://github.com/wazuh/wazuh-kubernetes.git"
CLONE_DIR="wazuh-kubernetes"
NAMESPACE="wazuh"

echo "Starting Wazuh deployment on EKS..."

# Step 1: Clone the repository
if [ ! -d "$CLONE_DIR" ]; then
    echo "Cloning Wazuh Kubernetes repository..."
    git clone "$REPO_URL" -b "$WAZUH_VERSION" --depth=1 "$CLONE_DIR"
else
    echo "Repository already cloned. Pulling latest changes..."
    cd "$CLONE_DIR"
    git pull
    cd ..
fi

cd "$CLONE_DIR"

# Step 2: Generate SSL certificates
echo "Generating SSL certificates..."
./wazuh/certs/indexer_cluster/generate_certs.sh
./wazuh/certs/dashboard_http/generate_certs.sh

# Step 3: Check storage class (optional, but log it)
echo "Checking storage class..."
kubectl get sc

# Step 4: Deploy Wazuh using Kustomize for EKS
echo "Deploying Wazuh to EKS..."
kubectl apply -k envs/eks/

# Step 5: Wait for deployment to be ready
echo "Waiting for Wazuh components to be ready..."
kubectl wait --for=condition=available --timeout=600s deployment/wazuh-dashboard -n "$NAMESPACE"
kubectl wait --for=condition=ready pod --selector=app=wazuh-indexer --timeout=600s -n "$NAMESPACE"
kubectl wait --for=condition=ready pod --selector=app=wazuh-manager --timeout=600s -n "$NAMESPACE"

# Step 6: Verify deployment
echo "Verifying deployment..."
kubectl get namespaces | grep "$NAMESPACE"
kubectl get services -n "$NAMESPACE"
kubectl get deployments -n "$NAMESPACE"
kubectl get statefulsets -n "$NAMESPACE"
kubectl get pods -n "$NAMESPACE"

# Step 7: Get access information
echo "Retrieving access information..."
DASHBOARD_IP=$(kubectl get svc dashboard -n "$NAMESPACE" -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
if [ -z "$DASHBOARD_IP" ]; then
    DASHBOARD_IP=$(kubectl get svc dashboard -n "$NAMESPACE" -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
fi

WAZUH_IP=$(kubectl get svc wazuh -n "$NAMESPACE" -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
if [ -z "$WAZUH_IP" ]; then
    WAZUH_IP=$(kubectl get svc wazuh -n "$NAMESPACE" -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
fi

WAZUH_WORKERS_IP=$(kubectl get svc wazuh-workers -n "$NAMESPACE" -o jsonpath='{.status.loadBalancer.ingress[0].hostname}')
if [ -z "$WAZUH_WORKERS_IP" ]; then
    WAZUH_WORKERS_IP=$(kubectl get svc wazuh-workers -n "$NAMESPACE" -o jsonpath='{.status.loadBalancer.ingress[0].ip}')
fi

echo ""
echo "Wazuh deployment completed successfully!"
echo "Access the Wazuh Dashboard at: https://$DASHBOARD_IP"
echo "Default credentials: admin / SecretPassword"
echo ""
echo "For agent enrollment:"
echo "  WAZUH_MANAGER: $WAZUH_WORKERS_IP"
echo "  WAZUH_REGISTRATION_SERVER: $WAZUH_IP"
echo "  WAZUH_REGISTRATION_PASSWORD: password"
echo ""
echo "Note: It may take a few minutes for LoadBalancer IPs to be assigned."

cd ..
echo "Script completed."