variable "namespace" {
  description = "Kubernetes namespace for Wazuh deployment"
  type        = string
  default     = "wazuh"
}

variable "storage_class" {
  description = "Storage class for persistent volumes"
  type        = string
  default     = "gp3"
}

# Storage sizes
variable "manager_data_storage" {
  description = "Storage size for Wazuh manager data"
  type        = string
  default     = "10Gi"
}

variable "manager_logs_storage" {
  description = "Storage size for Wazuh manager logs"
  type        = string
  default     = "5Gi"
}

variable "elasticsearch_storage" {
  description = "Storage size for Elasticsearch data"
  type        = string
  default     = "20Gi"
}

# Docker images
variable "wazuh_manager_image" {
  description = "Docker image for Wazuh manager"
  type        = string
  default     = "wazuh/wazuh-manager:4.7.2"
}

variable "wazuh_api_image" {
  description = "Docker image for Wazuh API"
  type        = string
  default     = "wazuh/wazuh-api:4.7.2"
}

variable "wazuh_dashboard_image" {
  description = "Docker image for Wazuh dashboard"
  type        = string
  default     = "wazuh/wazuh-dashboard:4.7.2"
}

# Authentication
variable "wazuh_username" {
  description = "Wazuh dashboard username"
  type        = string
  default     = "admin"
}

variable "wazuh_password" {
  description = "Wazuh dashboard password"
  type        = string
  default     = "admin"
  sensitive   = true
}

# Replicas
variable "elasticsearch_replicas" {
  description = "Number of Elasticsearch replicas"
  type        = number
  default     = 1
}

variable "manager_replicas" {
  description = "Number of Wazuh manager replicas"
  type        = number
  default     = 1
}

variable "api_replicas" {
  description = "Number of Wazuh API replicas"
  type        = number
  default     = 1
}

variable "dashboard_replicas" {
  description = "Number of Wazuh dashboard replicas"
  type        = number
  default     = 1
}

# Resource limits - Elasticsearch
variable "elasticsearch_memory_request" {
  description = "Elasticsearch memory request"
  type        = string
  default     = "1Gi"
}

variable "elasticsearch_memory_limit" {
  description = "Elasticsearch memory limit"
  type        = string
  default     = "2Gi"
}

variable "elasticsearch_cpu_request" {
  description = "Elasticsearch CPU request"
  type        = string
  default     = "500m"
}

variable "elasticsearch_cpu_limit" {
  description = "Elasticsearch CPU limit"
  type        = string
  default     = "1000m"
}

# Resource limits - Manager
variable "manager_memory_request" {
  description = "Wazuh manager memory request"
  type        = string
  default     = "512Mi"
}

variable "manager_memory_limit" {
  description = "Wazuh manager memory limit"
  type        = string
  default     = "1Gi"
}

variable "manager_cpu_request" {
  description = "Wazuh manager CPU request"
  type        = string
  default     = "500m"
}

variable "manager_cpu_limit" {
  description = "Wazuh manager CPU limit"
  type        = string
  default     = "1000m"
}

# Resource limits - API
variable "api_memory_request" {
  description = "Wazuh API memory request"
  type        = string
  default     = "256Mi"
}

variable "api_memory_limit" {
  description = "Wazuh API memory limit"
  type        = string
  default     = "512Mi"
}

variable "api_cpu_request" {
  description = "Wazuh API CPU request"
  type        = string
  default     = "250m"
}

variable "api_cpu_limit" {
  description = "Wazuh API CPU limit"
  type        = string
  default     = "500m"
}

# Resource limits - Dashboard
variable "dashboard_memory_request" {
  description = "Wazuh dashboard memory request"
  type        = string
  default     = "512Mi"
}

variable "dashboard_memory_limit" {
  description = "Wazuh dashboard memory limit"
  type        = string
  default     = "1Gi"
}

variable "dashboard_cpu_request" {
  description = "Wazuh dashboard CPU request"
  type        = string
  default     = "250m"
}

variable "dashboard_cpu_limit" {
  description = "Wazuh dashboard CPU limit"
  type        = string
  default     = "500m"
}

# Service configuration
variable "dashboard_service_type" {
  description = "Service type for Wazuh dashboard (LoadBalancer or ClusterIP)"
  type        = string
  default     = "LoadBalancer"
}

# Dependencies
variable "depends_on_eks" {
  description = "Dependency on EKS cluster"
  type        = any
  default     = null
}