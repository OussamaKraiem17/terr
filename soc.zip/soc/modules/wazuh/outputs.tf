output "namespace" {
  description = "Wazuh namespace name"
  value       = kubernetes_namespace.wazuh.metadata[0].name
}

output "dashboard_url" {
  description = "Wazuh dashboard URL"
  value       = var.dashboard_service_type == "LoadBalancer" ? "http://${kubernetes_service.wazuh_dashboard.status[0].load_balancer[0].ingress[0].hostname}:80" : "http://wazuh-dashboard.${kubernetes_namespace.wazuh.metadata[0].name}.svc.cluster.local:80"
}

output "api_url" {
  description = "Wazuh API URL"
  value       = "http://wazuh-api.${kubernetes_namespace.wazuh.metadata[0].name}.svc.cluster.local:55000"
}

output "manager_url" {
  description = "Wazuh manager URL"
  value       = "wazuh-manager.${kubernetes_namespace.wazuh.metadata[0].name}.svc.cluster.local:1514"
}

output "elasticsearch_url" {
  description = "Elasticsearch URL"
  value       = "http://wazuh-elasticsearch.${kubernetes_namespace.wazuh.metadata[0].name}.svc.cluster.local:9200"
}

output "dashboard_credentials" {
  description = "Wazuh dashboard login credentials"
  value = {
    username = var.wazuh_username
    password = var.wazuh_password
  }
  sensitive = true
}

output "persistent_volume_claims" {
  description = "List of created PVCs"
  value = [
    kubernetes_persistent_volume_claim.wazuh_manager_data.metadata[0].name,
    kubernetes_persistent_volume_claim.wazuh_manager_logs.metadata[0].name,
    kubernetes_persistent_volume_claim.wazuh_elasticsearch_data.metadata[0].name
  ]
}

output "deployments" {
  description = "List of created deployments"
  value = [
    kubernetes_deployment.wazuh_elasticsearch.metadata[0].name,
    kubernetes_deployment.wazuh_manager.metadata[0].name,
    kubernetes_deployment.wazuh_api.metadata[0].name,
    kubernetes_deployment.wazuh_dashboard.metadata[0].name
  ]
}

output "services" {
  description = "List of created services"
  value = [
    kubernetes_service.wazuh_elasticsearch.metadata[0].name,
    kubernetes_service.wazuh_manager.metadata[0].name,
    kubernetes_service.wazuh_api.metadata[0].name,
    kubernetes_service.wazuh_dashboard.metadata[0].name
  ]
}