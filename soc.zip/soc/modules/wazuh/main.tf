# Wazuh Kubernetes Deployment Module
# This module deploys Wazuh security monitoring platform to Kubernetes

terraform {
  required_providers {
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.0"
    }
  }
}

# Namespace
resource "kubernetes_namespace" "wazuh" {
  metadata {
    name = var.namespace
    labels = {
      name = "wazuh"
      app  = "wazuh"
    }
  }
}

# PVCs for persistent storage
resource "kubernetes_persistent_volume_claim" "wazuh_manager_data" {
  metadata {
    name      = "wazuh-manager-data"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "manager"
    }
  }
  spec {
    access_modes = ["ReadWriteOnce"]
    resources {
      requests = {
        storage = var.manager_data_storage
      }
    }
    storage_class_name = var.storage_class
  }
  depends_on = [kubernetes_namespace.wazuh]
}

resource "kubernetes_persistent_volume_claim" "wazuh_manager_logs" {
  metadata {
    name      = "wazuh-manager-logs"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "manager"
    }
  }
  spec {
    access_modes = ["ReadWriteOnce"]
    resources {
      requests = {
        storage = var.manager_logs_storage
      }
    }
    storage_class_name = var.storage_class
  }
  depends_on = [kubernetes_namespace.wazuh]
}

resource "kubernetes_persistent_volume_claim" "wazuh_elasticsearch_data" {
  metadata {
    name      = "wazuh-elasticsearch-data"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "elasticsearch"
    }
  }
  spec {
    access_modes = ["ReadWriteOnce"]
    resources {
      requests = {
        storage = var.elasticsearch_storage
      }
    }
    storage_class_name = var.storage_class
  }
  depends_on = [kubernetes_namespace.wazuh]
}

# ConfigMaps
resource "kubernetes_config_map" "wazuh_manager_config" {
  metadata {
    name      = "wazuh-manager-config"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "manager"
    }
  }

  data = {
    "ossec.conf" = file("${path.module}/../../../k8s/wazuh-manager.yaml")
  }

  depends_on = [kubernetes_namespace.wazuh]
}

resource "kubernetes_config_map" "wazuh_api_config" {
  metadata {
    name      = "wazuh-api-config"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "api"
    }
  }

  data = {
    "api.yaml" = <<EOF
host: "0.0.0.0"
port: 55000
https: "no"
https_key: "api/configuration/ssl/server.key"
https_cert: "api/configuration/ssl/server.crt"
https_use_ca: "False"
https_ca: "api/configuration/ssl/ca.crt"
logging:
  level: "info"
  path: "logs/api.log"
cors:
  enabled: "no"
  source_route: "*"
  expose_headers: "*"
  allow_headers: "*"
  allow_credentials: "False"
cache:
  enabled: "yes"
  time: 0.750
access:
  max_login_attempts: 5
  block_time: 300
  max_request_per_minute: 300
use_only_authd: "False"
drop_privileges: "True"
experimental_features: "False"
EOF
  }

  depends_on = [kubernetes_namespace.wazuh]
}

resource "kubernetes_config_map" "elasticsearch_config" {
  metadata {
    name      = "elasticsearch-config"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "elasticsearch"
    }
  }

  data = {
    "elasticsearch.yml" = <<EOF
cluster.name: wazuh-cluster
node.name: wazuh-elasticsearch
path.data: /usr/share/elasticsearch/data
path.logs: /usr/share/elasticsearch/logs
network.host: 0.0.0.0
http.port: 9200
discovery.type: single-node
xpack.security.enabled: false
xpack.monitoring.enabled: false
xpack.graph.enabled: false
xpack.watcher.enabled: false
xpack.ml.enabled: false
EOF
  }

  depends_on = [kubernetes_namespace.wazuh]
}

resource "kubernetes_config_map" "wazuh_dashboard_config" {
  metadata {
    name      = "wazuh-dashboard-config"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "dashboard"
    }
  }

  data = {
    "wazuh.yml" = <<EOF
hosts:
  - default:
      url: "http://wazuh-manager:55000"
      port: 55000
      username: "${var.wazuh_username}"
      password: "${var.wazuh_password}"
      run_as: false
EOF
  }

  depends_on = [kubernetes_namespace.wazuh]
}

# Deployments
resource "kubernetes_deployment" "wazuh_elasticsearch" {
  metadata {
    name      = "wazuh-elasticsearch"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "elasticsearch"
    }
  }

  spec {
    replicas = var.elasticsearch_replicas

    selector {
      match_labels = {
        app       = "wazuh"
        component = "elasticsearch"
      }
    }

    template {
      metadata {
        labels = {
          app       = "wazuh"
          component = "elasticsearch"
        }
      }

      spec {
        container {
          name  = "elasticsearch"
          image = "docker.elastic.co/elasticsearch/elasticsearch:7.17.9"

          port {
            container_port = 9200
            name           = "http"
          }

          port {
            container_port = 9300
            name           = "transport"
          }

          env {
            name  = "ES_JAVA_OPTS"
            value = "-Xms512m -Xmx512m"
          }

          env {
            name  = "discovery.type"
            value = "single-node"
          }

          env {
            name  = "xpack.security.enabled"
            value = "false"
          }

          volume_mount {
            name       = "config"
            mount_path = "/usr/share/elasticsearch/config/elasticsearch.yml"
            sub_path   = "elasticsearch.yml"
          }

          volume_mount {
            name       = "data"
            mount_path = "/usr/share/elasticsearch/data"
          }

          resources {
            requests = {
              memory = var.elasticsearch_memory_request
              cpu    = var.elasticsearch_cpu_request
            }
            limits = {
              memory = var.elasticsearch_memory_limit
              cpu    = var.elasticsearch_cpu_limit
            }
          }

          security_context {
            run_as_user  = 1000
            run_as_group = 1000
          }
        }

        volume {
          name = "config"
          config_map {
            name = kubernetes_config_map.elasticsearch_config.metadata[0].name
          }
        }

        volume {
          name = "data"
          persistent_volume_claim {
            claim_name = kubernetes_persistent_volume_claim.wazuh_elasticsearch_data.metadata[0].name
          }
        }
      }
    }
  }

  depends_on = [
    kubernetes_persistent_volume_claim.wazuh_elasticsearch_data,
    kubernetes_config_map.elasticsearch_config
  ]
}

resource "kubernetes_deployment" "wazuh_manager" {
  metadata {
    name      = "wazuh-manager"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "manager"
    }
  }

  spec {
    replicas = var.manager_replicas

    selector {
      match_labels = {
        app       = "wazuh"
        component = "manager"
      }
    }

    template {
      metadata {
        labels = {
          app       = "wazuh"
          component = "manager"
        }
      }

      spec {
        container {
          name  = "wazuh-manager"
          image = var.wazuh_manager_image

          port {
            container_port = 1514
            name           = "agent-connection"
          }

          port {
            container_port = 1515
            name           = "registration"
          }

          port {
            container_port = 55000
            name           = "api"
          }

          volume_mount {
            name       = "config"
            mount_path = "/var/ossec/etc/ossec.conf"
            sub_path   = "ossec.conf"
          }

          volume_mount {
            name       = "data"
            mount_path = "/var/ossec/data"
          }

          volume_mount {
            name       = "logs"
            mount_path = "/var/ossec/logs"
          }

          volume_mount {
            name       = "etc"
            mount_path = "/var/ossec/etc"
          }

          resources {
            requests = {
              memory = var.manager_memory_request
              cpu    = var.manager_cpu_request
            }
            limits = {
              memory = var.manager_memory_limit
              cpu    = var.manager_cpu_limit
            }
          }

          security_context {
            privileged = true
          }
        }

        volume {
          name = "config"
          config_map {
            name = kubernetes_config_map.wazuh_manager_config.metadata[0].name
          }
        }

        volume {
          name = "data"
          persistent_volume_claim {
            claim_name = kubernetes_persistent_volume_claim.wazuh_manager_data.metadata[0].name
          }
        }

        volume {
          name = "logs"
          persistent_volume_claim {
            claim_name = kubernetes_persistent_volume_claim.wazuh_manager_logs.metadata[0].name
          }
        }

        volume {
          name = "etc"
          empty_dir {}
        }
      }
    }
  }

  depends_on = [
    kubernetes_persistent_volume_claim.wazuh_manager_data,
    kubernetes_persistent_volume_claim.wazuh_manager_logs,
    kubernetes_config_map.wazuh_manager_config,
    kubernetes_deployment.wazuh_elasticsearch
  ]
}

resource "kubernetes_deployment" "wazuh_api" {
  metadata {
    name      = "wazuh-api"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "api"
    }
  }

  spec {
    replicas = var.api_replicas

    selector {
      match_labels = {
        app       = "wazuh"
        component = "api"
      }
    }

    template {
      metadata {
        labels = {
          app       = "wazuh"
          component = "api"
        }
      }

      spec {
        container {
          name  = "wazuh-api"
          image = var.wazuh_api_image

          port {
            container_port = 55000
            name           = "api"
          }

          env {
            name  = "WAZUH_MANAGER_HOST"
            value = "wazuh-manager"
          }

          volume_mount {
            name       = "config"
            mount_path = "/var/ossec/api/configuration/api.yaml"
            sub_path   = "api.yaml"
          }

          resources {
            requests = {
              memory = var.api_memory_request
              cpu    = var.api_cpu_request
            }
            limits = {
              memory = var.api_memory_limit
              cpu    = var.api_cpu_limit
            }
          }
        }

        volume {
          name = "config"
          config_map {
            name = kubernetes_config_map.wazuh_api_config.metadata[0].name
          }
        }
      }
    }
  }

  depends_on = [
    kubernetes_config_map.wazuh_api_config,
    kubernetes_deployment.wazuh_manager
  ]
}

resource "kubernetes_deployment" "wazuh_dashboard" {
  metadata {
    name      = "wazuh-dashboard"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "dashboard"
    }
  }

  spec {
    replicas = var.dashboard_replicas

    selector {
      match_labels = {
        app       = "wazuh"
        component = "dashboard"
      }
    }

    template {
      metadata {
        labels = {
          app       = "wazuh"
          component = "dashboard"
        }
      }

      spec {
        container {
          name  = "wazuh-dashboard"
          image = var.wazuh_dashboard_image

          port {
            container_port = 5601
            name           = "dashboard"
          }

          env {
            name  = "ELASTICSEARCH_HOSTS"
            value = "http://wazuh-elasticsearch:9200"
          }

          env {
            name  = "WAZUH_API_URL"
            value = "http://wazuh-api:55000"
          }

          volume_mount {
            name       = "config"
            mount_path = "/usr/share/wazuh-dashboard/config/wazuh.yml"
            sub_path   = "wazuh.yml"
          }

          resources {
            requests = {
              memory = var.dashboard_memory_request
              cpu    = var.dashboard_cpu_request
            }
            limits = {
              memory = var.dashboard_memory_limit
              cpu    = var.dashboard_cpu_limit
            }
          }
        }

        volume {
          name = "config"
          config_map {
            name = kubernetes_config_map.wazuh_dashboard_config.metadata[0].name
          }
        }
      }
    }
  }

  depends_on = [
    kubernetes_config_map.wazuh_dashboard_config,
    kubernetes_deployment.wazuh_api,
    kubernetes_deployment.wazuh_elasticsearch
  ]
}

# Services
resource "kubernetes_service" "wazuh_elasticsearch" {
  metadata {
    name      = "wazuh-elasticsearch"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "elasticsearch"
    }
  }

  spec {
    selector = {
      app       = "wazuh"
      component = "elasticsearch"
    }

    port {
      name        = "http"
      port        = 9200
      target_port = 9200
    }

    port {
      name        = "transport"
      port        = 9300
      target_port = 9300
    }

    type = "ClusterIP"
  }

  depends_on = [kubernetes_deployment.wazuh_elasticsearch]
}

resource "kubernetes_service" "wazuh_manager" {
  metadata {
    name      = "wazuh-manager"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "manager"
    }
  }

  spec {
    selector = {
      app       = "wazuh"
      component = "manager"
    }

    port {
      name        = "agent-connection"
      port        = 1514
      target_port = 1514
    }

    port {
      name        = "registration"
      port        = 1515
      target_port = 1515
    }

    port {
      name        = "api"
      port        = 55000
      target_port = 55000
    }

    type = "ClusterIP"
  }

  depends_on = [kubernetes_deployment.wazuh_manager]
}

resource "kubernetes_service" "wazuh_api" {
  metadata {
    name      = "wazuh-api"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "api"
    }
  }

  spec {
    selector = {
      app       = "wazuh"
      component = "api"
    }

    port {
      name        = "api"
      port        = 55000
      target_port = 55000
    }

    type = "ClusterIP"
  }

  depends_on = [kubernetes_deployment.wazuh_api]
}

resource "kubernetes_service" "wazuh_dashboard" {
  metadata {
    name      = "wazuh-dashboard"
    namespace = kubernetes_namespace.wazuh.metadata[0].name
    labels = {
      app       = "wazuh"
      component = "dashboard"
    }
  }

  spec {
    selector = {
      app       = "wazuh"
      component = "dashboard"
    }

    port {
      name        = "dashboard"
      port        = 80
      target_port = 5601
    }

    type = var.dashboard_service_type
  }

  depends_on = [kubernetes_deployment.wazuh_dashboard]
}