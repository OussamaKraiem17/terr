output "cluster_name" {
  description = "EKS Cluster name"
  value       = local.cluster_exists ? data.aws_eks_cluster.existing[0].name : aws_eks_cluster.main[0].name
}

output "cluster_endpoint" {
  description = "EKS Cluster API endpoint"
  value       = local.cluster_exists ? data.aws_eks_cluster.existing[0].endpoint : aws_eks_cluster.main[0].endpoint
}

output "cluster_version" {
  description = "EKS Cluster version"
  value       = local.cluster_exists ? data.aws_eks_cluster.existing[0].version : aws_eks_cluster.main[0].version
}

output "cluster_arn" {
  description = "EKS Cluster ARN"
  value       = local.cluster_exists ? data.aws_eks_cluster.existing[0].arn : aws_eks_cluster.main[0].arn
}

output "cluster_certificate_authority_data" {
  description = "Base64 encoded certificate data required to communicate with the cluster"
  value       = local.cluster_exists ? data.aws_eks_cluster.existing[0].certificate_authority[0].data : aws_eks_cluster.main[0].certificate_authority[0].data
  sensitive   = true
}

output "node_group_id" {
  description = "Node Group ID"
  value       = local.cluster_exists ? "" : aws_eks_node_group.workers[0].id
}

output "node_group_arn" {
  description = "Node Group ARN"
  value       = local.cluster_exists ? "" : aws_eks_node_group.workers[0].arn
}

output "oidc_provider_arn" {
  description = "OIDC Provider ARN for IRSA (empty if not created)"
  value       = var.create_oidc_provider && !local.cluster_exists ? aws_iam_openid_connect_provider.cluster[0].arn : (local.cluster_exists ? "" : "")
}
