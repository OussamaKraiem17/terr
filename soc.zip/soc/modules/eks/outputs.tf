output "cluster_name" {
  description = "EKS Cluster name"
  value       = aws_eks_cluster.main.name
}

output "cluster_endpoint" {
  description = "EKS Cluster API endpoint"
  value       = aws_eks_cluster.main.endpoint
}

output "cluster_version" {
  description = "EKS Cluster version"
  value       = aws_eks_cluster.main.version
}

output "cluster_arn" {
  description = "EKS Cluster ARN"
  value       = aws_eks_cluster.main.arn
}

output "cluster_certificate_authority_data" {
  description = "Base64 encoded certificate data required to communicate with the cluster"
  value       = aws_eks_cluster.main.certificate_authority[0].data
  sensitive   = true
}

output "node_group_id" {
  description = "Node Group ID"
  value       = aws_eks_node_group.workers.id
}

output "node_group_arn" {
  description = "Node Group ARN"
  value       = aws_eks_node_group.workers.arn
}

output "oidc_provider_arn" {
  description = "OIDC Provider ARN for IRSA (empty if not created)"
  value       = var.create_oidc_provider ? aws_iam_openid_connect_provider.cluster[0].arn : ""
}
