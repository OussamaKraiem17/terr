variable "cluster_name" {
  description = "EKS Cluster name"
  type        = string
}

variable "kubernetes_version" {
  description = "Kubernetes version to use for the EKS cluster"
  type        = string
}

variable "public_subnet_ids" {
  description = "List of public subnet IDs"
  type        = list(string)
}

variable "private_subnet_ids" {
  description = "List of private subnet IDs"
  type        = list(string)
}

variable "security_group_id" {
  description = "Security group ID for EKS cluster"
  type        = string
}

variable "desired_worker_nodes" {
  description = "Desired number of worker nodes"
  type        = number
}

variable "min_worker_nodes" {
  description = "Minimum number of worker nodes"
  type        = number
}

variable "max_worker_nodes" {
  description = "Maximum number of worker nodes"
  type        = number
}

variable "worker_instance_type" {
  description = "EC2 instance type for worker nodes"
  type        = string
}

variable "worker_disk_size" {
  description = "Disk size in GiB for worker nodes"
  type        = number
}

variable "cluster_role_arn" {
  description = "ARN of IAM role for EKS cluster (optional - leave empty to create new role)"
  type        = string
  default     = ""
}

variable "node_role_arn" {
  description = "ARN of IAM role for EKS worker nodes (optional - leave empty to create new role)"
  type        = string
  default     = ""
}

variable "create_oidc_provider" {
  description = "Whether to create OIDC provider for IRSA (IAM Roles for Service Accounts). Set to false for AWS Academy labs."
  type        = bool
  default     = true
}
