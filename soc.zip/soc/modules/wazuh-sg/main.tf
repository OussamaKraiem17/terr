# Security Group for Wazuh components
# This security group allows communication between Wazuh pods and external access

resource "aws_security_group" "wazuh" {
  name        = "wazuh-sg-${var.environment}"
  description = "Security group for Wazuh security monitoring platform"
  vpc_id      = var.vpc_id

  tags = merge(
    var.tags,
    {
      Name = "wazuh-sg-${var.environment}"
    }
  )
}

# Allow all internal traffic within the security group
resource "aws_security_group_rule" "wazuh_internal_ingress" {
  type              = "ingress"
  from_port         = 0
  to_port           = 65535
  protocol          = "tcp"
  self              = true
  security_group_id = aws_security_group.wazuh.id
  description       = "Allow all internal Wazuh component communication"
}

# Wazuh Manager - Agent connections (1514)
resource "aws_security_group_rule" "wazuh_agent_data" {
  type                     = "ingress"
  from_port                = 1514
  to_port                  = 1514
  protocol                 = "tcp"
  security_group_id        = aws_security_group.wazuh.id
  source_security_group_id = var.cluster_security_group_id
  description              = "Wazuh Manager - Agent data collection port"
}

# Wazuh Manager - Agent registration (1515)
resource "aws_security_group_rule" "wazuh_agent_registration" {
  type                     = "ingress"
  from_port                = 1515
  to_port                  = 1515
  protocol                 = "tcp"
  security_group_id        = aws_security_group.wazuh.id
  source_security_group_id = var.cluster_security_group_id
  description              = "Wazuh Manager - Agent registration port"
}

# Wazuh API (55000) - External access
resource "aws_security_group_rule" "wazuh_api_external" {
  type              = "ingress"
  from_port         = 55000
  to_port           = 55000
  protocol          = "tcp"
  cidr_blocks       = var.allowed_cidr_blocks
  security_group_id = aws_security_group.wazuh.id
  description       = "Wazuh API - External access (modify allowed_cidr_blocks in production)"
}

# Wazuh API (55000) - Internal cluster access
resource "aws_security_group_rule" "wazuh_api_internal" {
  type                     = "ingress"
  from_port                = 55000
  to_port                  = 55000
  protocol                 = "tcp"
  security_group_id        = aws_security_group.wazuh.id
  source_security_group_id = var.cluster_security_group_id
  description              = "Wazuh API - Internal cluster access"
}

# Wazuh Dashboard (5601) - External access
resource "aws_security_group_rule" "wazuh_dashboard_external" {
  type              = "ingress"
  from_port         = 5601
  to_port           = 5601
  protocol          = "tcp"
  cidr_blocks       = var.allowed_cidr_blocks
  security_group_id = aws_security_group.wazuh.id
  description       = "Wazuh Dashboard - External access (modify allowed_cidr_blocks in production)"
}

# Elasticsearch HTTP (9200) - Internal only
resource "aws_security_group_rule" "wazuh_elasticsearch_http" {
  type                     = "ingress"
  from_port                = 9200
  to_port                  = 9200
  protocol                 = "tcp"
  security_group_id        = aws_security_group.wazuh.id
  source_security_group_id = var.cluster_security_group_id
  description              = "Elasticsearch - HTTP API (internal only)"
}

# Elasticsearch Transport (9300) - Internal only
resource "aws_security_group_rule" "wazuh_elasticsearch_transport" {
  type                     = "ingress"
  from_port                = 9300
  to_port                  = 9300
  protocol                 = "tcp"
  security_group_id        = aws_security_group.wazuh.id
  source_security_group_id = var.cluster_security_group_id
  description              = "Elasticsearch - Node communication (internal only)"
}

# SSH for debugging (optional - restrict to specific IPs)
resource "aws_security_group_rule" "wazuh_ssh" {
  type              = "ingress"
  from_port         = 22
  to_port           = 22
  protocol          = "tcp"
  cidr_blocks       = ["0.0.0.0/0"]  # CHANGE THIS in production
  security_group_id = aws_security_group.wazuh.id
  description       = "SSH access - CHANGE THIS in production"
}

# Allow all outbound traffic
resource "aws_security_group_rule" "wazuh_egress_all" {
  type              = "egress"
  from_port         = 0
  to_port           = 0
  protocol          = "-1"
  cidr_blocks       = ["0.0.0.0/0"]
  security_group_id = aws_security_group.wazuh.id
  description       = "Allow all outbound traffic"
}