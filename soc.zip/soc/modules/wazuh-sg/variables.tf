variable "vpc_id" {
  description = "VPC ID where EKS cluster is deployed"
  type        = string
}

variable "cluster_security_group_id" {
  description = "EKS cluster security group ID"
  type        = string
}

variable "environment" {
  description = "Environment name"
  type        = string
  default     = "dev"
}

variable "allowed_cidr_blocks" {
  description = "CIDR blocks allowed for external access to Wazuh API and Dashboard"
  type        = list(string)
  default     = ["0.0.0.0/0"]  # Change to specific IPs in production
}

variable "tags" {
  description = "Tags to apply to security groups"
  type        = map(string)
  default = {
    app = "wazuh"
  }
}