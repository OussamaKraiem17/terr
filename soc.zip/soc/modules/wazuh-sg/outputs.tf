output "wazuh_security_group_id" {
  description = "Wazuh security group ID"
  value       = aws_security_group.wazuh.id
}

output "wazuh_security_group_arn" {
  description = "Wazuh security group ARN"
  value       = aws_security_group.wazuh.arn
}

output "wazuh_security_group_name" {
  description = "Wazuh security group name"
  value       = aws_security_group.wazuh.name
}