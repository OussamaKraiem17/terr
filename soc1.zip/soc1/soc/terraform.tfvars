aws_region            = "us-east-1"
environment           = "dev"
project_name          = "soc"
vpc_name              = "soc_vpc"
vpc_cidr              = "10.0.0.0/16"
public_subnet_cidrs   = ["10.0.1.0/24", "10.0.2.0/24", "10.0.3.0/24"]
private_subnet_cidrs  = ["10.0.11.0/24", "10.0.12.0/24", "10.0.13.0/24"]
cluster_name          = "soc-eks-cluster"
kubernetes_version    = "1.29"
desired_worker_nodes  = 3
min_worker_nodes      = 3
max_worker_nodes      = 6
worker_instance_type  = "t3.medium"
worker_disk_size      = 30

# AWS Academy Labs: Add your IAM role ARNs below
# Leave empty ("") to create new roles (requires IAM permissions)
# See AWS_ACADEMY_SETUP.md for instructions to find your role ARNs
cluster_role_arn      = "arn:aws:iam::366298399297:role/LabRole"  # Example: "arn:aws:iam::533267173701:role/voclabs-LabRole"
node_role_arn         = "arn:aws:iam::366298399297:role/LabRole"  # Example: "arn:aws:iam::533267173701:role/voclabs-LabRole"

# AWS Academy Labs: Set to false to skip OIDC provider creation (requires IAM permissions)
create_oidc_provider  = false

