###############################################################################
#  modules/vpc_pme/main.tf
#  VPC segmenté : 3 subnets (Management public, SOC privé, Workplace privé)
#  + IGW, NAT Gateway, NLB, VPC Flow Logs
###############################################################################

locals {
  azs = ["${var.aws_region}a", "${var.aws_region}b", "${var.aws_region}c"]
}

# ─────────────────────────────────────────────────────────────────────────────
# 1. VPC
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_vpc" "vpc" {
  cidr_block           = var.vpc_cidr
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = { Name = "${var.project_name}-${var.vpc_name}-vpc" }
}

# ─────────────────────────────────────────────────────────────────────────────
# 2. Internet Gateway
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.vpc.id
  tags   = { Name = "${var.project_name}-${var.vpc_name}-igw" }
}

# ─────────────────────────────────────────────────────────────────────────────
# 3. SUBNETS
# ─────────────────────────────────────────────────────────────────────────────

# Zone Management (publique) — NLB + NAT Gateway
resource "aws_subnet" "management_public" {
  vpc_id                  = aws_vpc.vpc.id
  cidr_block              = cidrsubnet(var.vpc_cidr, 8, 1)
  availability_zone       = local.azs[0]
  map_public_ip_on_launch = true
  tags = { Name = "${var.project_name}-${var.vpc_name}-management-public" }
}

# Zone SOC (privée) — Worker Nodes Kubernetes (3 AZ pour résilience)
resource "aws_subnet" "soc_private" {
  count             = 3
  vpc_id            = aws_vpc.vpc.id
  cidr_block        = cidrsubnet(var.vpc_cidr, 8, 10 + count.index)
  availability_zone = local.azs[count.index]
  tags = { Name = "${var.project_name}-${var.vpc_name}-soc-private-${count.index + 1}" }
}

# Zone Workplace (privée) — EC2 Linux/Windows + Active Directory
resource "aws_subnet" "workplace_private" {
  vpc_id            = aws_vpc.vpc.id
  cidr_block        = cidrsubnet(var.vpc_cidr, 8, 3)
  availability_zone = local.azs[2]
  tags = { Name = "${var.project_name}-${var.vpc_name}-workplace-private" }
}

# ─────────────────────────────────────────────────────────────────────────────
# 4. NAT GATEWAY (permet aux zones privées de faire des MAJ sans IP publique)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_eip" "nat" {
  domain     = "vpc"
  depends_on = [aws_internet_gateway.igw]
  tags       = { Name = "${var.project_name}-nat-eip" }
}

resource "aws_nat_gateway" "nat" {
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.management_public.id
  depends_on    = [aws_internet_gateway.igw]
  tags          = { Name = "${var.project_name}-nat" }
}

# ─────────────────────────────────────────────────────────────────────────────
# 5. ROUTE TABLES
# ─────────────────────────────────────────────────────────────────────────────

# Route publique → Internet
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.vpc.id
  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.igw.id
  }
  tags = { Name = "${var.project_name}-${var.vpc_name}-public-rt" }
}

resource "aws_route_table_association" "management_public" {
  subnet_id      = aws_subnet.management_public.id
  route_table_id = aws_route_table.public.id
}

# Route privée → NAT (SOC nodes + Workplace)
resource "aws_route_table" "private" {
  vpc_id = aws_vpc.vpc.id
  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.nat.id
  }
  tags = { Name = "${var.project_name}-${var.vpc_name}-private-rt" }
}

resource "aws_route_table_association" "soc_private" {
  count          = 3
  subnet_id      = aws_subnet.soc_private[count.index].id
  route_table_id = aws_route_table.private.id
}

resource "aws_route_table_association" "workplace" {
  subnet_id      = aws_subnet.workplace_private.id
  route_table_id = aws_route_table.private.id
}

# ─────────────────────────────────────────────────────────────────────────────
# 6. SECURITY GROUPS
# ─────────────────────────────────────────────────────────────────────────────

# SG pour le NLB — accepte les logs des agents Wazuh
resource "aws_security_group" "nlb" {
  name        = "${var.project_name}-${var.vpc_name}-nlb-sg"
  description = "NLB : accepte les logs Wazuh depuis Workplace"
  vpc_id      = aws_vpc.vpc.id

  ingress {
    description = "Logs agents Wazuh (TLS)"
    from_port   = 1514
    to_port     = 1514
    protocol    = "tcp"
    cidr_blocks = [cidrsubnet(var.vpc_cidr, 8, 3)]
  }
  ingress {
    description = "Enregistrement automatique des agents"
    from_port   = 1515
    to_port     = 1515
    protocol    = "tcp"
    cidr_blocks = [cidrsubnet(var.vpc_cidr, 8, 3)]
  }
  ingress {
    description = "HTTPS Kibana/Grafana"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "${var.project_name}-nlb-sg" }
}

# SG pour les EC2 Workplace
resource "aws_security_group" "workplace" {
  name        = "${var.project_name}-${var.vpc_name}-workplace-sg"
  description = "EC2 Workplace : envoi logs vers NLB uniquement"
  vpc_id      = aws_vpc.vpc.id

  ingress {
    description = "RDP interne (admin)"
    from_port   = 3389
    to_port     = 3389
    protocol    = "tcp"
    cidr_blocks = [cidrsubnet(var.vpc_cidr, 8, 1)]
  }
  ingress {
    description = "SSH interne (admin)"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = [cidrsubnet(var.vpc_cidr, 8, 1)]
  }
  egress {
    description = "Logs vers NLB Wazuh"
    from_port   = 1514
    to_port     = 1515
    protocol    = "tcp"
    cidr_blocks = [cidrsubnet(var.vpc_cidr, 8, 1)]
  }
  egress {
    description = "MAJ via NAT (HTTPS)"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    description = "DNS"
    from_port   = 53
    to_port     = 53
    protocol    = "udp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "${var.project_name}-${var.vpc_name}-workplace-sg" }
}

# SG pour les Worker Nodes EKS
resource "aws_security_group" "eks_nodes" {
  name        = "${var.project_name}-${var.vpc_name}-eks-nodes-sg"
  description = "Worker nodes EKS ${var.vpc_name}"
  vpc_id      = aws_vpc.vpc.id

  ingress {
    description = "Wazuh Manager (agents)"
    from_port   = 1514
    to_port     = 1515
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }
  ingress {
    description = "Communication inter-nodes K8s"
    from_port   = 0
    to_port     = 65535
    protocol    = "tcp"
    self        = true
  }
  ingress {
    description = "HTTPS API"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "${var.project_name}-${var.vpc_name}-eks-nodes-sg" }
}

# ─────────────────────────────────────────────────────────────────────────────
# 7. NETWORK LOAD BALANCER — Point d'entrée des agents Wazuh
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_lb" "nlb" {
  name               = "${var.project_name}-${var.vpc_name}-nlb"
  internal           = false
  load_balancer_type = "network"
  subnets            = [aws_subnet.management_public.id]
  tags               = { Name = "${var.project_name}-${var.vpc_name}-nlb" }
}

resource "aws_lb_target_group" "wazuh_logs" {
  name        = "${var.project_name}-${var.vpc_name}-wazuh-logs"
  port        = 1514
  protocol    = "TCP"
  vpc_id      = aws_vpc.vpc.id
  target_type = "ip"

  health_check {
    protocol = "TCP"
    port     = "1514"
  }
}

resource "aws_lb_target_group" "wazuh_enroll" {
  name        = "${var.project_name}-${var.vpc_name}-wazuh-enroll"
  port        = 1515
  protocol    = "TCP"
  vpc_id      = aws_vpc.vpc.id
  target_type = "ip"

  health_check {
    protocol = "TCP"
    port     = "1515"
  }
}

resource "aws_lb_listener" "wazuh_logs" {
  load_balancer_arn = aws_lb.nlb.arn
  port              = 1514
  protocol          = "TCP"
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.wazuh_logs.arn
  }
}

resource "aws_lb_listener" "wazuh_enroll" {
  load_balancer_arn = aws_lb.nlb.arn
  port              = 1515
  protocol          = "TCP"
  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.wazuh_enroll.arn
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# 8. VPC FLOW LOGS — Collecte du trafic réseau vers CloudWatch
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_cloudwatch_log_group" "flow_logs" {
  name              = "/aws/vpc/${var.project_name}-${var.vpc_name}-flow-logs"
  retention_in_days = 30
}

resource "aws_iam_role" "flow_log" {
  name = "${var.project_name}-${var.vpc_name}-flow-log-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "vpc-flow-logs.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy" "flow_log" {
  name = "${var.project_name}-${var.vpc_name}-flow-log-policy"
  role = aws_iam_role.flow_log.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = [
        "logs:CreateLogGroup",
        "logs:CreateLogStream",
        "logs:PutLogEvents",
        "logs:DescribeLogGroups",
        "logs:DescribeLogStreams"
      ]
      Resource = "*"
    }]
  })
}

resource "aws_flow_log" "vpc" {
  vpc_id          = aws_vpc.vpc.id
  traffic_type    = "ALL"
  iam_role_arn    = aws_iam_role.flow_log.arn
  log_destination = aws_cloudwatch_log_group.flow_logs.arn
}

# ─────────────────────────────────────────────────────────────────────────────
# 9. CLOUDTRAIL — Audit des appels API AWS (IAM, Security Groups, etc.)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_s3_bucket" "cloudtrail" {
  bucket        = "${var.project_name}-${var.vpc_name}-cloudtrail-${data.aws_caller_identity.current.account_id}"
  force_destroy = true
  tags          = { Name = "${var.project_name}-${var.vpc_name}-cloudtrail-bucket" }
}

resource "aws_s3_bucket_policy" "cloudtrail" {
  bucket = aws_s3_bucket.cloudtrail.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid       = "AWSCloudTrailAclCheck"
        Effect    = "Allow"
        Principal = { Service = "cloudtrail.amazonaws.com" }
        Action    = "s3:GetBucketAcl"
        Resource  = aws_s3_bucket.cloudtrail.arn
      },
      {
        Sid       = "AWSCloudTrailWrite"
        Effect    = "Allow"
        Principal = { Service = "cloudtrail.amazonaws.com" }
        Action    = "s3:PutObject"
        Resource  = "${aws_s3_bucket.cloudtrail.arn}/AWSLogs/${data.aws_caller_identity.current.account_id}/*"
        Condition = { StringEquals = { "s3:x-amz-acl" = "bucket-owner-full-control" } }
      }
    ]
  })
}

resource "aws_cloudtrail" "vpc" {
  name                          = "${var.project_name}-${var.vpc_name}-trail"
  s3_bucket_name                = aws_s3_bucket.cloudtrail.id
  is_multi_region_trail         = true
  include_global_service_events = true
  enable_log_file_validation    = true
  depends_on                    = [aws_s3_bucket_policy.cloudtrail]
}

data "aws_caller_identity" "current" {}