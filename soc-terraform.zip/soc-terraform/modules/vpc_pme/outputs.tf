###############################################################################
#  modules/vpc_pme/outputs.tf
###############################################################################
output "vpc_id" {
  value = aws_vpc.vpc.id
}

output "soc_subnet_ids" {
  value = aws_subnet.soc_private[*].id
}

output "workplace_subnet_id" {
  value = aws_subnet.workplace_private.id
}

output "management_subnet_id" {
  value = aws_subnet.management_public.id
}

output "nlb_dns_name" {
  value = aws_lb.nlb.dns_name
}

output "nat_public_ip" {
  value = aws_eip.nat.public_ip
}

output "nlb_arn" {
  value = aws_lb.nlb.arn
}

output "workplace_sg_id" {
  value = aws_security_group.workplace.id
}

output "eks_nodes_sg_id" {
  value = aws_security_group.eks_nodes.id
}