###############################################################################
#  modules/vpc_pme/variables.tf
###############################################################################
variable "project_name" { type = string }
variable "aws_region"   { type = string }
variable "vpc_cidr"     { type = string }
variable "vpc_name"     { type = string }