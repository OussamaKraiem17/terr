###############################################################################
#  modules/k8s/main.tf
#  Déploiement Kubernetes et Helm sur le cluster EKS créé par module.eks
###############################################################################

resource "kubernetes_storage_class" "ebs_gp3" {
  metadata {
    name = "ebs-gp3"
    annotations = {
      "storageclass.kubernetes.io/is-default-class" = "true"
    }
  }
  storage_provisioner    = "ebs.csi.aws.com"
  reclaim_policy         = "Retain"
  volume_binding_mode    = "WaitForFirstConsumer"
  allow_volume_expansion = true
  parameters = {
    type      = "gp3"
    iops      = "3000"
    throughput = "125"
    encrypted = "true"
  }
}

resource "kubernetes_namespace" "soc" {
  metadata {
    name = "soc"
    labels = {
      name    = "soc"
      project = var.project_name
    }
  }
}

resource "helm_release" "nginx_ingress" {
  name             = "ingress-nginx"
  repository       = "https://kubernetes.github.io/ingress-nginx"
  chart            = "ingress-nginx"
  namespace        = "ingress-nginx"
  create_namespace = true
  version          = "4.10.0"

  set {
    name  = "controller.service.type"
    value = "LoadBalancer"
  }
  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/aws-load-balancer-type"
    value = "nlb"
  }
}

resource "helm_release" "wazuh" {
  name             = "wazuh"
  repository       = "https://packages.wazuh.com/4.x/helm/"
  chart            = "wazuh-kubernetes"
  namespace        = "soc"
  create_namespace = false
  timeout          = 600
  wait             = true
  version          = "4.7.0"

  set {
    name  = "wazuh.manager.replicaCount"
    value = "1"
  }
  set {
    name  = "wazuh.manager.service.port"
    value = "1514"
  }
  set {
    name  = "indexer.storageClass"
    value = "ebs-gp3"
  }
  set {
    name  = "indexer.storageSize"
    value = "50Gi"
  }
  set {
    name  = "wazuh.manager.env[0].name"
    value = "WAZUH_MANAGER_PORT"
  }
  set {
    name  = "wazuh.manager.env[0].value"
    value = "1514"
  }

  depends_on = [
    kubernetes_namespace.soc,
    kubernetes_storage_class.ebs_gp3,
  ]
}

resource "helm_release" "kube_prometheus" {
  name             = "kube-prometheus-stack"
  repository       = "https://prometheus-community.github.io/helm-charts"
  chart            = "kube-prometheus-stack"
  namespace        = "monitoring"
  create_namespace = true
  version          = "58.0.0"

  set {
    name  = "grafana.adminPassword"
    value = "SOCAdmin2024!"
  }
  set {
    name  = "grafana.service.type"
    value = "ClusterIP"
  }
  set {
    name  = "prometheus.prometheusSpec.retention"
    value = "15d"
  }
  set {
    name  = "defaultRules.rules.alertmanager"
    value = "true"
  }
}

resource "helm_release" "falco" {
  name             = "falco"
  repository       = "https://falcosecurity.github.io/charts"
  chart            = "falco"
  namespace        = "falco-system"
  create_namespace = true
  version          = "3.8.0"

  set {
    name  = "falco.jsonOutput"
    value = "true"
  }
  set {
    name  = "falco.logLevel"
    value = "info"
  }
  set {
    name  = "falco.rules[0]"
    value = "spawned_process_in_container"
  }
  set {
    name  = "falcosidekick.enabled"
    value = "true"
  }
  set {
    name  = "driver.kind"
    value = "ebpf"
  }
}

resource "kubernetes_horizontal_pod_autoscaler_v2" "wazuh_manager" {
  metadata {
    name      = "wazuh-manager-hpa"
    namespace = "soc"
  }
  spec {
    scale_target_ref {
      api_version = "apps/v1"
      kind        = "StatefulSet"
      name        = "wazuh-manager"
    }
    min_replicas = 3
    max_replicas = 10
    metric {
      type = "Resource"
      resource {
        name = "cpu"
        target {
          type                = "Utilization"
          average_utilization = 70
        }
      }
    }
  }
}
