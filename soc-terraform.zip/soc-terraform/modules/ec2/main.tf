###############################################################################
#  modules/ec2/main.tf
#  EC2 Workplace : 1 Linux (Ubuntu) + 1 Windows (AD) avec agents Wazuh
###############################################################################

data "aws_ami" "ubuntu" {
  most_recent = true
  owners      = ["099720109477"]  # Canonical
  filter {
    name   = "name"
    values = ["ubuntu/images/hvm-ssd/ubuntu-jammy-22.04-amd64-server-*"]
  }
}

data "aws_ami" "windows" {
  most_recent = true
  owners      = ["801119661308"]  # Amazon
  filter {
    name   = "name"
    values = ["Windows_Server-2022-English-Full-Base-*"]
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# IAM Profile pour les EC2 (CloudWatch Logs + SSM pour accès sans SSH public)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_iam_role" "ec2_workplace" {
  name = "${var.project_name}-ec2-workplace-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "ssm" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
  role       = aws_iam_role.ec2_workplace.name
}

resource "aws_iam_role_policy_attachment" "cloudwatch_agent" {
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
  role       = aws_iam_role.ec2_workplace.name
}

resource "aws_iam_instance_profile" "ec2_workplace" {
  name = "${var.project_name}-ec2-workplace-profile"
  role = aws_iam_role.ec2_workplace.name
}

# ─────────────────────────────────────────────────────────────────────────────
# EC2 LINUX — Ubuntu 22.04 avec agent Wazuh auto-installé (user_data)
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_instance" "linux" {
  ami                    = data.aws_ami.ubuntu.id
  instance_type          = "t3.medium"
  subnet_id              = var.workplace_subnet_id
  iam_instance_profile   = aws_iam_instance_profile.ec2_workplace.name
  key_name               = var.key_pair_name
  vpc_security_group_ids = [aws_security_group.workplace_ec2.id]

  # Installation automatique de l'agent Wazuh au démarrage
  user_data = base64encode(templatefile("${path.module}/scripts/install_wazuh_linux.sh", {
    wazuh_manager_ip = var.wazuh_manager_ip
  }))

  root_block_device {
    volume_type           = "gp3"
    volume_size           = 30
    delete_on_termination = true
    encrypted             = true
  }

  tags = { Name = "${var.project_name}-workplace-linux" }
}

# ─────────────────────────────────────────────────────────────────────────────
# EC2 WINDOWS — Windows Server 2022 + Active Directory + agent Wazuh
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_instance" "windows_ad" {
  ami                    = data.aws_ami.windows.id
  instance_type          = "t3.large"    # AD nécessite plus de RAM
  subnet_id              = var.workplace_subnet_id
  iam_instance_profile   = aws_iam_instance_profile.ec2_workplace.name
  key_name               = var.key_pair_name
  vpc_security_group_ids = [aws_security_group.workplace_ec2.id]

  # Script PowerShell : installe AD DS + agent Wazuh
  user_data = base64encode(templatefile("${path.module}/scripts/install_wazuh_windows.ps1", {
    wazuh_manager_ip = var.wazuh_manager_ip
    domain_name      = "soc-pfe.local"
  }))

  root_block_device {
    volume_type           = "gp3"
    volume_size           = 60
    delete_on_termination = true
    encrypted             = true
  }

  tags = { Name = "${var.project_name}-workplace-windows-ad" }
}

# ─────────────────────────────────────────────────────────────────────────────
# SECURITY GROUP — EC2 Workplace
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_security_group" "workplace_ec2" {
  name        = "${var.project_name}-workplace-ec2-sg"
  description = "SG pour les instances EC2 de la zone Workplace"
  vpc_id      = var.vpc_id

  ingress {
    description = "SSH depuis zone management"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = ["10.0.1.0/24"]
  }
  ingress {
    description = "RDP depuis zone management"
    from_port   = 3389
    to_port     = 3389
    protocol    = "tcp"
    cidr_blocks = ["10.0.1.0/24"]
  }
  ingress {
    description = "Active Directory LDAP interne"
    from_port   = 389
    to_port     = 389
    protocol    = "tcp"
    cidr_blocks = ["10.0.3.0/24"]
  }
  egress {
    description = "Logs Wazuh vers NLB"
    from_port   = 1514
    to_port     = 1515
    protocol    = "tcp"
    cidr_blocks = ["10.0.1.0/24"]
  }
  egress {
    description = "HTTPS (MAJ, OTX, VirusTotal)"
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  egress {
    description = "DNS"
    from_port   = 53
    to_port     = 53
    protocol    = "udp"
    cidr_blocks = ["0.0.0.0/0"]
  }
  tags = { Name = "${var.project_name}-workplace-ec2-sg" }
}
