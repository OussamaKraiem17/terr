#!/bin/bash
###############################################################################
#  install_wazuh_linux.sh — User data Ubuntu 22.04
#  Installe l'agent Wazuh et le pointe vers le NLB
###############################################################################
set -e

WAZUH_MANAGER="${wazuh_manager_ip}"
WAZUH_VERSION="4.7.0-1"

apt-get update -y
apt-get install -y curl gnupg apt-transport-https

# Clé GPG Wazuh
curl -s https://packages.wazuh.com/key/GPG-KEY-WAZUH | gpg --dearmor -o /usr/share/keyrings/wazuh.gpg
echo "deb [signed-by=/usr/share/keyrings/wazuh.gpg] https://packages.wazuh.com/4.x/apt/ stable main" \
  > /etc/apt/sources.list.d/wazuh.list

apt-get update -y
WAZUH_MANAGER="$WAZUH_MANAGER" apt-get install -y wazuh-agent=$WAZUH_VERSION

# Configuration du manager
sed -i "s/MANAGER_IP/$WAZUH_MANAGER/g" /var/ossec/etc/ossec.conf

systemctl daemon-reload
systemctl enable wazuh-agent
systemctl start wazuh-agent

echo "[SOC-PFE] Agent Wazuh installé et démarré → Manager: $WAZUH_MANAGER"
