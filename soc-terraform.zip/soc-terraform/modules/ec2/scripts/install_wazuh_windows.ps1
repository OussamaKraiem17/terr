<powershell>
###############################################################################
#  install_wazuh_windows.ps1 — User data Windows Server 2022
#  1. Installe Active Directory Domain Services
#  2. Installe l'agent Wazuh et le pointe vers le NLB
###############################################################################

$WazuhManager = "${wazuh_manager_ip}"
$DomainName   = "${domain_name}"
$WazuhVersion = "4.7.0-1"

# ── 1. Installer les features AD DS ─────────────────────────────────────────
Install-WindowsFeature -Name AD-Domain-Services -IncludeManagementTools

# Promouvoir le serveur en Domain Controller
Import-Module ADDSDeployment
Install-ADDSForest `
  -DomainName $DomainName `
  -InstallDns:$true `
  -SafeModeAdministratorPassword (ConvertTo-SecureString "SOCPfe2024!" -AsPlainText -Force) `
  -Force:$true `
  -NoRebootOnCompletion:$true

# ── 2. Installer l'agent Wazuh ───────────────────────────────────────────────
$WazuhUrl = "https://packages.wazuh.com/4.x/windows/wazuh-agent-$WazuhVersion.msi"
$Installer = "C:\wazuh-agent.msi"

Invoke-WebRequest -Uri $WazuhUrl -OutFile $Installer

# Installation silencieuse avec pointage vers le manager
Start-Process msiexec.exe -Wait -ArgumentList `
  "/i $Installer WAZUH_MANAGER='$WazuhManager' WAZUH_REGISTRATION_SERVER='$WazuhManager' /quiet"

# Démarrer le service
Start-Service -Name WazuhSvc
Set-Service -Name WazuhSvc -StartupType Automatic

# ── 3. Activer l'audit Windows (Event IDs critiques pour le SOC) ─────────────
# 4625: Echec connexion | 4688: Création processus | 4720: Création user AD
auditpol /set /subcategory:"Logon" /success:enable /failure:enable
auditpol /set /subcategory:"Process Creation" /success:enable /failure:enable
auditpol /set /subcategory:"User Account Management" /success:enable /failure:enable
auditpol /set /subcategory:"Security Group Management" /success:enable /failure:enable

Write-Output "[SOC-PFE] Agent Wazuh + AD DS installés -> Manager: $WazuhManager"

# Redémarrage obligatoire pour AD DS
Restart-Computer -Force
</powershell>
