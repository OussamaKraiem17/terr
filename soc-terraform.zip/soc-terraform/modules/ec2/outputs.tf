###############################################################################
#  modules/ec2/outputs.tf
###############################################################################
output "linux_private_ip"   { value = aws_instance.linux.private_ip }
output "windows_private_ip" { value = aws_instance.windows_ad.private_ip }
output "linux_instance_id"  { value = aws_instance.linux.id }
output "windows_instance_id"{ value = aws_instance.windows_ad.id }
