###############################################################################
#  modules/ec2/variables.tf
###############################################################################
variable "project_name"        { type = string }
variable "vpc_id"              { type = string }
variable "workplace_subnet_id" { type = string }
variable "wazuh_manager_ip"    { type = string }
variable "key_pair_name"       { type = string }
