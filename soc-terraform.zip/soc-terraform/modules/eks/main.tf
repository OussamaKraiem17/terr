###############################################################################
#  modules/eks/main.tf
#  Cluster EKS Multi-AZ avec 2 Node Pools spécialisés :
#   - pool-analyse  : Compute-Optimized (Wazuh Manager/correlateur)
#   - pool-stockage : avec volumes EBS gp3 (Elasticsearch Indexer)
###############################################################################

# ─────────────────────────────────────────────────────────────────────────────
# IAM — Rôle du Control Plane EKS
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_iam_role" "eks_cluster" {
  name = "${var.project_name}-eks-cluster-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "eks.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "eks_cluster_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
  role       = aws_iam_role.eks_cluster.name
}

resource "aws_iam_role_policy_attachment" "eks_vpc_resource_controller" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSVPCResourceController"
  role       = aws_iam_role.eks_cluster.name
}

# ─────────────────────────────────────────────────────────────────────────────
# IAM — Rôle des Worker Nodes
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_iam_role" "eks_nodes" {
  name = "${var.project_name}-eks-nodes-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "eks_worker_node_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
  role       = aws_iam_role.eks_nodes.name
}

resource "aws_iam_role_policy_attachment" "eks_cni_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
  role       = aws_iam_role.eks_nodes.name
}

resource "aws_iam_role_policy_attachment" "eks_container_registry" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
  role       = aws_iam_role.eks_nodes.name
}

# Politique SOAR : permet à Shuffle de modifier les Security Groups via API AWS
resource "aws_iam_policy" "soar_remediation" {
  name        = "${var.project_name}-soar-remediation"
  description = "Permet au SOAR (Shuffle) d'isoler des EC2 via Security Groups"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "ec2:AuthorizeSecurityGroupIngress",
          "ec2:RevokeSecurityGroupIngress",
          "ec2:AuthorizeSecurityGroupEgress",
          "ec2:RevokeSecurityGroupEgress",
          "ec2:ModifyInstanceAttribute",
          "ec2:DescribeInstances",
          "ec2:DescribeSecurityGroups",
          "iam:DetachUserPolicy",
          "iam:DeleteAccessKey",
          "iam:ListAccessKeys"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "soar_remediation" {
  policy_arn = aws_iam_policy.soar_remediation.arn
  role       = aws_iam_role.eks_nodes.name
}

# ─────────────────────────────────────────────────────────────────────────────
# CLUSTER EKS — Control Plane Multi-AZ
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_eks_cluster" "soc" {
  name     = "${var.project_name}-cluster"
  role_arn = aws_iam_role.eks_cluster.arn
  version  = "1.29"

  vpc_config {
    subnet_ids              = var.private_subnet_ids
    endpoint_private_access = true
    endpoint_public_access  = true   # pour kubectl depuis la machine locale
  }

  # Activer les logs du Control Plane (audit, API, authenticator)
  enabled_cluster_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]

  depends_on = [
    aws_iam_role_policy_attachment.eks_cluster_policy,
    aws_iam_role_policy_attachment.eks_vpc_resource_controller,
  ]

  tags = { Name = "${var.project_name}-eks-cluster" }
}

# ─────────────────────────────────────────────────────────────────────────────
# NODE POOL 1 — Analyse (Wazuh Manager + corrélation)
#   Compute-Optimized : idéal pour traitement CPU intensif des règles SIGMA
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_eks_node_group" "analyse" {
  cluster_name    = aws_eks_cluster.soc.name
  node_group_name = "${var.project_name}-pool-analyse"
  node_role_arn   = aws_iam_role.eks_nodes.arn
  subnet_ids      = var.private_subnet_ids

  instance_types = ["c5.large"]   # Compute-Optimized

  scaling_config {
    desired_size = var.desired_node_count
    min_size     = var.min_node_count
    max_size     = var.max_node_count
  }

  # HPA — auto-scaling lors d'une tempête de logs
  update_config {
    max_unavailable = 1
  }

  labels = {
    pool = "analyse"
    role = "wazuh-manager"
  }

  taint {
    key    = "pool"
    value  = "analyse"
    effect = "NO_SCHEDULE"
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_worker_node_policy,
    aws_iam_role_policy_attachment.eks_cni_policy,
    aws_iam_role_policy_attachment.eks_container_registry,
  ]

  tags = { Name = "${var.project_name}-pool-analyse" }
}

# ─────────────────────────────────────────────────────────────────────────────
# NODE POOL 2 — Stockage (Elasticsearch / Wazuh Indexer)
#   Volumes EBS gp3 haute performance pour indexation des logs
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_eks_node_group" "stockage" {
  cluster_name    = aws_eks_cluster.soc.name
  node_group_name = "${var.project_name}-pool-stockage"
  node_role_arn   = aws_iam_role.eks_nodes.arn
  subnet_ids      = var.private_subnet_ids

  instance_types = ["r5.large"]   # Memory-Optimized : idéal pour Elasticsearch

  scaling_config {
    desired_size = 2
    min_size     = 2
    max_size     = 6
  }

  # Disque root étendu pour les logs
  disk_size = 100

  labels = {
    pool = "stockage"
    role = "elasticsearch"
  }

  taint {
    key    = "pool"
    value  = "stockage"
    effect = "NO_SCHEDULE"
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_worker_node_policy,
    aws_iam_role_policy_attachment.eks_cni_policy,
    aws_iam_role_policy_attachment.eks_container_registry,
  ]

  tags = { Name = "${var.project_name}-pool-stockage" }
}


