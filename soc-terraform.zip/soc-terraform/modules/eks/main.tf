###############################################################################
#  modules/eks/main.tf
#  Cluster EKS Multi-AZ avec 2 Node Pools spécialisés :
#   - pool-analyse  : Compute-Optimized (Wazuh Manager/correlateur)
#   - pool-stockage : avec volumes EBS gp3 (Elasticsearch Indexer)
###############################################################################

# ─────────────────────────────────────────────────────────────────────────────
# IAM — Rôle du Control Plane EKS
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_iam_role" "eks_cluster" {
  name = "${var.project_name}-eks-cluster-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "eks.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "eks_cluster_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSClusterPolicy"
  role       = aws_iam_role.eks_cluster.name
}

resource "aws_iam_role_policy_attachment" "eks_vpc_resource_controller" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSVPCResourceController"
  role       = aws_iam_role.eks_cluster.name
}

# ─────────────────────────────────────────────────────────────────────────────
# IAM — Rôle des Worker Nodes
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_iam_role" "eks_nodes" {
  name = "${var.project_name}-eks-nodes-role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action    = "sts:AssumeRole"
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
    }]
  })
}

resource "aws_iam_role_policy_attachment" "eks_worker_node_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKSWorkerNodePolicy"
  role       = aws_iam_role.eks_nodes.name
}

resource "aws_iam_role_policy_attachment" "eks_cni_policy" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEKS_CNI_Policy"
  role       = aws_iam_role.eks_nodes.name
}

resource "aws_iam_role_policy_attachment" "eks_container_registry" {
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
  role       = aws_iam_role.eks_nodes.name
}

# Politique SOAR : permet à Shuffle de modifier les Security Groups via API AWS
resource "aws_iam_policy" "soar_remediation" {
  name        = "${var.project_name}-soar-remediation"
  description = "Permet au SOAR (Shuffle) d'isoler des EC2 via Security Groups"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "ec2:AuthorizeSecurityGroupIngress",
          "ec2:RevokeSecurityGroupIngress",
          "ec2:AuthorizeSecurityGroupEgress",
          "ec2:RevokeSecurityGroupEgress",
          "ec2:ModifyInstanceAttribute",
          "ec2:DescribeInstances",
          "ec2:DescribeSecurityGroups",
          "iam:DetachUserPolicy",
          "iam:DeleteAccessKey",
          "iam:ListAccessKeys"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_role_policy_attachment" "soar_remediation" {
  policy_arn = aws_iam_policy.soar_remediation.arn
  role       = aws_iam_role.eks_nodes.name
}

# ─────────────────────────────────────────────────────────────────────────────
# CLUSTER EKS — Control Plane Multi-AZ
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_eks_cluster" "soc" {
  name     = "${var.project_name}-cluster"
  role_arn = aws_iam_role.eks_cluster.arn
  version  = "1.29"

  vpc_config {
    subnet_ids              = var.private_subnet_ids
    endpoint_private_access = true
    endpoint_public_access  = true   # pour kubectl depuis la machine locale
  }

  # Activer les logs du Control Plane (audit, API, authenticator)
  enabled_cluster_log_types = ["api", "audit", "authenticator", "controllerManager", "scheduler"]

  depends_on = [
    aws_iam_role_policy_attachment.eks_cluster_policy,
    aws_iam_role_policy_attachment.eks_vpc_resource_controller,
  ]

  tags = { Name = "${var.project_name}-eks-cluster" }
}

# ─────────────────────────────────────────────────────────────────────────────
# NODE POOL 1 — Analyse (Wazuh Manager + corrélation)
#   Compute-Optimized : idéal pour traitement CPU intensif des règles SIGMA
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_eks_node_group" "analyse" {
  cluster_name    = aws_eks_cluster.soc.name
  node_group_name = "${var.project_name}-pool-analyse"
  node_role_arn   = aws_iam_role.eks_nodes.arn
  subnet_ids      = var.private_subnet_ids

  instance_types = ["c5.large"]   # Compute-Optimized

  scaling_config {
    desired_size = var.desired_node_count
    min_size     = var.min_node_count
    max_size     = var.max_node_count
  }

  # HPA — auto-scaling lors d'une tempête de logs
  update_config {
    max_unavailable = 1
  }

  labels = {
    pool = "analyse"
    role = "wazuh-manager"
  }

  taint {
    key    = "pool"
    value  = "analyse"
    effect = "NO_SCHEDULE"
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_worker_node_policy,
    aws_iam_role_policy_attachment.eks_cni_policy,
    aws_iam_role_policy_attachment.eks_container_registry,
  ]

  tags = { Name = "${var.project_name}-pool-analyse" }
}

# ─────────────────────────────────────────────────────────────────────────────
# NODE POOL 2 — Stockage (Elasticsearch / Wazuh Indexer)
#   Volumes EBS gp3 haute performance pour indexation des logs
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_eks_node_group" "stockage" {
  cluster_name    = aws_eks_cluster.soc.name
  node_group_name = "${var.project_name}-pool-stockage"
  node_role_arn   = aws_iam_role.eks_nodes.arn
  subnet_ids      = var.private_subnet_ids

  instance_types = ["r5.large"]   # Memory-Optimized : idéal pour Elasticsearch

  scaling_config {
    desired_size = 2
    min_size     = 2
    max_size     = 6
  }

  # Disque root étendu pour les logs
  disk_size = 100

  labels = {
    pool = "stockage"
    role = "elasticsearch"
  }

  taint {
    key    = "pool"
    value  = "stockage"
    effect = "NO_SCHEDULE"
  }

  depends_on = [
    aws_iam_role_policy_attachment.eks_worker_node_policy,
    aws_iam_role_policy_attachment.eks_cni_policy,
    aws_iam_role_policy_attachment.eks_container_registry,
  ]

  tags = { Name = "${var.project_name}-pool-stockage" }
}

# ─────────────────────────────────────────────────────────────────────────────
# STORAGE CLASS EBS gp3 — Persistent Volumes pour Wazuh + Elasticsearch
# ─────────────────────────────────────────────────────────────────────────────
resource "kubernetes_storage_class" "ebs_gp3" {
  metadata {
    name = "ebs-gp3"
    annotations = {
      "storageclass.kubernetes.io/is-default-class" = "true"
    }
  }
  storage_provisioner    = "ebs.csi.aws.com"
  reclaim_policy         = "Retain"
  volume_binding_mode    = "WaitForFirstConsumer"
  allow_volume_expansion = true
  parameters = {
    type      = "gp3"
    iops      = "3000"
    throughput = "125"
    encrypted = "true"
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# NAMESPACE SOC — Isolation logique de tous les composants
# ─────────────────────────────────────────────────────────────────────────────
resource "kubernetes_namespace" "soc" {
  metadata {
    name = "soc"
    labels = {
      name    = "soc"
      project = var.project_name
    }
  }
  depends_on = [aws_eks_cluster.soc]
}

# ─────────────────────────────────────────────────────────────────────────────
# HELM — Nginx Ingress Controller (routage HTTPS vers Kibana/Grafana)
# ─────────────────────────────────────────────────────────────────────────────
resource "helm_release" "nginx_ingress" {
  name       = "ingress-nginx"
  repository = "https://kubernetes.github.io/ingress-nginx"
  chart      = "ingress-nginx"
  namespace  = "ingress-nginx"
  create_namespace = true
  version    = "4.10.0"

  set {
    name  = "controller.service.type"
    value = "LoadBalancer"
  }
  set {
    name  = "controller.service.annotations.service\\.beta\\.kubernetes\\.io/aws-load-balancer-type"
    value = "nlb"
  }

  depends_on = [aws_eks_node_group.analyse]
}

# ─────────────────────────────────────────────────────────────────────────────
# HELM — Wazuh SIEM (Manager + Indexer + Dashboard)
# ─────────────────────────────────────────────────────────────────────────────
resource "helm_release" "wazuh" {
  name             = "wazuh"
  repository       = "https://packages.wazuh.com/4.x/helm/"
  chart            = "wazuh-kubernetes"
  namespace        = "soc"
  create_namespace = false
  timeout          = 600
  wait             = true
  version          = "4.7.0"

  # Wazuh Manager — StatefulSet avec identité réseau fixe
  set {
    name  = "wazuh.manager.replicaCount"
    value = "1"
  }
  set {
    name  = "wazuh.manager.service.port"
    value = "1514"
  }
  # Wazuh Indexer — Persistent Volume EBS gp3
  set {
    name  = "indexer.storageClass"
    value = "ebs-gp3"
  }
  set {
    name  = "indexer.storageSize"
    value = "50Gi"
  }
  # TLS 1.3 pour les communications agents
  set {
    name  = "wazuh.manager.env[0].name"
    value = "WAZUH_MANAGER_PORT"
  }
  set {
    name  = "wazuh.manager.env[0].value"
    value = "1514"
  }

  depends_on = [
    kubernetes_namespace.soc,
    kubernetes_storage_class.ebs_gp3,
    aws_eks_node_group.stockage
  ]
}

# ─────────────────────────────────────────────────────────────────────────────
# HELM — Prometheus + Grafana (monitoring du SOC)
# ─────────────────────────────────────────────────────────────────────────────
resource "helm_release" "kube_prometheus" {
  name             = "kube-prometheus-stack"
  repository       = "https://prometheus-community.github.io/helm-charts"
  chart            = "kube-prometheus-stack"
  namespace        = "monitoring"
  create_namespace = true
  version          = "58.0.0"

  set {
    name  = "grafana.adminPassword"
    value = "SOCAdmin2024!"   # À remplacer par un secret Vault en prod
  }
  set {
    name  = "grafana.service.type"
    value = "ClusterIP"
  }
  set {
    name  = "prometheus.prometheusSpec.retention"
    value = "15d"
  }
  # Alertes si un pod SOC est down
  set {
    name  = "defaultRules.rules.alertmanager"
    value = "true"
  }

  depends_on = [aws_eks_node_group.analyse]
}

# ─────────────────────────────────────────────────────────────────────────────
# HELM — Falco (sécurité runtime — DaemonSet sur chaque node)
# ─────────────────────────────────────────────────────────────────────────────
resource "helm_release" "falco" {
  name             = "falco"
  repository       = "https://falcosecurity.github.io/charts"
  chart            = "falco"
  namespace        = "falco-system"
  create_namespace = true
  version          = "3.8.0"

  # Sortie JSON pour intégration avec Wazuh
  set {
    name  = "falco.jsonOutput"
    value = "true"
  }
  set {
    name  = "falco.logLevel"
    value = "info"
  }
  # Règles critiques : shell dans container, lecture /etc/shadow, modif binaires
  set {
    name  = "falco.rules[0]"
    value = "spawned_process_in_container"
  }
  set {
    name  = "falcosidekick.enabled"
    value = "true"   # Envoie les alertes Falco vers Wazuh/Slack
  }
  set {
    name  = "driver.kind"
    value = "ebpf"   # eBPF : plus stable que le module kernel sur EKS
  }

  depends_on = [aws_eks_node_group.analyse, aws_eks_node_group.stockage]
}

# ─────────────────────────────────────────────────────────────────────────────
# HPA — Horizontal Pod Autoscaler pour Wazuh Manager
#   Scale de 3 à 10 replicas lors d'une tempête de logs (cahier des charges)
# ─────────────────────────────────────────────────────────────────────────────
resource "kubernetes_horizontal_pod_autoscaler_v2" "wazuh_manager" {
  metadata {
    name      = "wazuh-manager-hpa"
    namespace = "soc"
  }
  spec {
    scale_target_ref {
      api_version = "apps/v1"
      kind        = "StatefulSet"
      name        = "wazuh-manager"
    }
    min_replicas = 3
    max_replicas = 10
    metric {
      type = "Resource"
      resource {
        name = "cpu"
        target {
          type                = "Utilization"
          average_utilization = 70
        }
      }
    }
  }
  depends_on = [helm_release.wazuh]
}
