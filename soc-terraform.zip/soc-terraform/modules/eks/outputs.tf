###############################################################################
#  modules/eks/outputs.tf
###############################################################################
output "cluster_name"     { value = aws_eks_cluster.soc.name }
output "cluster_endpoint" { value = aws_eks_cluster.soc.endpoint }
output "cluster_ca"       { value = aws_eks_cluster.soc.certificate_authority[0].data }
