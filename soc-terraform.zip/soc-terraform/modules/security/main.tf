###############################################################################
#  modules/security/main.tf
#  Politiques IAM pour le SOAR (Shuffle) et l'audit CloudTrail
###############################################################################

variable "project_name"          { type = string }
variable "vpc_id"                 { type = string }
variable "vpc_cidr"               { type = string }
variable "workplace_subnet_cidr"  { type = string }
variable "soc_subnet_cidr"        { type = string }

# ─────────────────────────────────────────────────────────────────────────────
# IAM User SOAR — Shuffle utilise ces credentials pour isoler les EC2
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_iam_user" "soar" {
  name = "${var.project_name}-soar-user"
  path = "/soc/"
  tags = { Purpose = "SOAR automation via Shuffle" }
}

resource "aws_iam_policy" "soar_actions" {
  name        = "${var.project_name}-soar-actions"
  description = "Actions SOAR : isolation EC2, révocation IAM, modification SG"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "IsolateEC2ViaSecurityGroup"
        Effect = "Allow"
        Action = [
          "ec2:AuthorizeSecurityGroupIngress",
          "ec2:RevokeSecurityGroupIngress",
          "ec2:AuthorizeSecurityGroupEgress",
          "ec2:RevokeSecurityGroupEgress",
          "ec2:ModifyInstanceAttribute",
          "ec2:DescribeInstances",
          "ec2:DescribeSecurityGroups"
        ]
        Resource = "*"
      },
      {
        Sid    = "RevokeIAMSuspiciousUser"
        Effect = "Allow"
        Action = [
          "iam:DetachUserPolicy",
          "iam:DeleteAccessKey",
          "iam:ListAccessKeys",
          "iam:GetUser",
          "iam:ListAttachedUserPolicies"
        ]
        Resource = "*"
      },
      {
        Sid    = "ReadCloudTrail"
        Effect = "Allow"
        Action = [
          "cloudtrail:LookupEvents",
          "cloudtrail:GetTrailStatus"
        ]
        Resource = "*"
      }
    ]
  })
}

resource "aws_iam_user_policy_attachment" "soar" {
  user       = aws_iam_user.soar.name
  policy_arn = aws_iam_policy.soar_actions.arn
}

resource "aws_iam_access_key" "soar" {
  user = aws_iam_user.soar.name
}

# ─────────────────────────────────────────────────────────────────────────────
# SECURITY GROUP d'isolation — Appliqué par SOAR lors d'un ransomware
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_security_group" "isolation" {
  name        = "${var.project_name}-isolation-sg"
  description = "SG vide : bloque TOUT le trafic (appliqué par SOAR en cas d'incident)"
  vpc_id      = var.vpc_id

  # Aucune règle ingress/egress = isolation totale de l'instance
  tags = {
    Name    = "${var.project_name}-isolation-sg"
    Purpose = "SOAR incident response - isolation"
  }
}

# ─────────────────────────────────────────────────────────────────────────────
# SECRET MANAGER — Stocke les credentials SOAR de façon sécurisée
# ─────────────────────────────────────────────────────────────────────────────
resource "aws_secretsmanager_secret" "soar_credentials" {
  name                    = "${var.project_name}/soar-aws-credentials"
  description             = "Credentials AWS pour le SOAR (Shuffle)"
  recovery_window_in_days = 7
}

resource "aws_secretsmanager_secret_version" "soar_credentials" {
  secret_id = aws_secretsmanager_secret.soar_credentials.id
  secret_string = jsonencode({
    access_key_id     = aws_iam_access_key.soar.id
    secret_access_key = aws_iam_access_key.soar.secret
    isolation_sg_id   = aws_security_group.isolation.id
  })
}

output "isolation_sg_id" {
  value       = aws_security_group.isolation.id
  description = "ID du SG d'isolation (à configurer dans les playbooks Shuffle)"
}

output "soar_secret_arn" {
  value       = aws_secretsmanager_secret.soar_credentials.arn
  description = "ARN du secret contenant les credentials SOAR"
}
