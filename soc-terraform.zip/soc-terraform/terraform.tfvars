###############################################################################
#  terraform.tfvars — Valeurs à personnaliser avant déploiement
###############################################################################

aws_region             = "eu-west-1"
project_name           = "soc-pfe"
environment            = "prod"
pme_vpc_cidr           = "10.1.0.0/16"
soc_vpc_cidr           = "10.0.0.0/16"

# EKS
eks_node_instance_type = "t3.medium"
eks_desired_nodes      = 3
eks_min_nodes          = 2
eks_max_nodes          = 10

# EC2 — remplace par le nom de ta paire de clés AWS
key_pair_name          = "soc-key"
