###############################################################################
#  outputs.tf — Valeurs affichées après terraform apply
###############################################################################

output "vpc_id" {
  description = "ID du VPC SOC"
  value       = module.vpc_soc.vpc_id
}

output "nlb_dns_name" {
  description = "DNS du Network Load Balancer (point d'entrée des agents Wazuh)"
  value       = module.vpc_soc.nlb_dns_name
}

output "nat_gateway_public_ip" {
  description = "IP publique du NAT Gateway"
  value       = module.vpc_soc.nat_public_ip
}

output "eks_cluster_name" {
  description = "Nom du cluster EKS"
  value       = module.eks.cluster_name
}

output "eks_cluster_endpoint" {
  description = "Endpoint API du cluster EKS"
  value       = module.eks.cluster_endpoint
  sensitive   = true
}

output "eks_kubeconfig_command" {
  description = "Commande pour configurer kubectl"
  value       = "aws eks update-kubeconfig --region ${var.aws_region} --name ${module.eks.cluster_name}"
}

output "ec2_linux_private_ip" {
  description = "IP privée de l'instance EC2 Linux"
  value       = module.ec2_workplace.linux_private_ip
}

output "ec2_windows_private_ip" {
  description = "IP privée de l'instance EC2 Windows"
  value       = module.ec2_workplace.windows_private_ip
}

output "wazuh_agent_install_linux" {
  description = "Commande d'installation de l'agent Wazuh sur Linux"
  value       = "WAZUH_MANAGER='${module.vpc_soc.nlb_dns_name}' dpkg -i wazuh-agent_4.7.0-1_amd64.deb"
}
