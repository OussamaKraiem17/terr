###############################################################################
#  SOC Résilient — Kubernetes / AWS
#  Cahier des charges PFE — Version 2.0
#  main.tf  (point d'entrée)
###############################################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
    kubernetes = {
      source  = "hashicorp/kubernetes"
      version = "~> 2.27"
    }
    helm = {
      source  = "hashicorp/helm"
      version = "~> 2.13"
    }
  }
}

provider "aws" {
  region = var.aws_region

  default_tags {
    tags = {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "Terraform"
    }
  }
}

# ── Récupère le token EKS après création du cluster ──────────────────────────
data "aws_eks_cluster" "soc" {
  name       = module.eks.cluster_name
  depends_on = [module.eks]
}

data "aws_eks_cluster_auth" "soc" {
  name       = module.eks.cluster_name
  depends_on = [module.eks]
}

provider "kubernetes" {
  host                   = data.aws_eks_cluster.soc.endpoint
  cluster_ca_certificate = base64decode(data.aws_eks_cluster.soc.certificate_authority[0].data)
  token                  = data.aws_eks_cluster_auth.soc.token
}

provider "helm" {
  kubernetes {
    host                   = data.aws_eks_cluster.soc.endpoint
    cluster_ca_certificate = base64decode(data.aws_eks_cluster.soc.certificate_authority[0].data)
    token                  = data.aws_eks_cluster_auth.soc.token
  }
}

###############################################################################
# MODULE 1 — VPC PME
###############################################################################
module "vpc_pme" {
  source = "./modules/vpc_pme"

  project_name = var.project_name
  aws_region   = var.aws_region
  vpc_cidr     = var.pme_vpc_cidr
  vpc_name     = "pme"
}

###############################################################################
# MODULE 2 — VPC SOC
###############################################################################
module "vpc_soc" {
  source = "./modules/vpc_soc"

  project_name = var.project_name
  aws_region   = var.aws_region
  vpc_cidr     = var.soc_vpc_cidr
  vpc_name     = "soc"
}

###############################################################################
# MODULE 3 — Cluster EKS Multi-AZ
###############################################################################
module "eks" {
  source = "./modules/eks"

  project_name        = var.project_name
  aws_region          = var.aws_region
  vpc_id              = module.vpc_soc.vpc_id
  private_subnet_ids  = module.vpc_soc.soc_subnet_ids
  node_instance_type  = var.eks_node_instance_type
  desired_node_count  = var.eks_desired_nodes
  min_node_count      = var.eks_min_nodes
  max_node_count      = var.eks_max_nodes

  depends_on = [module.vpc_soc]
}

###############################################################################
# MODULE 4 — Instances EC2 Workplace (Linux + Windows + AD)
###############################################################################
module "ec2_workplace" {
  source = "./modules/ec2"

  project_name          = var.project_name
  vpc_id                = module.vpc_soc.vpc_id
  workplace_subnet_id   = module.vpc_soc.workplace_subnet_id
  wazuh_manager_ip      = module.vpc_soc.nlb_dns_name
  key_pair_name         = var.key_pair_name

  depends_on = [module.vpc]
}

###############################################################################
# MODULE 4 — Security Groups & IAM
###############################################################################
module "security" {
  source = "./modules/security"

  project_name         = var.project_name
  vpc_id               = module.vpc.vpc_id
  vpc_cidr             = var.vpc_cidr
  workplace_subnet_cidr = "10.0.3.0/24"
  soc_subnet_cidr      = "10.0.2.0/24"
}
