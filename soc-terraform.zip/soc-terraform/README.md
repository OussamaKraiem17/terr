# SOC Résilient — Kubernetes / AWS
## Cahier des Charges PFE — Guide de Déploiement Terraform

---

## 🗂️ Structure du projet

```
soc-terraform/
├── main.tf                    # Point d'entrée — orchestre les 4 modules
├── variables.tf               # Variables globales
├── outputs.tf                 # Valeurs affichées après apply
├── terraform.tfvars           # Valeurs à personnaliser
└── modules/
    ├── vpc/                   # VPC segmenté (3 subnets, IGW, NAT, NLB, CloudTrail)
    ├── eks/                   # Cluster EKS + Wazuh + Prometheus + Falco (Helm)
    ├── ec2/                   # Instances EC2 Workplace (Linux + Windows AD)
    └── security/              # IAM SOAR, SG isolation, Secrets Manager
```

---

## 🔧 Prérequis

```bash
# 1. Outils à installer
brew install terraform awscli kubectl helm   # macOS
# ou
apt-get install terraform awscli kubectl     # Ubuntu

# 2. Configurer AWS CLI
aws configure
# Entrer : Access Key ID, Secret Key, Region (eu-west-1), format (json)

# 3. Créer la paire de clés SSH dans AWS
aws ec2 create-key-pair --key-name soc-key \
  --query 'KeyMaterial' --output text > ~/.ssh/soc-key.pem
chmod 400 ~/.ssh/soc-key.pem
```

---

## 🚀 Déploiement pas à pas

```bash
# Étape 1 — Initialiser Terraform (télécharge les providers AWS, K8s, Helm)
terraform init

# Étape 2 — Vérifier le plan (aucune ressource créée)
terraform plan

# Étape 3 — Déployer toute l'infrastructure (~15-20 minutes)
terraform apply -auto-approve

# Étape 4 — Configurer kubectl pour se connecter au cluster EKS
aws eks update-kubeconfig --region eu-west-1 --name soc-pfe-cluster

# Étape 5 — Vérifier que tous les pods SOC sont Running
kubectl get pods -n soc
kubectl get pods -n monitoring
kubectl get pods -n falco-system
```

---

## ✅ Vérifications après déploiement

```bash
# Cluster EKS
kubectl get nodes
# → 3 nodes Ready (pool-analyse + pool-stockage)

# Wazuh (SIEM)
kubectl get statefulset -n soc
# → wazuh-manager-0   1/1   Running
# → wazuh-indexer-0   1/1   Running

# HPA (auto-scaling de 3 à 10 replicas)
kubectl get hpa -n soc
# → wazuh-manager-hpa   3/10   <cpu>

# Falco (DaemonSet sur chaque node)
kubectl get daemonset -n falco-system
# → falco   3   3   3   3   3

# Prometheus + Grafana
kubectl get pods -n monitoring
# → kube-prometheus-stack-grafana-xxx   Running

# Voir le DNS du NLB
terraform output nlb_dns_name
# → soc-pfe-nlb-XXXX.eu-west-1.elb.amazonaws.com
```

---

## 🔍 Tests de validation (Phase 9 du PFE)

```bash
# Test 1 — Brute Force SSH (détection Wazuh)
hydra -l root -P /usr/share/wordlists/rockyou.txt ssh://<EC2_LINUX_IP>
# → Wazuh génère une alerte → SOAR bannit l'IP

# Test 2 — Simulation ransomware (isolation EC2)
ssh ubuntu@<EC2_LINUX_IP>
for i in {1..200}; do touch /tmp/file_$i.enc; done
# → Wazuh détecte → SOAR applique le SG d'isolation

# Test 3 — Résilience K8s (self-healing < 30s)
kubectl delete pod wazuh-manager-0 -n soc
kubectl get pod wazuh-manager-0 -n soc -w
# → Pod recréé automatiquement en < 30 secondes

# Test 4 — Falco (shell dans un container)
kubectl exec -it <pod-name> -n soc -- /bin/bash
# → Falco génère une alerte "Terminal shell in container"
```

---

## 💰 Estimation coût AWS (Free Tier exclu)

| Ressource          | Type        | Coût/mois estimé |
|--------------------|-------------|------------------|
| EKS Control Plane  | Managé      | ~75€             |
| 3× Worker Nodes    | c5.large    | ~120€            |
| 2× Stockage Nodes  | r5.large    | ~100€            |
| NAT Gateway        | Horaire     | ~35€             |
| EBS gp3 (200 Gi)   | Stockage    | ~20€             |
| NLB                | Horaire     | ~20€             |
| **TOTAL**          |             | **~370€/mois**   |

> Pour réduire les coûts en phase de développement : utiliser `t3.medium` pour tous les nodes et réduire `min_node_count` à 1.

---

## 🧹 Destruction (fin de PFE)

```bash
# Supprime TOUTES les ressources AWS pour éviter les coûts
terraform destroy -auto-approve
```
