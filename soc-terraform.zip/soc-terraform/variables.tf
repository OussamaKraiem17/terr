###############################################################################
#  variables.tf — Toutes les variables du projet SOC
###############################################################################

variable "aws_region" {
  description = "Région AWS de déploiement"
  type        = string
  default     = "eu-west-1"
}

variable "project_name" {
  description = "Préfixe utilisé pour nommer toutes les ressources"
  type        = string
  default     = "soc-pfe"
}

variable "environment" {
  description = "Environnement (prod / staging / dev)"
  type        = string
  default     = "prod"
}

variable "pme_vpc_cidr" {
  description = "Bloc CIDR du VPC PME"
  type        = string
  default     = "10.1.0.0/16"
}

variable "soc_vpc_cidr" {
  description = "Bloc CIDR du VPC SOC"
  type        = string
  default     = "10.0.0.0/16"
}

# ── EKS ──────────────────────────────────────────────────────────────────────
variable "eks_node_instance_type" {
  description = "Type d'instance EC2 pour les worker nodes EKS"
  type        = string
  default     = "t3.medium"
}

variable "eks_desired_nodes" {
  description = "Nombre de nodes désiré par pool"
  type        = number
  default     = 3
}

variable "eks_min_nodes" {
  description = "Nombre minimum de nodes (HPA)"
  type        = number
  default     = 2
}

variable "eks_max_nodes" {
  description = "Nombre maximum de nodes lors d'une tempête de logs"
  type        = number
  default     = 10
}

# ── EC2 Workplace ─────────────────────────────────────────────────────────────
variable "key_pair_name" {
  description = "Nom de la clé SSH AWS (doit exister au préalable)"
  type        = string
  default     = "soc-key"
}

variable "linux_ami" {
  description = "AMI Ubuntu 22.04 (eu-west-1)"
  type        = string
  default     = "ami-0694d931cee176e7d"   # Ubuntu 22.04 LTS eu-west-1
}

variable "windows_ami" {
  description = "AMI Windows Server 2022 (eu-west-1)"
  type        = string
  default     = "ami-0b9edc31d10b1be0e"   # Windows Server 2022 eu-west-1
}
