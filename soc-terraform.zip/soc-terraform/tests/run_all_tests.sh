#!/bin/bash
###############################################################################
#  tests/run_all_tests.sh
#  Phase 9 — Tests & Validation de l'architecture SOC
#  Exécuter UNIQUEMENT dans un environnement de lab (pas en production !)
###############################################################################

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

SOC_NAMESPACE="soc"
MONITORING_NAMESPACE="monitoring"
EC2_LINUX_IP="${EC2_LINUX_IP:-10.0.3.10}"
WAZUH_API="https://wazuh-manager.${SOC_NAMESPACE}.svc.cluster.local:55000"

log_test() { echo -e "${BLUE}[TEST]${NC} $1"; }
log_pass() { echo -e "${GREEN}[PASS]${NC} $1"; }
log_fail() { echo -e "${RED}[FAIL]${NC} $1"; }
log_info() { echo -e "${YELLOW}[INFO]${NC} $1"; }

echo ""
echo "═══════════════════════════════════════════════════════"
echo "    SOC PFE — Suite de Tests de Validation"
echo "═══════════════════════════════════════════════════════"
echo ""

###############################################################################
# TEST 1 — Résilience K8s : self-healing < 30 secondes
###############################################################################
log_test "T1 — Self-healing : suppression du pod wazuh-manager-0"
kubectl delete pod wazuh-manager-0 -n "$SOC_NAMESPACE" 2>/dev/null

START_TIME=$(date +%s)
MAX_WAIT=45

while true; do
  PHASE=$(kubectl get pod wazuh-manager-0 -n "$SOC_NAMESPACE" \
    -o jsonpath='{.status.phase}' 2>/dev/null)
  ELAPSED=$(( $(date +%s) - START_TIME ))

  if [ "$PHASE" = "Running" ]; then
    if [ "$ELAPSED" -le 30 ]; then
      log_pass "T1 — Pod recréé en ${ELAPSED}s (< 30s requis) ✓"
    else
      log_fail "T1 — Pod recréé en ${ELAPSED}s (> 30s — SLA manqué)"
    fi
    break
  fi

  if [ "$ELAPSED" -ge "$MAX_WAIT" ]; then
    log_fail "T1 — Pod non recréé après ${MAX_WAIT}s"
    break
  fi

  sleep 2
done

echo ""

###############################################################################
# TEST 2 — HPA : auto-scaling lors d'une tempête de logs
###############################################################################
log_test "T2 — HPA : génération d'une charge élevée pour déclencher le scaling"

INITIAL_REPLICAS=$(kubectl get hpa wazuh-manager-hpa -n "$SOC_NAMESPACE" \
  -o jsonpath='{.status.currentReplicas}' 2>/dev/null)
log_info "Replicas initiaux : $INITIAL_REPLICAS"

# Génère une charge CPU sur le pod Wazuh
kubectl exec wazuh-manager-0 -n "$SOC_NAMESPACE" -- \
  bash -c "for i in \$(seq 1 4); do yes > /dev/null & done; sleep 120" &
STRESS_PID=$!

log_info "Attente de 3 minutes pour le HPA..."
sleep 180

SCALED_REPLICAS=$(kubectl get hpa wazuh-manager-hpa -n "$SOC_NAMESPACE" \
  -o jsonpath='{.status.currentReplicas}' 2>/dev/null)

kill $STRESS_PID 2>/dev/null

if [ "$SCALED_REPLICAS" -gt "$INITIAL_REPLICAS" ]; then
  log_pass "T2 — HPA a scalé de ${INITIAL_REPLICAS} à ${SCALED_REPLICAS} replicas ✓"
else
  log_fail "T2 — HPA n'a pas scalé (toujours ${SCALED_REPLICAS} replicas)"
fi

echo ""

###############################################################################
# TEST 3 — Brute Force SSH : détection Wazuh + action SOAR
###############################################################################
log_test "T3 — Brute Force SSH sur $EC2_LINUX_IP"
log_info "⚠️  Nécessite : apt-get install hydra"

if command -v hydra &>/dev/null; then
  # 10 tentatives rapides pour déclencher la règle Wazuh
  hydra -l root -P /usr/share/wordlists/rockyou.txt \
    -t 4 -V -f ssh://"$EC2_LINUX_IP" 2>/dev/null &
  HYDRA_PID=$!
  sleep 30
  kill $HYDRA_PID 2>/dev/null

  log_info "Vérification de l'alerte dans Wazuh..."
  sleep 10

  ALERTS=$(kubectl exec wazuh-manager-0 -n "$SOC_NAMESPACE" -- \
    grep -c "brute_force\|authentication_failures" \
    /var/ossec/logs/alerts/alerts.json 2>/dev/null || echo "0")

  if [ "$ALERTS" -gt "0" ]; then
    log_pass "T3 — Brute Force détecté ($ALERTS alertes générées) ✓"
  else
    log_fail "T3 — Aucune alerte brute force détectée"
  fi
else
  log_info "T3 — Hydra non installé, test ignoré"
fi

echo ""

###############################################################################
# TEST 4 — Simulation Ransomware : modification massive de fichiers
###############################################################################
log_test "T4 — Simulation ransomware (200 fichiers modifiés)"

SSH_KEY="${SSH_KEY_PATH:-~/.ssh/soc-key.pem}"

if [ -f "$SSH_KEY" ]; then
  ssh -i "$SSH_KEY" -o StrictHostKeyChecking=no ubuntu@"$EC2_LINUX_IP" \
    'for i in $(seq 1 200); do touch /tmp/file_$i.enc; done; echo "Simulation terminée"'

  log_info "Attente de la détection Wazuh (syscheck)..."
  sleep 60

  RANSOMWARE_ALERTS=$(kubectl exec wazuh-manager-0 -n "$SOC_NAMESPACE" -- \
    grep -c "integrity_checksum\|multiple_changes" \
    /var/ossec/logs/alerts/alerts.json 2>/dev/null || echo "0")

  if [ "$RANSOMWARE_ALERTS" -gt "0" ]; then
    log_pass "T4 — Activité ransomware détectée ($RANSOMWARE_ALERTS alertes) ✓"
  else
    log_fail "T4 — Modification de fichiers non détectée"
  fi
else
  log_info "T4 — Clé SSH non trouvée ($SSH_KEY), test ignoré"
fi

echo ""

###############################################################################
# TEST 5 — Falco : détection shell dans container
###############################################################################
log_test "T5 — Falco : ouverture d'un shell dans le container Wazuh"

# Ouvre un shell (déclenche la règle Falco "Shell spawned in SOC container")
kubectl exec wazuh-manager-0 -n "$SOC_NAMESPACE" -- bash -c "echo test_shell" &>/dev/null &
SHELL_PID=$!
sleep 5
kill $SHELL_PID 2>/dev/null

# Vérifie que Falco a généré une alerte
FALCO_ALERT=$(kubectl logs -n falco-system -l app=falco --since=2m 2>/dev/null \
  | grep -c "Shell spawned in SOC container" || echo "0")

if [ "$FALCO_ALERT" -gt "0" ]; then
  log_pass "T5 — Falco a détecté le shell dans le container ✓"
else
  log_fail "T5 — Aucune alerte Falco générée"
fi

echo ""

###############################################################################
# TEST 6 — Agents connectés à Wazuh Manager
###############################################################################
log_test "T6 — Vérification des agents Wazuh connectés"

AGENTS=$(kubectl exec wazuh-manager-0 -n "$SOC_NAMESPACE" -- \
  /var/ossec/bin/agent_control -l 2>/dev/null | grep -c "Active" || echo "0")

if [ "$AGENTS" -ge "1" ]; then
  log_pass "T6 — $AGENTS agents Wazuh actifs ✓"
else
  log_fail "T6 — Aucun agent Wazuh connecté"
fi

echo ""

###############################################################################
# TEST 7 — Chiffrement : TLS 1.3 sur le port 1514
###############################################################################
log_test "T7 — Vérification TLS 1.3 sur le NLB port 1514"

NLB_DNS=$(terraform output -raw nlb_dns_name 2>/dev/null)

if [ -n "$NLB_DNS" ]; then
  TLS_VERSION=$(echo | openssl s_client -connect "$NLB_DNS:1514" \
    -tls1_3 2>/dev/null | grep -c "TLSv1.3" || echo "0")

  if [ "$TLS_VERSION" -gt "0" ]; then
    log_pass "T7 — TLS 1.3 actif sur le NLB ✓"
  else
    log_fail "T7 — TLS 1.3 non détecté"
  fi
else
  log_info "T7 — DNS NLB non disponible (terraform output), test ignoré"
fi

echo ""

###############################################################################
# RÉSUMÉ
###############################################################################
echo "═══════════════════════════════════════════════════════"
echo "    Résumé — Voir les résultats ci-dessus"
echo "    Pour les logs détaillés :"
echo "    kubectl logs -n soc wazuh-manager-0"
echo "    kubectl logs -n falco-system -l app=falco"
echo "═══════════════════════════════════════════════════════"
