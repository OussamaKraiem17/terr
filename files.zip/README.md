# Kubernetes Cluster — Terraform Infrastructure

Self-managed Kubernetes cluster on AWS using kubeadm, mirroring the architecture diagram with each EC2 instance in its own dedicated private subnet.

---

## Architecture Overview

```
Internet
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│                     Kubernetes Cluster (VPC 10.0.0.0/16)    │
│                                                             │
│  Public Subnet (10.0.0.0/24)                               │
│  ┌─────────────┐   ┌─────┐                                 │
│  │ Bastion Host│   │ NLB │  ◄── Internet traffic           │
│  └─────────────┘   └──┬──┘                                 │
│         │             │ :6443                               │
│  ┌──────▼─────────────▼──────────────────────────────────┐ │
│  │ Private Subnets                                        │ │
│  │                                                        │ │
│  │  10.0.1.0/24          10.0.2.0/24                     │ │
│  │  ┌─────────────┐      ┌─────────────┐                  │ │
│  │  │  Master 1   │◄────►│  Master 2   │                  │ │
│  │  └─────────────┘      └─────────────┘                  │ │
│  │                                                        │ │
│  │  10.0.10.0/24   10.0.11.0/24   10.0.12.0/24           │ │
│  │  ┌──────────┐   ┌──────────┐   ┌──────────┐           │ │
│  │  │ Worker 1 │   │ Worker 2 │   │ Worker 3 │           │ │
│  │  └────┬─────┘   └────┬─────┘   └────┬─────┘           │ │
│  └───────┼──────────────┼──────────────┼───────────────── ┘ │
│          │   Outbound   │              │                     │
│  ┌───────▼──────────────▼──────────────▼──────────────────┐ │
│  │                   NAT Gateway                           │ │
│  └────────────────────────────────────────────────────────┘ │
└─────────────────────────────────────────────────────────────┘
```

## Resources Created

| Resource           | Count | Details                                    |
|--------------------|-------|--------------------------------------------|
| VPC                | 1     | 10.0.0.0/16                               |
| Public Subnet      | 1     | 10.0.0.0/24 — Bastion, NLB, NAT GW       |
| Private Subnet     | 5     | One per node (2 masters + 3 workers)       |
| Internet Gateway   | 1     | Public internet access                     |
| NAT Gateway        | 1     | Outbound for all private subnets           |
| Elastic IPs        | 2     | Bastion + NAT Gateway                      |
| EC2 Bastion        | 1     | t3.micro, Amazon Linux 2023                |
| EC2 Master Nodes   | 2     | t3.medium, each in its own private subnet  |
| EC2 Worker Nodes   | 3     | t3.large, each in its own private subnet   |
| Network LB (NLB)   | 1     | Forwards :6443 to both master nodes        |
| Security Groups    | 3     | bastion / master / worker                  |
| IAM Role           | 1     | SSM + ECR + CloudWatch for all nodes       |
| Route Tables       | 2     | Public (IGW) + Private (NAT GW)            |

---

## Prerequisites

- [Terraform](https://developer.hashicorp.com/terraform/downloads) ≥ 1.5
- AWS credentials configured (`aws configure` or environment variables)
- An SSH key pair (`ssh-keygen -t rsa -b 4096`)

---

## Quick Start

```bash
# 1. Clone / copy this directory
cd k8s-terraform/

# 2. Create your tfvars
cp terraform.tfvars.example terraform.tfvars

# 3. Edit terraform.tfvars — set ssh_public_key at minimum:
#    ssh_public_key = "$(cat ~/.ssh/id_rsa.pub)"

# 4. Initialise providers
terraform init

# 5. Review the plan
terraform plan

# 6. Apply
terraform apply
```

---

## Outputs

After `terraform apply` completes:

```
bastion_public_ip    = "x.x.x.x"
nlb_dns_name         = "k8s-cluster-nlb-xxxx.elb.amazonaws.com"
master_1_private_ip  = "10.0.1.10"
master_2_private_ip  = "10.0.2.10"
worker_1_private_ip  = "10.0.10.10"
worker_2_private_ip  = "10.0.11.10"
worker_3_private_ip  = "10.0.12.10"
kubectl_api_server   = "https://k8s-cluster-nlb-xxxx.elb.amazonaws.com:6443"
```

---

## Joining Worker Nodes

After Master 1 finishes its `kubeadm init` (check `/var/log/k8s-master-init.log`):

```bash
# 1. SSH to bastion
ssh -i your-key.pem ec2-user@<bastion_public_ip>

# 2. From bastion, SSH to Master 1
ssh -i your-key.pem ec2-user@10.0.1.10

# 3. Get the join command
sudo cat /var/lib/k8s-join-command.sh

# 4. Run the join command on each worker node (via bastion)
ssh -i your-key.pem ec2-user@10.0.10.10
sudo bash -c "<paste-join-command-here>"
```

---

## Security Notes

- Restrict `ssh_allowed_cidrs` to your specific IP in production (e.g. `["203.0.113.10/32"]`)
- The NLB is internet-facing; restrict source IPs via NLB security policies or a WAF if needed
- All EBS volumes are encrypted at rest
- Worker nodes have no public IPs — all access goes through Bastion
- IAM role uses AWS managed policies (SSM, ECR read, CloudWatch)

---

## Tear Down

```bash
terraform destroy
```

---

## File Structure

```
k8s-terraform/
├── main.tf                    # VPC, subnets, EC2, NLB, SGs, IAM
├── variables.tf               # All input variables with defaults
├── outputs.tf                 # Useful post-apply outputs
├── terraform.tfvars.example   # Template — copy to terraform.tfvars
└── scripts/
    ├── master-init.sh         # kubeadm init + Calico CNI
    └── worker-init.sh         # containerd + kubelet prerequisites
```
