###############################################################
# variables.tf
###############################################################

variable "aws_region" {
  description = "AWS region to deploy into"
  type        = string
  default     = "us-east-1"
}

variable "cluster_name" {
  description = "Name prefix for all resources"
  type        = string
  default     = "k8s-cluster"
}

variable "environment" {
  description = "Deployment environment (e.g. dev, staging, prod)"
  type        = string
  default     = "dev"
}

###############################################################
# NETWORK
###############################################################
variable "vpc_cidr" {
  description = "CIDR block for the VPC"
  type        = string
  default     = "10.0.0.0/16"
}

variable "public_subnet_cidr" {
  description = "CIDR for the public subnet (Bastion + NLB + NAT GW)"
  type        = string
  default     = "10.0.0.0/24"
}

variable "master_subnet_cidrs" {
  description = "CIDRs for the two master node private subnets"
  type        = list(string)
  default     = [
    "10.0.1.0/24",   # Master 1
    "10.0.2.0/24",   # Master 2
  ]
}

variable "worker_subnet_cidrs" {
  description = "CIDRs for the three worker node private subnets (one each)"
  type        = list(string)
  default     = [
    "10.0.10.0/24",  # Worker 1
    "10.0.11.0/24",  # Worker 2
    "10.0.12.0/24",  # Worker 3
  ]
}

variable "pod_network_cidr" {
  description = "CIDR for Kubernetes pod network (used by kubeadm / CNI)"
  type        = string
  default     = "192.168.0.0/16"   # Calico default
}

###############################################################
# ACCESS
###############################################################
variable "ssh_public_key" {
  description = "SSH public key material to create the key pair"
  type        = string
  # Set via TF_VAR_ssh_public_key or terraform.tfvars
}

variable "ssh_allowed_cidrs" {
  description = "CIDRs allowed to SSH to the bastion host"
  type        = list(string)
  default     = ["0.0.0.0/0"]   # Restrict in production!
}

###############################################################
# INSTANCE TYPES
###############################################################
variable "bastion_instance_type" {
  description = "EC2 instance type for bastion host"
  type        = string
  default     = "t3.micro"
}

variable "master_instance_type" {
  description = "EC2 instance type for master nodes"
  type        = string
  default     = "t3.medium"   # 2 vCPU / 4 GB — kubeadm minimum
}

variable "worker_instance_type" {
  description = "EC2 instance type for worker nodes"
  type        = string
  default     = "t3.large"
}

###############################################################
# STORAGE
###############################################################
variable "master_root_volume_size" {
  description = "Root EBS volume size (GiB) for master nodes"
  type        = number
  default     = 50
}

variable "worker_root_volume_size" {
  description = "Root EBS volume size (GiB) for worker nodes"
  type        = number
  default     = 100
}
