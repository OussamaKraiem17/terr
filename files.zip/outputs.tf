###############################################################
# outputs.tf
###############################################################

output "vpc_id" {
  description = "VPC ID"
  value       = aws_vpc.main.id
}

output "bastion_public_ip" {
  description = "Elastic IP of the Bastion Host"
  value       = aws_eip.bastion.public_ip
}

output "nlb_dns_name" {
  description = "DNS name of the Network Load Balancer (K8s API endpoint)"
  value       = aws_lb.nlb.dns_name
}

output "master_1_private_ip" {
  description = "Private IP of Master Node 1"
  value       = aws_instance.master_1.private_ip
}

output "master_2_private_ip" {
  description = "Private IP of Master Node 2"
  value       = aws_instance.master_2.private_ip
}

output "worker_1_private_ip" {
  description = "Private IP of Worker Node 1"
  value       = aws_instance.worker_1.private_ip
}

output "worker_2_private_ip" {
  description = "Private IP of Worker Node 2"
  value       = aws_instance.worker_2.private_ip
}

output "worker_3_private_ip" {
  description = "Private IP of Worker Node 3"
  value       = aws_instance.worker_3.private_ip
}

output "nat_gateway_public_ip" {
  description = "Public IP of the NAT Gateway"
  value       = aws_eip.nat.public_ip
}

output "subnet_summary" {
  description = "Summary of all subnets"
  value = {
    public   = aws_subnet.public.cidr_block
    master_1 = aws_subnet.master_1.cidr_block
    master_2 = aws_subnet.master_2.cidr_block
    worker_1 = aws_subnet.worker_1.cidr_block
    worker_2 = aws_subnet.worker_2.cidr_block
    worker_3 = aws_subnet.worker_3.cidr_block
  }
}

output "ssh_command_bastion" {
  description = "SSH command to reach the bastion host"
  value       = "ssh -i <your-key.pem> ec2-user@${aws_eip.bastion.public_ip}"
}

output "kubectl_api_server" {
  description = "Kubernetes API server URL (via NLB)"
  value       = "https://${aws_lb.nlb.dns_name}:6443"
}
