#!/bin/bash
# scripts/master-init.sh
# Bootstraps a Kubernetes master node using kubeadm
# Template variables: cluster_name, node_index, pod_network_cidr

set -euxo pipefail

CLUSTER_NAME="${cluster_name}"
NODE_INDEX="${node_index}"
POD_NETWORK_CIDR="${pod_network_cidr}"

LOG="/var/log/k8s-master-init.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Master Node $NODE_INDEX — Init start: $(date) ==="

###############################################################
# 1. System prerequisites
###############################################################
yum update -y
yum install -y curl wget git iproute-tc

# Disable swap
swapoff -a
sed -i '/swap/d' /etc/fstab

# Load kernel modules
cat > /etc/modules-load.d/k8s.conf <<EOF
overlay
br_netfilter
EOF
modprobe overlay
modprobe br_netfilter

# Sysctl settings
cat > /etc/sysctl.d/k8s.conf <<EOF
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
EOF
sysctl --system

###############################################################
# 2. Container runtime (containerd)
###############################################################
yum install -y containerd
mkdir -p /etc/containerd
containerd config default > /etc/containerd/config.toml
# Use systemd cgroup driver
sed -i 's/SystemdCgroup = false/SystemdCgroup = true/' /etc/containerd/config.toml
systemctl enable --now containerd

###############################################################
# 3. Kubernetes packages
###############################################################
cat > /etc/yum.repos.d/kubernetes.repo <<EOF
[kubernetes]
name=Kubernetes
baseurl=https://pkgs.k8s.io/core:/stable:/v1.29/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/v1.29/rpm/repodata/repomd.xml.key
EOF

yum install -y kubelet kubeadm kubectl
systemctl enable kubelet

###############################################################
# 4. kubeadm init (only on Master Node 1)
###############################################################
if [ "$NODE_INDEX" -eq 1 ]; then
  # Get the instance's private IP from metadata
  TOKEN=$(curl -sX PUT "http://169.254.169.254/latest/api/token" \
    -H "X-aws-ec2-metadata-token-ttl-seconds: 21600")
  PRIVATE_IP=$(curl -s -H "X-aws-ec2-metadata-token: $TOKEN" \
    http://169.254.169.254/latest/meta-data/local-ipv4)

  kubeadm init \
    --pod-network-cidr="$POD_NETWORK_CIDR" \
    --apiserver-advertise-address="$PRIVATE_IP" \
    --node-name="$CLUSTER_NAME-master-$NODE_INDEX" \
    --ignore-preflight-errors=NumCPU \
    | tee /var/log/kubeadm-init.log

  # Configure kubectl for root
  export KUBECONFIG=/etc/kubernetes/admin.conf
  mkdir -p /root/.kube
  cp /etc/kubernetes/admin.conf /root/.kube/config

  # Install Calico CNI
  kubectl apply -f \
    https://raw.githubusercontent.com/projectcalico/calico/v3.27.0/manifests/calico.yaml

  # Save join command for workers
  kubeadm token create --print-join-command > /var/lib/k8s-join-command.sh
  chmod 600 /var/lib/k8s-join-command.sh

  echo "=== Master 1 init complete ==="
fi

echo "=== Master Node $NODE_INDEX — Init done: $(date) ==="
