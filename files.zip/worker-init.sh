#!/bin/bash
# scripts/worker-init.sh
# Bootstraps a Kubernetes worker node using kubeadm
# Template variables: cluster_name, node_index

set -euxo pipefail

CLUSTER_NAME="${cluster_name}"
NODE_INDEX="${node_index}"

LOG="/var/log/k8s-worker-init.log"
exec > >(tee -a "$LOG") 2>&1

echo "=== Worker Node $NODE_INDEX — Init start: $(date) ==="

###############################################################
# 1. System prerequisites
###############################################################
yum update -y
yum install -y curl wget git iproute-tc

swapoff -a
sed -i '/swap/d' /etc/fstab

cat > /etc/modules-load.d/k8s.conf <<EOF
overlay
br_netfilter
EOF
modprobe overlay
modprobe br_netfilter

cat > /etc/sysctl.d/k8s.conf <<EOF
net.bridge.bridge-nf-call-iptables  = 1
net.bridge.bridge-nf-call-ip6tables = 1
net.ipv4.ip_forward                 = 1
EOF
sysctl --system

###############################################################
# 2. Container runtime (containerd)
###############################################################
yum install -y containerd
mkdir -p /etc/containerd
containerd config default > /etc/containerd/config.toml
sed -i 's/SystemdCgroup = false/SystemdCgroup = true/' /etc/containerd/config.toml
systemctl enable --now containerd

###############################################################
# 3. Kubernetes packages
###############################################################
cat > /etc/yum.repos.d/kubernetes.repo <<EOF
[kubernetes]
name=Kubernetes
baseurl=https://pkgs.k8s.io/core:/stable:/v1.29/rpm/
enabled=1
gpgcheck=1
gpgkey=https://pkgs.k8s.io/core:/stable:/v1.29/rpm/repodata/repomd.xml.key
EOF

yum install -y kubelet kubeadm kubectl
systemctl enable kubelet

echo "=== Worker prerequisites installed. Run join command from master. ==="
echo "=== Worker Node $NODE_INDEX — Init done: $(date) ==="
# NOTE: The actual 'kubeadm join' must be run after Master 1 is ready.
# Retrieve the join command from Master 1:
#   scp ec2-user@<master-1-ip>:/var/lib/k8s-join-command.sh .
#   sudo bash k8s-join-command.sh
