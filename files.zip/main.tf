###############################################################
# main.tf — Kubernetes Cluster Architecture on AWS
# 2 Master Nodes + 3 Worker Nodes, each in its own private subnet
# Bastion Host + NLB in public subnet + NAT Gateway
###############################################################

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

###############################################################
# DATA
###############################################################
data "aws_availability_zones" "available" {
  state = "available"
}

data "aws_ami" "amazon_linux" {
  most_recent = true
  owners      = ["amazon"]
  filter {
    name   = "name"
    values = ["al2023-ami-*-x86_64"]
  }
  filter {
    name   = "virtualization-type"
    values = ["hvm"]
  }
}

###############################################################
# VPC
###############################################################
resource "aws_vpc" "main" {
  cidr_block           = var.vpc_cidr
  enable_dns_support   = true
  enable_dns_hostnames = true

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-vpc" })
}

###############################################################
# INTERNET GATEWAY
###############################################################
resource "aws_internet_gateway" "igw" {
  vpc_id = aws_vpc.main.id
  tags   = merge(local.common_tags, { Name = "${var.cluster_name}-igw" })
}

###############################################################
# PUBLIC SUBNET  (Bastion + NLB + NAT GW)
###############################################################
resource "aws_subnet" "public" {
  vpc_id                  = aws_vpc.main.id
  cidr_block              = var.public_subnet_cidr
  availability_zone       = data.aws_availability_zones.available.names[0]
  map_public_ip_on_launch = true

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-public-subnet" })
}

###############################################################
# PRIVATE SUBNETS — one per node (2 masters + 3 workers = 5)
###############################################################

# Master Node 1
resource "aws_subnet" "master_1" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = var.master_subnet_cidrs[0]
  availability_zone = data.aws_availability_zones.available.names[0]

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-master-1-subnet" })
}

# Master Node 2
resource "aws_subnet" "master_2" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = var.master_subnet_cidrs[1]
  availability_zone = data.aws_availability_zones.available.names[1]

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-master-2-subnet" })
}

# Worker Node 1
resource "aws_subnet" "worker_1" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = var.worker_subnet_cidrs[0]
  availability_zone = data.aws_availability_zones.available.names[0]

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-worker-1-subnet" })
}

# Worker Node 2
resource "aws_subnet" "worker_2" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = var.worker_subnet_cidrs[1]
  availability_zone = data.aws_availability_zones.available.names[1]

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-worker-2-subnet" })
}

# Worker Node 3
resource "aws_subnet" "worker_3" {
  vpc_id            = aws_vpc.main.id
  cidr_block        = var.worker_subnet_cidrs[2]
  availability_zone = data.aws_availability_zones.available.names[2]

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-worker-3-subnet" })
}

###############################################################
# NAT GATEWAY (for private subnets outbound)
###############################################################
resource "aws_eip" "nat" {
  domain = "vpc"
  tags   = merge(local.common_tags, { Name = "${var.cluster_name}-nat-eip" })
}

resource "aws_nat_gateway" "nat" {
  allocation_id = aws_eip.nat.id
  subnet_id     = aws_subnet.public.id
  depends_on    = [aws_internet_gateway.igw]

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-nat-gw" })
}

###############################################################
# ROUTE TABLES
###############################################################

# Public route table — routes to IGW
resource "aws_route_table" "public" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block = "0.0.0.0/0"
    gateway_id = aws_internet_gateway.igw.id
  }

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-public-rt" })
}

resource "aws_route_table_association" "public" {
  subnet_id      = aws_subnet.public.id
  route_table_id = aws_route_table.public.id
}

# Private route table — routes outbound through NAT GW
resource "aws_route_table" "private" {
  vpc_id = aws_vpc.main.id

  route {
    cidr_block     = "0.0.0.0/0"
    nat_gateway_id = aws_nat_gateway.nat.id
  }

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-private-rt" })
}

resource "aws_route_table_association" "master_1" {
  subnet_id      = aws_subnet.master_1.id
  route_table_id = aws_route_table.private.id
}

resource "aws_route_table_association" "master_2" {
  subnet_id      = aws_subnet.master_2.id
  route_table_id = aws_route_table.private.id
}

resource "aws_route_table_association" "worker_1" {
  subnet_id      = aws_subnet.worker_1.id
  route_table_id = aws_route_table.private.id
}

resource "aws_route_table_association" "worker_2" {
  subnet_id      = aws_subnet.worker_2.id
  route_table_id = aws_route_table.private.id
}

resource "aws_route_table_association" "worker_3" {
  subnet_id      = aws_subnet.worker_3.id
  route_table_id = aws_route_table.private.id
}

###############################################################
# SECURITY GROUPS
###############################################################

# Bastion SG — SSH from allowed IPs only
resource "aws_security_group" "bastion" {
  name        = "${var.cluster_name}-bastion-sg"
  description = "Allow SSH to bastion host"
  vpc_id      = aws_vpc.main.id

  ingress {
    description = "SSH from allowed CIDRs"
    from_port   = 22
    to_port     = 22
    protocol    = "tcp"
    cidr_blocks = var.ssh_allowed_cidrs
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-bastion-sg" })
}

# Master Node SG
resource "aws_security_group" "master" {
  name        = "${var.cluster_name}-master-sg"
  description = "Kubernetes master node security group"
  vpc_id      = aws_vpc.main.id

  # SSH from bastion
  ingress {
    description     = "SSH from bastion"
    from_port       = 22
    to_port         = 22
    protocol        = "tcp"
    security_groups = [aws_security_group.bastion.id]
  }

  # Kubernetes API from NLB / bastion
  ingress {
    description     = "K8s API from bastion"
    from_port       = 6443
    to_port         = 6443
    protocol        = "tcp"
    security_groups = [aws_security_group.bastion.id]
  }

  # Kubernetes API from NLB (NLB passes through client IPs, allow VPC CIDR)
  ingress {
    description = "K8s API from VPC (NLB)"
    from_port   = 6443
    to_port     = 6443
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  # etcd peer communication
  ingress {
    description = "etcd peer"
    from_port   = 2379
    to_port     = 2380
    protocol    = "tcp"
    self        = true
  }

  # etcd peer from masters
  ingress {
    description     = "etcd from other masters"
    from_port       = 2379
    to_port         = 2380
    protocol        = "tcp"
    security_groups = []
    self            = true
  }

  # Kubelet API (masters → workers)
  ingress {
    description = "Kubelet API"
    from_port   = 10250
    to_port     = 10250
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  # Controller manager & scheduler
  ingress {
    description = "Scheduler and controller"
    from_port   = 10257
    to_port     = 10259
    protocol    = "tcp"
    self        = true
  }

  # Allow all internal cluster traffic
  ingress {
    description = "All internal VPC"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = [var.vpc_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-master-sg" })
}

# Worker Node SG
resource "aws_security_group" "worker" {
  name        = "${var.cluster_name}-worker-sg"
  description = "Kubernetes worker node security group"
  vpc_id      = aws_vpc.main.id

  # SSH from bastion
  ingress {
    description     = "SSH from bastion"
    from_port       = 22
    to_port         = 22
    protocol        = "tcp"
    security_groups = [aws_security_group.bastion.id]
  }

  # Kubelet API
  ingress {
    description     = "Kubelet API from masters"
    from_port       = 10250
    to_port         = 10250
    protocol        = "tcp"
    security_groups = [aws_security_group.master.id]
  }

  # NodePort services
  ingress {
    description = "NodePort services"
    from_port   = 30000
    to_port     = 32767
    protocol    = "tcp"
    cidr_blocks = [var.vpc_cidr]
  }

  # All internal VPC (pod-to-pod, CNI)
  ingress {
    description = "All internal VPC (CNI)"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = [var.vpc_cidr]
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-worker-sg" })
}

###############################################################
# KEY PAIR
###############################################################
resource "aws_key_pair" "k8s" {
  key_name   = "${var.cluster_name}-key"
  public_key = var.ssh_public_key

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-key" })
}

###############################################################
# IAM ROLE FOR EC2 (SSM + ECR + CloudWatch)
###############################################################
resource "aws_iam_role" "k8s_node" {
  name = "${var.cluster_name}-node-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect    = "Allow"
      Principal = { Service = "ec2.amazonaws.com" }
      Action    = "sts:AssumeRole"
    }]
  })

  tags = local.common_tags
}

resource "aws_iam_role_policy_attachment" "ssm" {
  role       = aws_iam_role.k8s_node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonSSMManagedInstanceCore"
}

resource "aws_iam_role_policy_attachment" "ecr" {
  role       = aws_iam_role.k8s_node.name
  policy_arn = "arn:aws:iam::aws:policy/AmazonEC2ContainerRegistryReadOnly"
}

resource "aws_iam_role_policy_attachment" "cloudwatch" {
  role       = aws_iam_role.k8s_node.name
  policy_arn = "arn:aws:iam::aws:policy/CloudWatchAgentServerPolicy"
}

resource "aws_iam_instance_profile" "k8s_node" {
  name = "${var.cluster_name}-node-profile"
  role = aws_iam_role.k8s_node.name
}

###############################################################
# BASTION HOST
###############################################################
resource "aws_instance" "bastion" {
  ami                         = data.aws_ami.amazon_linux.id
  instance_type               = var.bastion_instance_type
  subnet_id                   = aws_subnet.public.id
  vpc_security_group_ids      = [aws_security_group.bastion.id]
  key_name                    = aws_key_pair.k8s.key_name
  associate_public_ip_address = true
  iam_instance_profile        = aws_iam_instance_profile.k8s_node.name

  root_block_device {
    volume_size           = 20
    volume_type           = "gp3"
    delete_on_termination = true
    encrypted             = true
  }

  user_data = base64encode(<<-EOF
    #!/bin/bash
    yum update -y
    yum install -y kubectl
    echo "Bastion ready" > /var/log/bastion-init.log
  EOF
  )

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-bastion", Role = "bastion" })
}

resource "aws_eip" "bastion" {
  instance = aws_instance.bastion.id
  domain   = "vpc"
  tags     = merge(local.common_tags, { Name = "${var.cluster_name}-bastion-eip" })
}

###############################################################
# MASTER NODES
###############################################################
resource "aws_instance" "master_1" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.master_instance_type
  subnet_id              = aws_subnet.master_1.id
  vpc_security_group_ids = [aws_security_group.master.id]
  key_name               = aws_key_pair.k8s.key_name
  iam_instance_profile   = aws_iam_instance_profile.k8s_node.name
  private_ip             = cidrhost(var.master_subnet_cidrs[0], 10)

  root_block_device {
    volume_size           = var.master_root_volume_size
    volume_type           = "gp3"
    delete_on_termination = true
    encrypted             = true
  }

  user_data = base64encode(templatefile("${path.module}/scripts/master-init.sh", {
    cluster_name = var.cluster_name
    node_index   = 1
    pod_network_cidr = var.pod_network_cidr
  }))

  tags = merge(local.common_tags, {
    Name = "${var.cluster_name}-master-1"
    Role = "master"
    "kubernetes.io/cluster/${var.cluster_name}" = "owned"
  })
}

resource "aws_instance" "master_2" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.master_instance_type
  subnet_id              = aws_subnet.master_2.id
  vpc_security_group_ids = [aws_security_group.master.id]
  key_name               = aws_key_pair.k8s.key_name
  iam_instance_profile   = aws_iam_instance_profile.k8s_node.name
  private_ip             = cidrhost(var.master_subnet_cidrs[1], 10)

  root_block_device {
    volume_size           = var.master_root_volume_size
    volume_type           = "gp3"
    delete_on_termination = true
    encrypted             = true
  }

  user_data = base64encode(templatefile("${path.module}/scripts/master-init.sh", {
    cluster_name = var.cluster_name
    node_index   = 2
    pod_network_cidr = var.pod_network_cidr
  }))

  tags = merge(local.common_tags, {
    Name = "${var.cluster_name}-master-2"
    Role = "master"
    "kubernetes.io/cluster/${var.cluster_name}" = "owned"
  })
}

###############################################################
# WORKER NODES — each in its own private subnet
###############################################################
resource "aws_instance" "worker_1" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.worker_instance_type
  subnet_id              = aws_subnet.worker_1.id
  vpc_security_group_ids = [aws_security_group.worker.id]
  key_name               = aws_key_pair.k8s.key_name
  iam_instance_profile   = aws_iam_instance_profile.k8s_node.name
  private_ip             = cidrhost(var.worker_subnet_cidrs[0], 10)

  root_block_device {
    volume_size           = var.worker_root_volume_size
    volume_type           = "gp3"
    delete_on_termination = true
    encrypted             = true
  }

  user_data = base64encode(templatefile("${path.module}/scripts/worker-init.sh", {
    cluster_name = var.cluster_name
    node_index   = 1
  }))

  tags = merge(local.common_tags, {
    Name = "${var.cluster_name}-worker-1"
    Role = "worker"
    "kubernetes.io/cluster/${var.cluster_name}" = "owned"
  })
}

resource "aws_instance" "worker_2" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.worker_instance_type
  subnet_id              = aws_subnet.worker_2.id
  vpc_security_group_ids = [aws_security_group.worker.id]
  key_name               = aws_key_pair.k8s.key_name
  iam_instance_profile   = aws_iam_instance_profile.k8s_node.name
  private_ip             = cidrhost(var.worker_subnet_cidrs[1], 10)

  root_block_device {
    volume_size           = var.worker_root_volume_size
    volume_type           = "gp3"
    delete_on_termination = true
    encrypted             = true
  }

  user_data = base64encode(templatefile("${path.module}/scripts/worker-init.sh", {
    cluster_name = var.cluster_name
    node_index   = 2
  }))

  tags = merge(local.common_tags, {
    Name = "${var.cluster_name}-worker-2"
    Role = "worker"
    "kubernetes.io/cluster/${var.cluster_name}" = "owned"
  })
}

resource "aws_instance" "worker_3" {
  ami                    = data.aws_ami.amazon_linux.id
  instance_type          = var.worker_instance_type
  subnet_id              = aws_subnet.worker_3.id
  vpc_security_group_ids = [aws_security_group.worker.id]
  key_name               = aws_key_pair.k8s.key_name
  iam_instance_profile   = aws_iam_instance_profile.k8s_node.name
  private_ip             = cidrhost(var.worker_subnet_cidrs[2], 10)

  root_block_device {
    volume_size           = var.worker_root_volume_size
    volume_type           = "gp3"
    delete_on_termination = true
    encrypted             = true
  }

  user_data = base64encode(templatefile("${path.module}/scripts/worker-init.sh", {
    cluster_name = var.cluster_name
    node_index   = 3
  }))

  tags = merge(local.common_tags, {
    Name = "${var.cluster_name}-worker-3"
    Role = "worker"
    "kubernetes.io/cluster/${var.cluster_name}" = "owned"
  })
}

###############################################################
# NETWORK LOAD BALANCER (for Kubernetes API)
###############################################################
resource "aws_lb" "nlb" {
  name               = "${var.cluster_name}-nlb"
  internal           = false
  load_balancer_type = "network"
  subnets            = [aws_subnet.public.id]

  enable_deletion_protection       = false
  enable_cross_zone_load_balancing = true

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-nlb" })
}

resource "aws_lb_target_group" "k8s_api" {
  name        = "${var.cluster_name}-api-tg"
  port        = 6443
  protocol    = "TCP"
  vpc_id      = aws_vpc.main.id
  target_type = "instance"

  health_check {
    protocol            = "TCP"
    port                = 6443
    healthy_threshold   = 2
    unhealthy_threshold = 2
    interval            = 10
  }

  tags = merge(local.common_tags, { Name = "${var.cluster_name}-api-tg" })
}

resource "aws_lb_target_group_attachment" "master_1" {
  target_group_arn = aws_lb_target_group.k8s_api.arn
  target_id        = aws_instance.master_1.id
  port             = 6443
}

resource "aws_lb_target_group_attachment" "master_2" {
  target_group_arn = aws_lb_target_group.k8s_api.arn
  target_id        = aws_instance.master_2.id
  port             = 6443
}

resource "aws_lb_listener" "k8s_api" {
  load_balancer_arn = aws_lb.nlb.arn
  port              = 6443
  protocol          = "TCP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.k8s_api.arn
  }
}

###############################################################
# LOCALS
###############################################################
locals {
  common_tags = {
    Project     = var.cluster_name
    Environment = var.environment
    ManagedBy   = "Terraform"
  }
}
